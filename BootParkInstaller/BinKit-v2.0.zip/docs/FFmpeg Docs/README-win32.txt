FFmpeg Win32 binary Builds by Gianluigi Tiesi <sherpya@netfarm.it>

This binary build license is GPL, not LGPL,
please read COPYING.txt

Modified windows icons are made by using Lila SVG Icon and Theme Artwork:
http://www.lila-center.info/doku.php
Copyright 2004-2006 Lila Community
available under the GNU General Public License

-- Report bugs to sherpya@netfarm.it
