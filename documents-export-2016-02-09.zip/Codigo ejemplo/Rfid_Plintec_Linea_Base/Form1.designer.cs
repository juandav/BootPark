﻿namespace RFid_Plintec
{
    partial class Form1
    {
        /// <summary>
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows 窗体设计器生成的代码

        /// <summary>
        /// 设计器支持所需的方法 - 不要
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.TabSheet_CMD = new System.Windows.Forms.TabPage();
            this.groupBox46 = new System.Windows.Forms.GroupBox();
            this.button26 = new System.Windows.Forms.Button();
            this.textBox14 = new System.Windows.Forms.TextBox();
            this.groupBox42 = new System.Windows.Forms.GroupBox();
            this.groupBox41 = new System.Windows.Forms.GroupBox();
            this.CloseNetPort = new System.Windows.Forms.Button();
            this.OpenNetPort = new System.Windows.Forms.Button();
            this.textBox9 = new System.Windows.Forms.TextBox();
            this.label63 = new System.Windows.Forms.Label();
            this.textBox8 = new System.Windows.Forms.TextBox();
            this.label62 = new System.Windows.Forms.Label();
            this.textBox7 = new System.Windows.Forms.TextBox();
            this.label61 = new System.Windows.Forms.Label();
            this.radioButton2 = new System.Windows.Forms.RadioButton();
            this.radioButton1 = new System.Windows.Forms.RadioButton();
            this.GroupBox1 = new System.Windows.Forms.GroupBox();
            this.ComboBox_baud2 = new System.Windows.Forms.ComboBox();
            this.label47 = new System.Windows.Forms.Label();
            this.ComboBox_AlreadyOpenCOM = new System.Windows.Forms.ComboBox();
            this.label3 = new System.Windows.Forms.Label();
            this.ClosePort = new System.Windows.Forms.Button();
            this.OpenPort = new System.Windows.Forms.Button();
            this.Edit_CmdComAddr = new System.Windows.Forms.TextBox();
            this.Label2 = new System.Windows.Forms.Label();
            this.ComboBox_COM = new System.Windows.Forms.ComboBox();
            this.Label1 = new System.Windows.Forms.Label();
            this.groupBox28 = new System.Windows.Forms.GroupBox();
            this.Radio_beepDis = new System.Windows.Forms.RadioButton();
            this.Radio_beepEn = new System.Windows.Forms.RadioButton();
            this.Button_Beep = new System.Windows.Forms.Button();
            this.groupBox27 = new System.Windows.Forms.GroupBox();
            this.Button_OutputRep = new System.Windows.Forms.Button();
            this.checkBox14 = new System.Windows.Forms.CheckBox();
            this.checkBox15 = new System.Windows.Forms.CheckBox();
            this.checkBox16 = new System.Windows.Forms.CheckBox();
            this.checkBox17 = new System.Windows.Forms.CheckBox();
            this.groupBox26 = new System.Windows.Forms.GroupBox();
            this.ClockCMD = new System.Windows.Forms.Button();
            this.GetClock = new System.Windows.Forms.RadioButton();
            this.SetClock = new System.Windows.Forms.RadioButton();
            this.label39 = new System.Windows.Forms.Label();
            this.label40 = new System.Windows.Forms.Label();
            this.label41 = new System.Windows.Forms.Label();
            this.label42 = new System.Windows.Forms.Label();
            this.label45 = new System.Windows.Forms.Label();
            this.Text_sec = new System.Windows.Forms.TextBox();
            this.Text_min = new System.Windows.Forms.TextBox();
            this.Text_hour = new System.Windows.Forms.TextBox();
            this.Text_day = new System.Windows.Forms.TextBox();
            this.Text_month = new System.Windows.Forms.TextBox();
            this.label46 = new System.Windows.Forms.Label();
            this.Text_year = new System.Windows.Forms.TextBox();
            this.TextBox5 = new System.Windows.Forms.TextBox();
            this.groupBox25 = new System.Windows.Forms.GroupBox();
            this.Button_RelayTime = new System.Windows.Forms.Button();
            this.label38 = new System.Windows.Forms.Label();
            this.ComboBox_RelayTime = new System.Windows.Forms.ComboBox();
            this.label37 = new System.Windows.Forms.Label();
            this.groupBox24 = new System.Windows.Forms.GroupBox();
            this.Button_Ant = new System.Windows.Forms.Button();
            this.checkBox13 = new System.Windows.Forms.CheckBox();
            this.checkBox12 = new System.Windows.Forms.CheckBox();
            this.checkBox11 = new System.Windows.Forms.CheckBox();
            this.checkBox10 = new System.Windows.Forms.CheckBox();
            this.groupBox23 = new System.Windows.Forms.GroupBox();
            this.Button_GetGPIO = new System.Windows.Forms.Button();
            this.Button_SetGPIO = new System.Windows.Forms.Button();
            this.checkBox9 = new System.Windows.Forms.CheckBox();
            this.checkBox8 = new System.Windows.Forms.CheckBox();
            this.checkBox7 = new System.Windows.Forms.CheckBox();
            this.checkBox6 = new System.Windows.Forms.CheckBox();
            this.checkBox5 = new System.Windows.Forms.CheckBox();
            this.checkBox4 = new System.Windows.Forms.CheckBox();
            this.checkBox3 = new System.Windows.Forms.CheckBox();
            this.checkBox2 = new System.Windows.Forms.CheckBox();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.groupBox30 = new System.Windows.Forms.GroupBox();
            this.radioButton_band5 = new System.Windows.Forms.RadioButton();
            this.radioButton_band4 = new System.Windows.Forms.RadioButton();
            this.radioButton_band3 = new System.Windows.Forms.RadioButton();
            this.radioButton_band2 = new System.Windows.Forms.RadioButton();
            this.radioButton_band1 = new System.Windows.Forms.RadioButton();
            this.progressBar1 = new System.Windows.Forms.ProgressBar();
            this.Button1 = new System.Windows.Forms.Button();
            this.Button5 = new System.Windows.Forms.Button();
            this.ComboBox_scantime = new System.Windows.Forms.ComboBox();
            this.ComboBox_baud = new System.Windows.Forms.ComboBox();
            this.CheckBox_SameFre = new System.Windows.Forms.CheckBox();
            this.label17 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.ComboBox_dmaxfre = new System.Windows.Forms.ComboBox();
            this.ComboBox_dminfre = new System.Windows.Forms.ComboBox();
            this.ComboBox_PowerDbm = new System.Windows.Forms.ComboBox();
            this.Edit_NewComAdr = new System.Windows.Forms.TextBox();
            this.label15 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.Button3 = new System.Windows.Forms.Button();
            this.Edit_scantime = new System.Windows.Forms.TextBox();
            this.EPCC1G2 = new System.Windows.Forms.CheckBox();
            this.ISO180006B = new System.Windows.Forms.CheckBox();
            this.label11 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.Edit_dmaxfre = new System.Windows.Forms.TextBox();
            this.Edit_powerdBm = new System.Windows.Forms.TextBox();
            this.Edit_Version = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.Edit_dminfre = new System.Windows.Forms.TextBox();
            this.Edit_ComAdr = new System.Windows.Forms.TextBox();
            this.Edit_Type = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.tabPage4 = new System.Windows.Forms.TabPage();
            this.button37 = new System.Windows.Forms.Button();
            this.button25 = new System.Windows.Forms.Button();
            this.groupBox48 = new System.Windows.Forms.GroupBox();
            this.label71 = new System.Windows.Forms.Label();
            this.comboBox6 = new System.Windows.Forms.ComboBox();
            this.label70 = new System.Windows.Forms.Label();
            this.button30 = new System.Windows.Forms.Button();
            this.button29 = new System.Windows.Forms.Button();
            this.textBox16 = new System.Windows.Forms.TextBox();
            this.textBox15 = new System.Windows.Forms.TextBox();
            this.groupBox51 = new System.Windows.Forms.GroupBox();
            this.button36 = new System.Windows.Forms.Button();
            this.button33 = new System.Windows.Forms.Button();
            this.label110 = new System.Windows.Forms.Label();
            this.macTB = new System.Windows.Forms.TextBox();
            this.panel_StaticIp = new System.Windows.Forms.Panel();
            this.label109 = new System.Windows.Forms.Label();
            this.label108 = new System.Windows.Forms.Label();
            this.label107 = new System.Windows.Forms.Label();
            this.label106 = new System.Windows.Forms.Label();
            this.label105 = new System.Windows.Forms.Label();
            this.altDNSTB = new System.Windows.Forms.TextBox();
            this.pDNSTB = new System.Windows.Forms.TextBox();
            this.gatewayTB = new System.Windows.Forms.TextBox();
            this.subnetTB = new System.Windows.Forms.TextBox();
            this.ipTB = new System.Windows.Forms.TextBox();
            this.groupBox50 = new System.Windows.Forms.GroupBox();
            this.button35 = new System.Windows.Forms.Button();
            this.button32 = new System.Windows.Forms.Button();
            this.panel_TCP = new System.Windows.Forms.Panel();
            this.label87 = new System.Windows.Forms.Label();
            this.label88 = new System.Windows.Forms.Label();
            this.label89 = new System.Windows.Forms.Label();
            this.label90 = new System.Windows.Forms.Label();
            this.label93 = new System.Windows.Forms.Label();
            this.workasCB = new System.Windows.Forms.ComboBox();
            this.tcpRomteHostTB = new System.Windows.Forms.TextBox();
            this.tcpRemotePortNUD = new System.Windows.Forms.NumericUpDown();
            this.tcpLocalPortNUD = new System.Windows.Forms.NumericUpDown();
            this.tcpActiveCB = new System.Windows.Forms.ComboBox();
            this.groupBox49 = new System.Windows.Forms.GroupBox();
            this.button34 = new System.Windows.Forms.Button();
            this.button31 = new System.Windows.Forms.Button();
            this.panel4 = new System.Windows.Forms.Panel();
            this.label72 = new System.Windows.Forms.Label();
            this.label73 = new System.Windows.Forms.Label();
            this.label74 = new System.Windows.Forms.Label();
            this.label75 = new System.Windows.Forms.Label();
            this.label76 = new System.Windows.Forms.Label();
            this.label77 = new System.Windows.Forms.Label();
            this.label78 = new System.Windows.Forms.Label();
            this.protocolCB = new System.Windows.Forms.ComboBox();
            this.stopbitCB = new System.Windows.Forms.ComboBox();
            this.parityCB = new System.Windows.Forms.ComboBox();
            this.databitCB = new System.Windows.Forms.ComboBox();
            this.baudrateCB = new System.Windows.Forms.ComboBox();
            this.flowCB = new System.Windows.Forms.ComboBox();
            this.fifoCB = new System.Windows.Forms.ComboBox();
            this.groupBox47 = new System.Windows.Forms.GroupBox();
            this.button28 = new System.Windows.Forms.Button();
            this.button27 = new System.Windows.Forms.Button();
            this.TabSheet_EPCC1G2 = new System.Windows.Forms.TabPage();
            this.groupBox31 = new System.Windows.Forms.GroupBox();
            this.maskData_textBox = new System.Windows.Forms.TextBox();
            this.label60 = new System.Windows.Forms.Label();
            this.groupBox40 = new System.Windows.Forms.GroupBox();
            this.R_User = new System.Windows.Forms.RadioButton();
            this.R_TID = new System.Windows.Forms.RadioButton();
            this.R_EPC = new System.Windows.Forms.RadioButton();
            this.checkBox1 = new System.Windows.Forms.CheckBox();
            this.maskLen_textBox = new System.Windows.Forms.TextBox();
            this.label44 = new System.Windows.Forms.Label();
            this.maskadr_textbox = new System.Windows.Forms.TextBox();
            this.label43 = new System.Windows.Forms.Label();
            this.groupBox18 = new System.Windows.Forms.GroupBox();
            this.Button_LockUserBlock_G2 = new System.Windows.Forms.Button();
            this.Edit_AccessCode6 = new System.Windows.Forms.TextBox();
            this.ComboBox_BlockNum = new System.Windows.Forms.ComboBox();
            this.label30 = new System.Windows.Forms.Label();
            this.label29 = new System.Windows.Forms.Label();
            this.ComboBox_EPC6 = new System.Windows.Forms.ComboBox();
            this.groupBox16 = new System.Windows.Forms.GroupBox();
            this.Label_Alarm = new System.Windows.Forms.Label();
            this.button4 = new System.Windows.Forms.Button();
            this.Button_SetEASAlarm_G2 = new System.Windows.Forms.Button();
            this.groupBox17 = new System.Windows.Forms.GroupBox();
            this.NoAlarm_G2 = new System.Windows.Forms.RadioButton();
            this.Alarm_G2 = new System.Windows.Forms.RadioButton();
            this.Edit_AccessCode5 = new System.Windows.Forms.TextBox();
            this.label28 = new System.Windows.Forms.Label();
            this.ComboBox_EPC5 = new System.Windows.Forms.ComboBox();
            this.groupBox15 = new System.Windows.Forms.GroupBox();
            this.Button_CheckReadProtected_G2 = new System.Windows.Forms.Button();
            this.Button_RemoveReadProtect_G2 = new System.Windows.Forms.Button();
            this.Button_SetMultiReadProtect_G2 = new System.Windows.Forms.Button();
            this.Button_SetReadProtect_G2 = new System.Windows.Forms.Button();
            this.Edit_AccessCode4 = new System.Windows.Forms.TextBox();
            this.label27 = new System.Windows.Forms.Label();
            this.ComboBox_EPC4 = new System.Windows.Forms.ComboBox();
            this.groupBox14 = new System.Windows.Forms.GroupBox();
            this.Button_WriteEPC_G2 = new System.Windows.Forms.Button();
            this.Edit_AccessCode3 = new System.Windows.Forms.TextBox();
            this.label26 = new System.Windows.Forms.Label();
            this.Edit_WriteEPC = new System.Windows.Forms.TextBox();
            this.label25 = new System.Windows.Forms.Label();
            this.groupBox13 = new System.Windows.Forms.GroupBox();
            this.Button_DestroyCard = new System.Windows.Forms.Button();
            this.Edit_DestroyCode = new System.Windows.Forms.TextBox();
            this.label24 = new System.Windows.Forms.Label();
            this.ComboBox_EPC3 = new System.Windows.Forms.ComboBox();
            this.groupBox12 = new System.Windows.Forms.GroupBox();
            this.CheckBox_TID = new System.Windows.Forms.CheckBox();
            this.groupBox45 = new System.Windows.Forms.GroupBox();
            this.textBox12 = new System.Windows.Forms.TextBox();
            this.label68 = new System.Windows.Forms.Label();
            this.textBox13 = new System.Windows.Forms.TextBox();
            this.label69 = new System.Windows.Forms.Label();
            this.button2 = new System.Windows.Forms.Button();
            this.ComboBox_IntervalTime = new System.Windows.Forms.ComboBox();
            this.label23 = new System.Windows.Forms.Label();
            this.groupBox7 = new System.Windows.Forms.GroupBox();
            this.Button_SetProtectState = new System.Windows.Forms.Button();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.label22 = new System.Windows.Forms.Label();
            this.groupBox11 = new System.Windows.Forms.GroupBox();
            this.AlwaysNot2 = new System.Windows.Forms.RadioButton();
            this.Always2 = new System.Windows.Forms.RadioButton();
            this.Proect2 = new System.Windows.Forms.RadioButton();
            this.NoProect2 = new System.Windows.Forms.RadioButton();
            this.groupBox10 = new System.Windows.Forms.GroupBox();
            this.P_User = new System.Windows.Forms.RadioButton();
            this.P_TID = new System.Windows.Forms.RadioButton();
            this.P_EPC = new System.Windows.Forms.RadioButton();
            this.P_Reserve = new System.Windows.Forms.RadioButton();
            this.groupBox8 = new System.Windows.Forms.GroupBox();
            this.AlwaysNot = new System.Windows.Forms.RadioButton();
            this.Always = new System.Windows.Forms.RadioButton();
            this.Proect = new System.Windows.Forms.RadioButton();
            this.NoProect = new System.Windows.Forms.RadioButton();
            this.groupBox9 = new System.Windows.Forms.GroupBox();
            this.AccessCode = new System.Windows.Forms.RadioButton();
            this.DestroyCode = new System.Windows.Forms.RadioButton();
            this.ComboBox_EPC1 = new System.Windows.Forms.ComboBox();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.textBox_pc = new System.Windows.Forms.TextBox();
            this.checkBox_pc = new System.Windows.Forms.CheckBox();
            this.BlockWrite = new System.Windows.Forms.Button();
            this.ComboBox_EPC2 = new System.Windows.Forms.ComboBox();
            this.button7 = new System.Windows.Forms.Button();
            this.Button_BlockErase = new System.Windows.Forms.Button();
            this.Button_DataWrite = new System.Windows.Forms.Button();
            this.SpeedButton_Read_G2 = new System.Windows.Forms.Button();
            this.Edit_WriteData = new System.Windows.Forms.TextBox();
            this.Edit_AccessCode2 = new System.Windows.Forms.TextBox();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.Edit_WordPtr = new System.Windows.Forms.TextBox();
            this.listBox1 = new System.Windows.Forms.ListBox();
            this.label21 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.groupBox6 = new System.Windows.Forms.GroupBox();
            this.C_User = new System.Windows.Forms.RadioButton();
            this.C_TID = new System.Windows.Forms.RadioButton();
            this.C_EPC = new System.Windows.Forms.RadioButton();
            this.C_Reserve = new System.Windows.Forms.RadioButton();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.textBox18 = new System.Windows.Forms.TextBox();
            this.label80 = new System.Windows.Forms.Label();
            this.textBox17 = new System.Windows.Forms.TextBox();
            this.label79 = new System.Windows.Forms.Label();
            this.ListView1_EPC = new System.Windows.Forms.ListView();
            this.listViewCol_Number = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.listViewCol_ID = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.listViewCol_Length = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader10 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.listViewCol_Times = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.TabSheet_6B = new System.Windows.Forms.TabPage();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.columnHeader5 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader6 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader7 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader1 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader2 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader3 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader4 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader8 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader9 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.StatusBar1 = new System.Windows.Forms.StatusBar();
            this.TStatusPanel = new System.Windows.Forms.StatusBarPanel();
            this.Port = new System.Windows.Forms.StatusBarPanel();
            this.Manufacturername = new System.Windows.Forms.StatusBarPanel();
            this.Timer_Test_ = new System.Windows.Forms.Timer(this.components);
            this.Timer_G2_Read = new System.Windows.Forms.Timer(this.components);
            this.Timer_G2_Alarm = new System.Windows.Forms.Timer(this.components);
            this.Timer_Test_6B = new System.Windows.Forms.Timer(this.components);
            this.Timer_6B_Read = new System.Windows.Forms.Timer(this.components);
            this.Timer_6B_Write = new System.Windows.Forms.Timer(this.components);
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.tabControl1.SuspendLayout();
            this.TabSheet_CMD.SuspendLayout();
            this.groupBox46.SuspendLayout();
            this.groupBox42.SuspendLayout();
            this.groupBox41.SuspendLayout();
            this.GroupBox1.SuspendLayout();
            this.groupBox28.SuspendLayout();
            this.groupBox27.SuspendLayout();
            this.groupBox26.SuspendLayout();
            this.groupBox25.SuspendLayout();
            this.groupBox24.SuspendLayout();
            this.groupBox23.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.groupBox30.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.tabPage4.SuspendLayout();
            this.groupBox48.SuspendLayout();
            this.groupBox51.SuspendLayout();
            this.panel_StaticIp.SuspendLayout();
            this.groupBox50.SuspendLayout();
            this.panel_TCP.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.tcpRemotePortNUD)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tcpLocalPortNUD)).BeginInit();
            this.groupBox49.SuspendLayout();
            this.panel4.SuspendLayout();
            this.groupBox47.SuspendLayout();
            this.TabSheet_EPCC1G2.SuspendLayout();
            this.groupBox31.SuspendLayout();
            this.groupBox40.SuspendLayout();
            this.groupBox18.SuspendLayout();
            this.groupBox16.SuspendLayout();
            this.groupBox17.SuspendLayout();
            this.groupBox15.SuspendLayout();
            this.groupBox14.SuspendLayout();
            this.groupBox13.SuspendLayout();
            this.groupBox12.SuspendLayout();
            this.groupBox45.SuspendLayout();
            this.groupBox7.SuspendLayout();
            this.groupBox11.SuspendLayout();
            this.groupBox10.SuspendLayout();
            this.groupBox8.SuspendLayout();
            this.groupBox9.SuspendLayout();
            this.groupBox5.SuspendLayout();
            this.groupBox6.SuspendLayout();
            this.groupBox4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.TStatusPanel)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Port)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Manufacturername)).BeginInit();
            this.SuspendLayout();
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.TabSheet_CMD);
            this.tabControl1.Controls.Add(this.tabPage4);
            this.tabControl1.Controls.Add(this.TabSheet_EPCC1G2);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Controls.Add(this.TabSheet_6B);
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage3);
            this.tabControl1.Location = new System.Drawing.Point(2, 1);
            this.tabControl1.Multiline = true;
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(825, 704);
            this.tabControl1.TabIndex = 0;
            this.tabControl1.Selecting += new System.Windows.Forms.TabControlCancelEventHandler(this.tabControl1_Selecting);
            // 
            // TabSheet_CMD
            // 
            this.TabSheet_CMD.BackColor = System.Drawing.Color.Transparent;
            this.TabSheet_CMD.Controls.Add(this.groupBox46);
            this.TabSheet_CMD.Controls.Add(this.groupBox42);
            this.TabSheet_CMD.Controls.Add(this.groupBox28);
            this.TabSheet_CMD.Controls.Add(this.groupBox27);
            this.TabSheet_CMD.Controls.Add(this.groupBox26);
            this.TabSheet_CMD.Controls.Add(this.groupBox25);
            this.TabSheet_CMD.Controls.Add(this.groupBox24);
            this.TabSheet_CMD.Controls.Add(this.groupBox23);
            this.TabSheet_CMD.Controls.Add(this.groupBox3);
            this.TabSheet_CMD.Controls.Add(this.groupBox2);
            this.TabSheet_CMD.Location = new System.Drawing.Point(4, 22);
            this.TabSheet_CMD.Name = "TabSheet_CMD";
            this.TabSheet_CMD.Padding = new System.Windows.Forms.Padding(3);
            this.TabSheet_CMD.Size = new System.Drawing.Size(817, 678);
            this.TabSheet_CMD.TabIndex = 1;
            this.TabSheet_CMD.Text = "Reader Parameter";
            this.TabSheet_CMD.UseVisualStyleBackColor = true;
            // 
            // groupBox46
            // 
            this.groupBox46.Controls.Add(this.button26);
            this.groupBox46.Controls.Add(this.textBox14);
            this.groupBox46.Location = new System.Drawing.Point(5, 457);
            this.groupBox46.Name = "groupBox46";
            this.groupBox46.Size = new System.Drawing.Size(136, 76);
            this.groupBox46.TabIndex = 52;
            this.groupBox46.TabStop = false;
            this.groupBox46.Text = "Reader seria number";
            // 
            // button26
            // 
            this.button26.Location = new System.Drawing.Point(71, 46);
            this.button26.Name = "button26";
            this.button26.Size = new System.Drawing.Size(56, 25);
            this.button26.TabIndex = 2;
            this.button26.Text = "Get";
            this.button26.UseVisualStyleBackColor = true;
            this.button26.Click += new System.EventHandler(this.button26_Click);
            // 
            // textBox14
            // 
            this.textBox14.Location = new System.Drawing.Point(9, 18);
            this.textBox14.MaxLength = 8;
            this.textBox14.Name = "textBox14";
            this.textBox14.Size = new System.Drawing.Size(117, 20);
            this.textBox14.TabIndex = 0;
            // 
            // groupBox42
            // 
            this.groupBox42.Controls.Add(this.groupBox41);
            this.groupBox42.Controls.Add(this.radioButton2);
            this.groupBox42.Controls.Add(this.radioButton1);
            this.groupBox42.Controls.Add(this.GroupBox1);
            this.groupBox42.Location = new System.Drawing.Point(6, 7);
            this.groupBox42.Name = "groupBox42";
            this.groupBox42.Size = new System.Drawing.Size(138, 449);
            this.groupBox42.TabIndex = 50;
            this.groupBox42.TabStop = false;
            this.groupBox42.Text = "Communication";
            // 
            // groupBox41
            // 
            this.groupBox41.Controls.Add(this.CloseNetPort);
            this.groupBox41.Controls.Add(this.OpenNetPort);
            this.groupBox41.Controls.Add(this.textBox9);
            this.groupBox41.Controls.Add(this.label63);
            this.groupBox41.Controls.Add(this.textBox8);
            this.groupBox41.Controls.Add(this.label62);
            this.groupBox41.Controls.Add(this.textBox7);
            this.groupBox41.Controls.Add(this.label61);
            this.groupBox41.Location = new System.Drawing.Point(6, 263);
            this.groupBox41.Name = "groupBox41";
            this.groupBox41.Size = new System.Drawing.Size(128, 180);
            this.groupBox41.TabIndex = 50;
            this.groupBox41.TabStop = false;
            this.groupBox41.Text = "TCPIP";
            // 
            // CloseNetPort
            // 
            this.CloseNetPort.Location = new System.Drawing.Point(9, 147);
            this.CloseNetPort.Name = "CloseNetPort";
            this.CloseNetPort.Size = new System.Drawing.Size(113, 25);
            this.CloseNetPort.TabIndex = 7;
            this.CloseNetPort.Text = "CloseNetPort";
            this.CloseNetPort.UseVisualStyleBackColor = true;
            this.CloseNetPort.Click += new System.EventHandler(this.CloseNetPort_Click);
            // 
            // OpenNetPort
            // 
            this.OpenNetPort.Location = new System.Drawing.Point(9, 114);
            this.OpenNetPort.Name = "OpenNetPort";
            this.OpenNetPort.Size = new System.Drawing.Size(113, 25);
            this.OpenNetPort.TabIndex = 6;
            this.OpenNetPort.Text = "OpenNetPort";
            this.OpenNetPort.UseVisualStyleBackColor = true;
            this.OpenNetPort.Click += new System.EventHandler(this.OpenNetPort_Click);
            // 
            // textBox9
            // 
            this.textBox9.Location = new System.Drawing.Point(43, 85);
            this.textBox9.Name = "textBox9";
            this.textBox9.Size = new System.Drawing.Size(78, 20);
            this.textBox9.TabIndex = 5;
            this.textBox9.Text = "FF";
            // 
            // label63
            // 
            this.label63.AutoSize = true;
            this.label63.Location = new System.Drawing.Point(7, 94);
            this.label63.Name = "label63";
            this.label63.Size = new System.Drawing.Size(35, 13);
            this.label63.TabIndex = 4;
            this.label63.Text = "Addr：";
            // 
            // textBox8
            // 
            this.textBox8.Location = new System.Drawing.Point(33, 47);
            this.textBox8.Name = "textBox8";
            this.textBox8.Size = new System.Drawing.Size(88, 20);
            this.textBox8.TabIndex = 3;
            this.textBox8.Text = "192.168.0.250";
            // 
            // label62
            // 
            this.label62.AutoSize = true;
            this.label62.Location = new System.Drawing.Point(7, 56);
            this.label62.Name = "label62";
            this.label62.Size = new System.Drawing.Size(23, 13);
            this.label62.TabIndex = 2;
            this.label62.Text = "IP：";
            // 
            // textBox7
            // 
            this.textBox7.Location = new System.Drawing.Point(40, 17);
            this.textBox7.Name = "textBox7";
            this.textBox7.Size = new System.Drawing.Size(82, 20);
            this.textBox7.TabIndex = 1;
            this.textBox7.Text = "27012";
            // 
            // label61
            // 
            this.label61.AutoSize = true;
            this.label61.Location = new System.Drawing.Point(6, 27);
            this.label61.Name = "label61";
            this.label61.Size = new System.Drawing.Size(29, 13);
            this.label61.TabIndex = 0;
            this.label61.Text = "Port:";
            // 
            // radioButton2
            // 
            this.radioButton2.AutoSize = true;
            this.radioButton2.Location = new System.Drawing.Point(73, 18);
            this.radioButton2.Name = "radioButton2";
            this.radioButton2.Size = new System.Drawing.Size(56, 17);
            this.radioButton2.TabIndex = 43;
            this.radioButton2.TabStop = true;
            this.radioButton2.Text = "TCPIP";
            this.radioButton2.UseVisualStyleBackColor = true;
            this.radioButton2.CheckedChanged += new System.EventHandler(this.radioButton2_CheckedChanged);
            // 
            // radioButton1
            // 
            this.radioButton1.AutoSize = true;
            this.radioButton1.Location = new System.Drawing.Point(13, 18);
            this.radioButton1.Name = "radioButton1";
            this.radioButton1.Size = new System.Drawing.Size(49, 17);
            this.radioButton1.TabIndex = 42;
            this.radioButton1.TabStop = true;
            this.radioButton1.Text = "COM";
            this.radioButton1.UseVisualStyleBackColor = true;
            this.radioButton1.CheckedChanged += new System.EventHandler(this.radioButton1_CheckedChanged);
            // 
            // GroupBox1
            // 
            this.GroupBox1.Controls.Add(this.ComboBox_baud2);
            this.GroupBox1.Controls.Add(this.label47);
            this.GroupBox1.Controls.Add(this.ComboBox_AlreadyOpenCOM);
            this.GroupBox1.Controls.Add(this.label3);
            this.GroupBox1.Controls.Add(this.ClosePort);
            this.GroupBox1.Controls.Add(this.OpenPort);
            this.GroupBox1.Controls.Add(this.Edit_CmdComAddr);
            this.GroupBox1.Controls.Add(this.Label2);
            this.GroupBox1.Controls.Add(this.ComboBox_COM);
            this.GroupBox1.Controls.Add(this.Label1);
            this.GroupBox1.Location = new System.Drawing.Point(6, 35);
            this.GroupBox1.Name = "GroupBox1";
            this.GroupBox1.Size = new System.Drawing.Size(127, 223);
            this.GroupBox1.TabIndex = 41;
            this.GroupBox1.TabStop = false;
            this.GroupBox1.Text = "COM";
            // 
            // ComboBox_baud2
            // 
            this.ComboBox_baud2.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.ComboBox_baud2.FormattingEnabled = true;
            this.ComboBox_baud2.Items.AddRange(new object[] {
            "9600bps",
            "19200bps",
            "38400bps",
            "57600bps",
            "115200bps"});
            this.ComboBox_baud2.Location = new System.Drawing.Point(7, 119);
            this.ComboBox_baud2.Name = "ComboBox_baud2";
            this.ComboBox_baud2.Size = new System.Drawing.Size(113, 21);
            this.ComboBox_baud2.TabIndex = 12;
            // 
            // label47
            // 
            this.label47.AutoSize = true;
            this.label47.Location = new System.Drawing.Point(6, 103);
            this.label47.Name = "label47";
            this.label47.Size = new System.Drawing.Size(38, 13);
            this.label47.TabIndex = 9;
            this.label47.Text = "Baud：";
            // 
            // ComboBox_AlreadyOpenCOM
            // 
            this.ComboBox_AlreadyOpenCOM.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.ComboBox_AlreadyOpenCOM.FormattingEnabled = true;
            this.ComboBox_AlreadyOpenCOM.Location = new System.Drawing.Point(5, 166);
            this.ComboBox_AlreadyOpenCOM.Name = "ComboBox_AlreadyOpenCOM";
            this.ComboBox_AlreadyOpenCOM.Size = new System.Drawing.Size(117, 21);
            this.ComboBox_AlreadyOpenCOM.TabIndex = 7;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(6, 147);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(94, 13);
            this.label3.TabIndex = 6;
            this.label3.Text = "Opened COM Port";
            // 
            // ClosePort
            // 
            this.ClosePort.Location = new System.Drawing.Point(5, 192);
            this.ClosePort.Name = "ClosePort";
            this.ClosePort.Size = new System.Drawing.Size(117, 25);
            this.ClosePort.TabIndex = 5;
            this.ClosePort.Text = "Close COM Port";
            this.ClosePort.UseVisualStyleBackColor = true;
            this.ClosePort.Click += new System.EventHandler(this.ClosePort_Click);
            // 
            // OpenPort
            // 
            this.OpenPort.Location = new System.Drawing.Point(5, 72);
            this.OpenPort.Name = "OpenPort";
            this.OpenPort.Size = new System.Drawing.Size(117, 25);
            this.OpenPort.TabIndex = 4;
            this.OpenPort.Text = "Open COM Port";
            this.OpenPort.UseVisualStyleBackColor = true;
            this.OpenPort.Click += new System.EventHandler(this.OpenPort_Click);
            // 
            // Edit_CmdComAddr
            // 
            this.Edit_CmdComAddr.BackColor = System.Drawing.SystemColors.Window;
            this.Edit_CmdComAddr.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.Edit_CmdComAddr.Location = new System.Drawing.Point(98, 42);
            this.Edit_CmdComAddr.MaxLength = 2;
            this.Edit_CmdComAddr.Name = "Edit_CmdComAddr";
            this.Edit_CmdComAddr.Size = new System.Drawing.Size(24, 20);
            this.Edit_CmdComAddr.TabIndex = 3;
            this.Edit_CmdComAddr.Text = "FF";
            // 
            // Label2
            // 
            this.Label2.AutoSize = true;
            this.Label2.Location = new System.Drawing.Point(6, 46);
            this.Label2.Name = "Label2";
            this.Label2.Size = new System.Drawing.Size(86, 13);
            this.Label2.TabIndex = 2;
            this.Label2.Text = "Reader Address:";
            // 
            // ComboBox_COM
            // 
            this.ComboBox_COM.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.ComboBox_COM.FormattingEnabled = true;
            this.ComboBox_COM.Location = new System.Drawing.Point(65, 14);
            this.ComboBox_COM.Name = "ComboBox_COM";
            this.ComboBox_COM.Size = new System.Drawing.Size(57, 21);
            this.ComboBox_COM.TabIndex = 1;
            this.ComboBox_COM.SelectedIndexChanged += new System.EventHandler(this.ComboBox_COM_SelectedIndexChanged_1);
            // 
            // Label1
            // 
            this.Label1.AutoSize = true;
            this.Label1.Location = new System.Drawing.Point(5, 23);
            this.Label1.Name = "Label1";
            this.Label1.Size = new System.Drawing.Size(59, 13);
            this.Label1.TabIndex = 0;
            this.Label1.Text = "COM Port：";
            // 
            // groupBox28
            // 
            this.groupBox28.Controls.Add(this.Radio_beepDis);
            this.groupBox28.Controls.Add(this.Radio_beepEn);
            this.groupBox28.Controls.Add(this.Button_Beep);
            this.groupBox28.Location = new System.Drawing.Point(317, 481);
            this.groupBox28.Name = "groupBox28";
            this.groupBox28.Size = new System.Drawing.Size(193, 52);
            this.groupBox28.TabIndex = 48;
            this.groupBox28.TabStop = false;
            this.groupBox28.Text = "Beep Operationn";
            // 
            // Radio_beepDis
            // 
            this.Radio_beepDis.AutoSize = true;
            this.Radio_beepDis.Location = new System.Drawing.Point(56, 22);
            this.Radio_beepDis.Name = "Radio_beepDis";
            this.Radio_beepDis.Size = new System.Drawing.Size(39, 17);
            this.Radio_beepDis.TabIndex = 7;
            this.Radio_beepDis.TabStop = true;
            this.Radio_beepDis.Text = "Off";
            this.Radio_beepDis.UseVisualStyleBackColor = true;
            // 
            // Radio_beepEn
            // 
            this.Radio_beepEn.AutoSize = true;
            this.Radio_beepEn.Location = new System.Drawing.Point(10, 22);
            this.Radio_beepEn.Name = "Radio_beepEn";
            this.Radio_beepEn.Size = new System.Drawing.Size(39, 17);
            this.Radio_beepEn.TabIndex = 6;
            this.Radio_beepEn.TabStop = true;
            this.Radio_beepEn.Text = "On";
            this.Radio_beepEn.UseVisualStyleBackColor = true;
            // 
            // Button_Beep
            // 
            this.Button_Beep.Location = new System.Drawing.Point(110, 16);
            this.Button_Beep.Name = "Button_Beep";
            this.Button_Beep.Size = new System.Drawing.Size(75, 25);
            this.Button_Beep.TabIndex = 5;
            this.Button_Beep.Text = "Set";
            this.Button_Beep.UseVisualStyleBackColor = true;
            this.Button_Beep.Click += new System.EventHandler(this.Button_Beep_Click);
            // 
            // groupBox27
            // 
            this.groupBox27.Controls.Add(this.Button_OutputRep);
            this.groupBox27.Controls.Add(this.checkBox14);
            this.groupBox27.Controls.Add(this.checkBox15);
            this.groupBox27.Controls.Add(this.checkBox16);
            this.groupBox27.Controls.Add(this.checkBox17);
            this.groupBox27.Location = new System.Drawing.Point(317, 428);
            this.groupBox27.Name = "groupBox27";
            this.groupBox27.Size = new System.Drawing.Size(299, 51);
            this.groupBox27.TabIndex = 47;
            this.groupBox27.TabStop = false;
            this.groupBox27.Text = "Set Notification Pulse Output";
            // 
            // Button_OutputRep
            // 
            this.Button_OutputRep.Location = new System.Drawing.Point(216, 16);
            this.Button_OutputRep.Name = "Button_OutputRep";
            this.Button_OutputRep.Size = new System.Drawing.Size(75, 25);
            this.Button_OutputRep.TabIndex = 5;
            this.Button_OutputRep.Text = "Set";
            this.Button_OutputRep.UseVisualStyleBackColor = true;
            this.Button_OutputRep.Click += new System.EventHandler(this.Button_OutputRep_Click);
            // 
            // checkBox14
            // 
            this.checkBox14.AutoSize = true;
            this.checkBox14.Location = new System.Drawing.Point(162, 21);
            this.checkBox14.Name = "checkBox14";
            this.checkBox14.Size = new System.Drawing.Size(55, 17);
            this.checkBox14.TabIndex = 4;
            this.checkBox14.Text = "OUT4";
            this.checkBox14.UseVisualStyleBackColor = true;
            // 
            // checkBox15
            // 
            this.checkBox15.AutoSize = true;
            this.checkBox15.Location = new System.Drawing.Point(110, 21);
            this.checkBox15.Name = "checkBox15";
            this.checkBox15.Size = new System.Drawing.Size(55, 17);
            this.checkBox15.TabIndex = 3;
            this.checkBox15.Text = "OUT3";
            this.checkBox15.UseVisualStyleBackColor = true;
            // 
            // checkBox16
            // 
            this.checkBox16.AutoSize = true;
            this.checkBox16.Location = new System.Drawing.Point(57, 21);
            this.checkBox16.Name = "checkBox16";
            this.checkBox16.Size = new System.Drawing.Size(55, 17);
            this.checkBox16.TabIndex = 2;
            this.checkBox16.Text = "OUT2";
            this.checkBox16.UseVisualStyleBackColor = true;
            // 
            // checkBox17
            // 
            this.checkBox17.AutoSize = true;
            this.checkBox17.Location = new System.Drawing.Point(8, 21);
            this.checkBox17.Name = "checkBox17";
            this.checkBox17.Size = new System.Drawing.Size(55, 17);
            this.checkBox17.TabIndex = 1;
            this.checkBox17.Text = "OUT1";
            this.checkBox17.UseVisualStyleBackColor = true;
            // 
            // groupBox26
            // 
            this.groupBox26.Controls.Add(this.ClockCMD);
            this.groupBox26.Controls.Add(this.GetClock);
            this.groupBox26.Controls.Add(this.SetClock);
            this.groupBox26.Controls.Add(this.label39);
            this.groupBox26.Controls.Add(this.label40);
            this.groupBox26.Controls.Add(this.label41);
            this.groupBox26.Controls.Add(this.label42);
            this.groupBox26.Controls.Add(this.label45);
            this.groupBox26.Controls.Add(this.Text_sec);
            this.groupBox26.Controls.Add(this.Text_min);
            this.groupBox26.Controls.Add(this.Text_hour);
            this.groupBox26.Controls.Add(this.Text_day);
            this.groupBox26.Controls.Add(this.Text_month);
            this.groupBox26.Controls.Add(this.label46);
            this.groupBox26.Controls.Add(this.Text_year);
            this.groupBox26.Controls.Add(this.TextBox5);
            this.groupBox26.Location = new System.Drawing.Point(147, 428);
            this.groupBox26.Name = "groupBox26";
            this.groupBox26.Size = new System.Drawing.Size(163, 105);
            this.groupBox26.TabIndex = 46;
            this.groupBox26.TabStop = false;
            this.groupBox26.Text = "Real Time Clock Setting";
            // 
            // ClockCMD
            // 
            this.ClockCMD.Location = new System.Drawing.Point(94, 67);
            this.ClockCMD.Name = "ClockCMD";
            this.ClockCMD.Size = new System.Drawing.Size(62, 30);
            this.ClockCMD.TabIndex = 15;
            this.ClockCMD.Text = "Go";
            this.ClockCMD.UseVisualStyleBackColor = true;
            this.ClockCMD.Click += new System.EventHandler(this.ClockCMD_Click);
            // 
            // GetClock
            // 
            this.GetClock.AutoSize = true;
            this.GetClock.Location = new System.Drawing.Point(3, 83);
            this.GetClock.Name = "GetClock";
            this.GetClock.Size = new System.Drawing.Size(83, 17);
            this.GetClock.TabIndex = 14;
            this.GetClock.TabStop = true;
            this.GetClock.Text = "Query Clock";
            this.GetClock.UseVisualStyleBackColor = true;
            // 
            // SetClock
            // 
            this.SetClock.AutoSize = true;
            this.SetClock.Location = new System.Drawing.Point(3, 65);
            this.SetClock.Name = "SetClock";
            this.SetClock.Size = new System.Drawing.Size(71, 17);
            this.SetClock.TabIndex = 13;
            this.SetClock.TabStop = true;
            this.SetClock.Text = "Set Clock";
            this.SetClock.UseVisualStyleBackColor = true;
            // 
            // label39
            // 
            this.label39.AutoSize = true;
            this.label39.Location = new System.Drawing.Point(137, 20);
            this.label39.Name = "label39";
            this.label39.Size = new System.Drawing.Size(26, 13);
            this.label39.TabIndex = 12;
            this.label39.Text = "Sec";
            // 
            // label40
            // 
            this.label40.AutoSize = true;
            this.label40.Location = new System.Drawing.Point(116, 20);
            this.label40.Name = "label40";
            this.label40.Size = new System.Drawing.Size(24, 13);
            this.label40.TabIndex = 11;
            this.label40.Text = "Min";
            // 
            // label41
            // 
            this.label41.AutoSize = true;
            this.label41.Location = new System.Drawing.Point(90, 20);
            this.label41.Name = "label41";
            this.label41.Size = new System.Drawing.Size(30, 13);
            this.label41.TabIndex = 10;
            this.label41.Text = "Hour";
            // 
            // label42
            // 
            this.label42.AutoSize = true;
            this.label42.Location = new System.Drawing.Point(68, 20);
            this.label42.Name = "label42";
            this.label42.Size = new System.Drawing.Size(26, 13);
            this.label42.TabIndex = 9;
            this.label42.Text = "Day";
            // 
            // label45
            // 
            this.label45.AutoSize = true;
            this.label45.Location = new System.Drawing.Point(34, 20);
            this.label45.Name = "label45";
            this.label45.Size = new System.Drawing.Size(37, 13);
            this.label45.TabIndex = 8;
            this.label45.Text = "Month";
            // 
            // Text_sec
            // 
            this.Text_sec.Location = new System.Drawing.Point(140, 36);
            this.Text_sec.MaxLength = 2;
            this.Text_sec.Name = "Text_sec";
            this.Text_sec.Size = new System.Drawing.Size(20, 20);
            this.Text_sec.TabIndex = 7;
            // 
            // Text_min
            // 
            this.Text_min.Location = new System.Drawing.Point(117, 36);
            this.Text_min.MaxLength = 2;
            this.Text_min.Name = "Text_min";
            this.Text_min.Size = new System.Drawing.Size(20, 20);
            this.Text_min.TabIndex = 6;
            // 
            // Text_hour
            // 
            this.Text_hour.Location = new System.Drawing.Point(92, 36);
            this.Text_hour.MaxLength = 2;
            this.Text_hour.Name = "Text_hour";
            this.Text_hour.Size = new System.Drawing.Size(20, 20);
            this.Text_hour.TabIndex = 5;
            // 
            // Text_day
            // 
            this.Text_day.Location = new System.Drawing.Point(67, 36);
            this.Text_day.MaxLength = 2;
            this.Text_day.Name = "Text_day";
            this.Text_day.Size = new System.Drawing.Size(20, 20);
            this.Text_day.TabIndex = 4;
            // 
            // Text_month
            // 
            this.Text_month.Location = new System.Drawing.Point(42, 36);
            this.Text_month.MaxLength = 2;
            this.Text_month.Name = "Text_month";
            this.Text_month.Size = new System.Drawing.Size(20, 20);
            this.Text_month.TabIndex = 3;
            // 
            // label46
            // 
            this.label46.AutoSize = true;
            this.label46.Location = new System.Drawing.Point(6, 20);
            this.label46.Name = "label46";
            this.label46.Size = new System.Drawing.Size(29, 13);
            this.label46.TabIndex = 2;
            this.label46.Text = "Year";
            // 
            // Text_year
            // 
            this.Text_year.Location = new System.Drawing.Point(18, 36);
            this.Text_year.MaxLength = 2;
            this.Text_year.Name = "Text_year";
            this.Text_year.Size = new System.Drawing.Size(20, 20);
            this.Text_year.TabIndex = 1;
            // 
            // TextBox5
            // 
            this.TextBox5.Location = new System.Drawing.Point(1, 36);
            this.TextBox5.Name = "TextBox5";
            this.TextBox5.ReadOnly = true;
            this.TextBox5.Size = new System.Drawing.Size(17, 20);
            this.TextBox5.TabIndex = 0;
            this.TextBox5.Text = "20";
            // 
            // groupBox25
            // 
            this.groupBox25.Controls.Add(this.Button_RelayTime);
            this.groupBox25.Controls.Add(this.label38);
            this.groupBox25.Controls.Add(this.ComboBox_RelayTime);
            this.groupBox25.Controls.Add(this.label37);
            this.groupBox25.Location = new System.Drawing.Point(485, 365);
            this.groupBox25.Name = "groupBox25";
            this.groupBox25.Size = new System.Drawing.Size(323, 56);
            this.groupBox25.TabIndex = 45;
            this.groupBox25.TabStop = false;
            this.groupBox25.Text = "Relay control ";
            // 
            // Button_RelayTime
            // 
            this.Button_RelayTime.Location = new System.Drawing.Point(242, 17);
            this.Button_RelayTime.Name = "Button_RelayTime";
            this.Button_RelayTime.Size = new System.Drawing.Size(75, 25);
            this.Button_RelayTime.TabIndex = 3;
            this.Button_RelayTime.Text = "Set";
            this.Button_RelayTime.UseVisualStyleBackColor = true;
            this.Button_RelayTime.Click += new System.EventHandler(this.Button_RelayTime_Click);
            // 
            // label38
            // 
            this.label38.AutoSize = true;
            this.label38.Location = new System.Drawing.Point(200, 23);
            this.label38.Name = "label38";
            this.label38.Size = new System.Drawing.Size(36, 13);
            this.label38.TabIndex = 2;
            this.label38.Text = "*50ms";
            // 
            // ComboBox_RelayTime
            // 
            this.ComboBox_RelayTime.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.ComboBox_RelayTime.FormattingEnabled = true;
            this.ComboBox_RelayTime.Location = new System.Drawing.Point(86, 20);
            this.ComboBox_RelayTime.Name = "ComboBox_RelayTime";
            this.ComboBox_RelayTime.Size = new System.Drawing.Size(113, 21);
            this.ComboBox_RelayTime.TabIndex = 1;
            // 
            // label37
            // 
            this.label37.AutoSize = true;
            this.label37.Location = new System.Drawing.Point(8, 24);
            this.label37.Name = "label37";
            this.label37.Size = new System.Drawing.Size(75, 13);
            this.label37.TabIndex = 0;
            this.label37.Text = "ReleaseTime：";
            // 
            // groupBox24
            // 
            this.groupBox24.Controls.Add(this.Button_Ant);
            this.groupBox24.Controls.Add(this.checkBox13);
            this.groupBox24.Controls.Add(this.checkBox12);
            this.groupBox24.Controls.Add(this.checkBox11);
            this.groupBox24.Controls.Add(this.checkBox10);
            this.groupBox24.Location = new System.Drawing.Point(147, 365);
            this.groupBox24.Name = "groupBox24";
            this.groupBox24.Size = new System.Drawing.Size(333, 56);
            this.groupBox24.TabIndex = 44;
            this.groupBox24.TabStop = false;
            this.groupBox24.Text = "Antenna configuration ";
            // 
            // Button_Ant
            // 
            this.Button_Ant.Location = new System.Drawing.Point(248, 17);
            this.Button_Ant.Name = "Button_Ant";
            this.Button_Ant.Size = new System.Drawing.Size(75, 25);
            this.Button_Ant.TabIndex = 5;
            this.Button_Ant.Text = "Set";
            this.Button_Ant.UseVisualStyleBackColor = true;
            this.Button_Ant.Click += new System.EventHandler(this.Button_Ant_Click);
            // 
            // checkBox13
            // 
            this.checkBox13.AutoSize = true;
            this.checkBox13.Location = new System.Drawing.Point(188, 23);
            this.checkBox13.Name = "checkBox13";
            this.checkBox13.Size = new System.Drawing.Size(54, 17);
            this.checkBox13.TabIndex = 4;
            this.checkBox13.Text = "ANT4";
            this.checkBox13.UseVisualStyleBackColor = true;
            // 
            // checkBox12
            // 
            this.checkBox12.AutoSize = true;
            this.checkBox12.Location = new System.Drawing.Point(128, 23);
            this.checkBox12.Name = "checkBox12";
            this.checkBox12.Size = new System.Drawing.Size(54, 17);
            this.checkBox12.TabIndex = 3;
            this.checkBox12.Text = "ANT3";
            this.checkBox12.UseVisualStyleBackColor = true;
            // 
            // checkBox11
            // 
            this.checkBox11.AutoSize = true;
            this.checkBox11.Location = new System.Drawing.Point(68, 23);
            this.checkBox11.Name = "checkBox11";
            this.checkBox11.Size = new System.Drawing.Size(54, 17);
            this.checkBox11.TabIndex = 2;
            this.checkBox11.Text = "ANT2";
            this.checkBox11.UseVisualStyleBackColor = true;
            // 
            // checkBox10
            // 
            this.checkBox10.AutoSize = true;
            this.checkBox10.Location = new System.Drawing.Point(8, 23);
            this.checkBox10.Name = "checkBox10";
            this.checkBox10.Size = new System.Drawing.Size(54, 17);
            this.checkBox10.TabIndex = 1;
            this.checkBox10.Text = "ANT1";
            this.checkBox10.UseVisualStyleBackColor = true;
            // 
            // groupBox23
            // 
            this.groupBox23.Controls.Add(this.Button_GetGPIO);
            this.groupBox23.Controls.Add(this.Button_SetGPIO);
            this.groupBox23.Controls.Add(this.checkBox9);
            this.groupBox23.Controls.Add(this.checkBox8);
            this.groupBox23.Controls.Add(this.checkBox7);
            this.groupBox23.Controls.Add(this.checkBox6);
            this.groupBox23.Controls.Add(this.checkBox5);
            this.groupBox23.Controls.Add(this.checkBox4);
            this.groupBox23.Controls.Add(this.checkBox3);
            this.groupBox23.Controls.Add(this.checkBox2);
            this.groupBox23.Location = new System.Drawing.Point(147, 304);
            this.groupBox23.Name = "groupBox23";
            this.groupBox23.Size = new System.Drawing.Size(663, 54);
            this.groupBox23.TabIndex = 43;
            this.groupBox23.TabStop = false;
            this.groupBox23.Text = "GPIO Operation";
            // 
            // Button_GetGPIO
            // 
            this.Button_GetGPIO.Location = new System.Drawing.Point(580, 17);
            this.Button_GetGPIO.Name = "Button_GetGPIO";
            this.Button_GetGPIO.Size = new System.Drawing.Size(75, 25);
            this.Button_GetGPIO.TabIndex = 9;
            this.Button_GetGPIO.Text = "Get";
            this.Button_GetGPIO.UseVisualStyleBackColor = true;
            this.Button_GetGPIO.Click += new System.EventHandler(this.Button_GetGPIO_Click);
            // 
            // Button_SetGPIO
            // 
            this.Button_SetGPIO.Location = new System.Drawing.Point(483, 17);
            this.Button_SetGPIO.Name = "Button_SetGPIO";
            this.Button_SetGPIO.Size = new System.Drawing.Size(75, 25);
            this.Button_SetGPIO.TabIndex = 8;
            this.Button_SetGPIO.Text = "Set";
            this.Button_SetGPIO.UseVisualStyleBackColor = true;
            this.Button_SetGPIO.Click += new System.EventHandler(this.Button_SetGPIO_Click);
            // 
            // checkBox9
            // 
            this.checkBox9.AutoSize = true;
            this.checkBox9.Location = new System.Drawing.Point(392, 22);
            this.checkBox9.Name = "checkBox9";
            this.checkBox9.Size = new System.Drawing.Size(47, 17);
            this.checkBox9.TabIndex = 7;
            this.checkBox9.Text = "Pin8";
            this.checkBox9.UseVisualStyleBackColor = true;
            // 
            // checkBox8
            // 
            this.checkBox8.AutoSize = true;
            this.checkBox8.Location = new System.Drawing.Point(338, 22);
            this.checkBox8.Name = "checkBox8";
            this.checkBox8.Size = new System.Drawing.Size(47, 17);
            this.checkBox8.TabIndex = 6;
            this.checkBox8.Text = "Pin7";
            this.checkBox8.UseVisualStyleBackColor = true;
            // 
            // checkBox7
            // 
            this.checkBox7.AutoSize = true;
            this.checkBox7.Location = new System.Drawing.Point(281, 22);
            this.checkBox7.Name = "checkBox7";
            this.checkBox7.Size = new System.Drawing.Size(47, 17);
            this.checkBox7.TabIndex = 5;
            this.checkBox7.Text = "Pin6";
            this.checkBox7.UseVisualStyleBackColor = true;
            // 
            // checkBox6
            // 
            this.checkBox6.AutoSize = true;
            this.checkBox6.Location = new System.Drawing.Point(227, 22);
            this.checkBox6.Name = "checkBox6";
            this.checkBox6.Size = new System.Drawing.Size(47, 17);
            this.checkBox6.TabIndex = 4;
            this.checkBox6.Text = "Pin5";
            this.checkBox6.UseVisualStyleBackColor = true;
            // 
            // checkBox5
            // 
            this.checkBox5.AutoSize = true;
            this.checkBox5.Location = new System.Drawing.Point(170, 22);
            this.checkBox5.Name = "checkBox5";
            this.checkBox5.Size = new System.Drawing.Size(47, 17);
            this.checkBox5.TabIndex = 3;
            this.checkBox5.Text = "Pin4";
            this.checkBox5.UseVisualStyleBackColor = true;
            // 
            // checkBox4
            // 
            this.checkBox4.AutoSize = true;
            this.checkBox4.Location = new System.Drawing.Point(116, 22);
            this.checkBox4.Name = "checkBox4";
            this.checkBox4.Size = new System.Drawing.Size(47, 17);
            this.checkBox4.TabIndex = 2;
            this.checkBox4.Text = "Pin3";
            this.checkBox4.UseVisualStyleBackColor = true;
            // 
            // checkBox3
            // 
            this.checkBox3.AutoSize = true;
            this.checkBox3.Location = new System.Drawing.Point(62, 22);
            this.checkBox3.Name = "checkBox3";
            this.checkBox3.Size = new System.Drawing.Size(47, 17);
            this.checkBox3.TabIndex = 1;
            this.checkBox3.Text = "Pin2";
            this.checkBox3.UseVisualStyleBackColor = true;
            // 
            // checkBox2
            // 
            this.checkBox2.AutoSize = true;
            this.checkBox2.Location = new System.Drawing.Point(8, 22);
            this.checkBox2.Name = "checkBox2";
            this.checkBox2.Size = new System.Drawing.Size(47, 17);
            this.checkBox2.TabIndex = 0;
            this.checkBox2.Text = "Pin1";
            this.checkBox2.UseVisualStyleBackColor = true;
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.groupBox30);
            this.groupBox3.Controls.Add(this.progressBar1);
            this.groupBox3.Controls.Add(this.Button1);
            this.groupBox3.Controls.Add(this.Button5);
            this.groupBox3.Controls.Add(this.ComboBox_scantime);
            this.groupBox3.Controls.Add(this.ComboBox_baud);
            this.groupBox3.Controls.Add(this.CheckBox_SameFre);
            this.groupBox3.Controls.Add(this.label17);
            this.groupBox3.Controls.Add(this.label16);
            this.groupBox3.Controls.Add(this.ComboBox_dmaxfre);
            this.groupBox3.Controls.Add(this.ComboBox_dminfre);
            this.groupBox3.Controls.Add(this.ComboBox_PowerDbm);
            this.groupBox3.Controls.Add(this.Edit_NewComAdr);
            this.groupBox3.Controls.Add(this.label15);
            this.groupBox3.Controls.Add(this.label14);
            this.groupBox3.Controls.Add(this.label13);
            this.groupBox3.Controls.Add(this.label12);
            this.groupBox3.Location = new System.Drawing.Point(147, 139);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(663, 159);
            this.groupBox3.TabIndex = 42;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Set Reader Parameter";
            // 
            // groupBox30
            // 
            this.groupBox30.Controls.Add(this.radioButton_band5);
            this.groupBox30.Controls.Add(this.radioButton_band4);
            this.groupBox30.Controls.Add(this.radioButton_band3);
            this.groupBox30.Controls.Add(this.radioButton_band2);
            this.groupBox30.Controls.Add(this.radioButton_band1);
            this.groupBox30.Location = new System.Drawing.Point(475, 15);
            this.groupBox30.Name = "groupBox30";
            this.groupBox30.Size = new System.Drawing.Size(180, 96);
            this.groupBox30.TabIndex = 44;
            this.groupBox30.TabStop = false;
            this.groupBox30.Text = "FreqBaud";
            // 
            // radioButton_band5
            // 
            this.radioButton_band5.AutoSize = true;
            this.radioButton_band5.Location = new System.Drawing.Point(6, 76);
            this.radioButton_band5.Name = "radioButton_band5";
            this.radioButton_band5.Size = new System.Drawing.Size(67, 17);
            this.radioButton_band5.TabIndex = 4;
            this.radioButton_band5.TabStop = true;
            this.radioButton_band5.Text = "EU band";
            this.radioButton_band5.UseVisualStyleBackColor = true;
            this.radioButton_band5.CheckedChanged += new System.EventHandler(this.radioButton21_CheckedChanged);
            // 
            // radioButton_band4
            // 
            this.radioButton_band4.AutoSize = true;
            this.radioButton_band4.Location = new System.Drawing.Point(6, 59);
            this.radioButton_band4.Name = "radioButton_band4";
            this.radioButton_band4.Size = new System.Drawing.Size(86, 17);
            this.radioButton_band4.TabIndex = 3;
            this.radioButton_band4.TabStop = true;
            this.radioButton_band4.Text = "Korean band";
            this.radioButton_band4.UseVisualStyleBackColor = true;
            this.radioButton_band4.CheckedChanged += new System.EventHandler(this.radioButton_band4_CheckedChanged);
            // 
            // radioButton_band3
            // 
            this.radioButton_band3.AutoSize = true;
            this.radioButton_band3.Location = new System.Drawing.Point(6, 43);
            this.radioButton_band3.Name = "radioButton_band3";
            this.radioButton_band3.Size = new System.Drawing.Size(67, 17);
            this.radioButton_band3.TabIndex = 2;
            this.radioButton_band3.TabStop = true;
            this.radioButton_band3.Text = "US band";
            this.radioButton_band3.UseVisualStyleBackColor = true;
            this.radioButton_band3.CheckedChanged += new System.EventHandler(this.radioButton_band3_CheckedChanged);
            // 
            // radioButton_band2
            // 
            this.radioButton_band2.AutoSize = true;
            this.radioButton_band2.Location = new System.Drawing.Point(6, 28);
            this.radioButton_band2.Name = "radioButton_band2";
            this.radioButton_band2.Size = new System.Drawing.Size(96, 17);
            this.radioButton_band2.TabIndex = 1;
            this.radioButton_band2.TabStop = true;
            this.radioButton_band2.Text = "Chinese band2";
            this.radioButton_band2.UseVisualStyleBackColor = true;
            this.radioButton_band2.CheckedChanged += new System.EventHandler(this.radioButton_band2_CheckedChanged);
            // 
            // radioButton_band1
            // 
            this.radioButton_band1.AutoSize = true;
            this.radioButton_band1.Location = new System.Drawing.Point(6, 13);
            this.radioButton_band1.Name = "radioButton_band1";
            this.radioButton_band1.Size = new System.Drawing.Size(74, 17);
            this.radioButton_band1.TabIndex = 0;
            this.radioButton_band1.TabStop = true;
            this.radioButton_band1.Text = "User band";
            this.radioButton_band1.UseVisualStyleBackColor = true;
            this.radioButton_band1.CheckedChanged += new System.EventHandler(this.radioButton_band1_CheckedChanged);
            // 
            // progressBar1
            // 
            this.progressBar1.Location = new System.Drawing.Point(101, 118);
            this.progressBar1.Name = "progressBar1";
            this.progressBar1.Size = new System.Drawing.Size(399, 25);
            this.progressBar1.TabIndex = 43;
            // 
            // Button1
            // 
            this.Button1.Location = new System.Drawing.Point(538, 125);
            this.Button1.Name = "Button1";
            this.Button1.Size = new System.Drawing.Size(118, 25);
            this.Button1.TabIndex = 14;
            this.Button1.Text = "Default Parameter";
            this.Button1.UseVisualStyleBackColor = true;
            this.Button1.Click += new System.EventHandler(this.Button1_Click);
            // 
            // Button5
            // 
            this.Button5.Location = new System.Drawing.Point(404, 125);
            this.Button5.Name = "Button5";
            this.Button5.Size = new System.Drawing.Size(121, 25);
            this.Button5.TabIndex = 13;
            this.Button5.Text = "Set Parameter";
            this.Button5.UseVisualStyleBackColor = true;
            this.Button5.Click += new System.EventHandler(this.Button5_Click);
            // 
            // ComboBox_scantime
            // 
            this.ComboBox_scantime.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.ComboBox_scantime.FormattingEnabled = true;
            this.ComboBox_scantime.Location = new System.Drawing.Point(348, 60);
            this.ComboBox_scantime.Name = "ComboBox_scantime";
            this.ComboBox_scantime.Size = new System.Drawing.Size(121, 21);
            this.ComboBox_scantime.TabIndex = 12;
            // 
            // ComboBox_baud
            // 
            this.ComboBox_baud.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.ComboBox_baud.FormattingEnabled = true;
            this.ComboBox_baud.Items.AddRange(new object[] {
            "9600bps",
            "19200bps",
            "38400bps",
            "57600bps",
            "115200bps"});
            this.ComboBox_baud.Location = new System.Drawing.Point(348, 22);
            this.ComboBox_baud.Name = "ComboBox_baud";
            this.ComboBox_baud.Size = new System.Drawing.Size(121, 21);
            this.ComboBox_baud.TabIndex = 11;
            // 
            // CheckBox_SameFre
            // 
            this.CheckBox_SameFre.AutoSize = true;
            this.CheckBox_SameFre.Location = new System.Drawing.Point(215, 95);
            this.CheckBox_SameFre.Name = "CheckBox_SameFre";
            this.CheckBox_SameFre.Size = new System.Drawing.Size(79, 17);
            this.CheckBox_SameFre.TabIndex = 10;
            this.CheckBox_SameFre.Text = "Single Freq";
            this.CheckBox_SameFre.UseVisualStyleBackColor = true;
            this.CheckBox_SameFre.CheckedChanged += new System.EventHandler(this.CheckBox_SameFre_CheckedChanged);
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(213, 63);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(128, 13);
            this.label17.TabIndex = 9;
            this.label17.Text = "Max InventoryScanTime::";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(213, 29);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(38, 13);
            this.label16.TabIndex = 8;
            this.label16.Text = "Baud：";
            // 
            // ComboBox_dmaxfre
            // 
            this.ComboBox_dmaxfre.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.ComboBox_dmaxfre.FormattingEnabled = true;
            this.ComboBox_dmaxfre.Location = new System.Drawing.Point(95, 127);
            this.ComboBox_dmaxfre.Name = "ComboBox_dmaxfre";
            this.ComboBox_dmaxfre.Size = new System.Drawing.Size(100, 21);
            this.ComboBox_dmaxfre.TabIndex = 7;
            this.ComboBox_dmaxfre.SelectedIndexChanged += new System.EventHandler(this.ComboBox_dfreSelect);
            // 
            // ComboBox_dminfre
            // 
            this.ComboBox_dminfre.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.ComboBox_dminfre.FormattingEnabled = true;
            this.ComboBox_dminfre.Location = new System.Drawing.Point(95, 93);
            this.ComboBox_dminfre.Name = "ComboBox_dminfre";
            this.ComboBox_dminfre.Size = new System.Drawing.Size(100, 21);
            this.ComboBox_dminfre.TabIndex = 6;
            this.ComboBox_dminfre.SelectedIndexChanged += new System.EventHandler(this.ComboBox_dfreSelect);
            // 
            // ComboBox_PowerDbm
            // 
            this.ComboBox_PowerDbm.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.ComboBox_PowerDbm.FormattingEnabled = true;
            this.ComboBox_PowerDbm.Items.AddRange(new object[] {
            "0",
            "1",
            "2",
            "3",
            "4",
            "5",
            "6",
            "7",
            "8",
            "9",
            "10",
            "11",
            "12",
            "13",
            "14",
            "15",
            "16",
            "17",
            "18",
            "19",
            "20",
            "21",
            "22",
            "23",
            "24",
            "25",
            "26",
            "27",
            "28",
            "29",
            "30"});
            this.ComboBox_PowerDbm.Location = new System.Drawing.Point(95, 60);
            this.ComboBox_PowerDbm.Name = "ComboBox_PowerDbm";
            this.ComboBox_PowerDbm.Size = new System.Drawing.Size(100, 21);
            this.ComboBox_PowerDbm.TabIndex = 5;
            // 
            // Edit_NewComAdr
            // 
            this.Edit_NewComAdr.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.Edit_NewComAdr.Location = new System.Drawing.Point(95, 22);
            this.Edit_NewComAdr.MaxLength = 2;
            this.Edit_NewComAdr.Name = "Edit_NewComAdr";
            this.Edit_NewComAdr.Size = new System.Drawing.Size(100, 20);
            this.Edit_NewComAdr.TabIndex = 4;
            this.Edit_NewComAdr.Text = "00";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(6, 130);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(52, 13);
            this.label15.TabIndex = 3;
            this.label15.Text = "Dmaxfre：";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(6, 96);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(54, 13);
            this.label14.TabIndex = 2;
            this.label14.Text = "Dminxfre：";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(6, 63);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(40, 13);
            this.label13.TabIndex = 1;
            this.label13.Text = "Power:";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(6, 29);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(76, 13);
            this.label12.TabIndex = 0;
            this.label12.Text = "Address(HEX):";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.Button3);
            this.groupBox2.Controls.Add(this.Edit_scantime);
            this.groupBox2.Controls.Add(this.EPCC1G2);
            this.groupBox2.Controls.Add(this.ISO180006B);
            this.groupBox2.Controls.Add(this.label11);
            this.groupBox2.Controls.Add(this.label10);
            this.groupBox2.Controls.Add(this.Edit_dmaxfre);
            this.groupBox2.Controls.Add(this.Edit_powerdBm);
            this.groupBox2.Controls.Add(this.Edit_Version);
            this.groupBox2.Controls.Add(this.label9);
            this.groupBox2.Controls.Add(this.label8);
            this.groupBox2.Controls.Add(this.label7);
            this.groupBox2.Controls.Add(this.Edit_dminfre);
            this.groupBox2.Controls.Add(this.Edit_ComAdr);
            this.groupBox2.Controls.Add(this.Edit_Type);
            this.groupBox2.Controls.Add(this.label6);
            this.groupBox2.Controls.Add(this.label5);
            this.groupBox2.Controls.Add(this.label4);
            this.groupBox2.Location = new System.Drawing.Point(147, 7);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(663, 129);
            this.groupBox2.TabIndex = 41;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Reader Information";
            // 
            // Button3
            // 
            this.Button3.Location = new System.Drawing.Point(538, 98);
            this.Button3.Name = "Button3";
            this.Button3.Size = new System.Drawing.Size(118, 25);
            this.Button3.TabIndex = 17;
            this.Button3.Text = "Get Reader Info";
            this.Button3.UseVisualStyleBackColor = true;
            this.Button3.Click += new System.EventHandler(this.Button3_Click);
            // 
            // Edit_scantime
            // 
            this.Edit_scantime.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.Edit_scantime.Location = new System.Drawing.Point(538, 59);
            this.Edit_scantime.Name = "Edit_scantime";
            this.Edit_scantime.Size = new System.Drawing.Size(118, 20);
            this.Edit_scantime.TabIndex = 16;
            // 
            // EPCC1G2
            // 
            this.EPCC1G2.AutoSize = true;
            this.EPCC1G2.Location = new System.Drawing.Point(538, 35);
            this.EPCC1G2.Name = "EPCC1G2";
            this.EPCC1G2.Size = new System.Drawing.Size(77, 17);
            this.EPCC1G2.TabIndex = 15;
            this.EPCC1G2.Text = "EPCC1-G2";
            this.EPCC1G2.UseVisualStyleBackColor = true;
            // 
            // ISO180006B
            // 
            this.ISO180006B.AutoSize = true;
            this.ISO180006B.Location = new System.Drawing.Point(538, 14);
            this.ISO180006B.Name = "ISO180006B";
            this.ISO180006B.Size = new System.Drawing.Size(90, 17);
            this.ISO180006B.TabIndex = 14;
            this.ISO180006B.Text = "ISO18000-6B";
            this.ISO180006B.UseVisualStyleBackColor = true;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(402, 63);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(125, 13);
            this.label11.TabIndex = 13;
            this.label11.Text = "Max InventoryScanTime:";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(402, 23);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(43, 13);
            this.label10.TabIndex = 12;
            this.label10.Text = "Protocl:";
            // 
            // Edit_dmaxfre
            // 
            this.Edit_dmaxfre.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.Edit_dmaxfre.Location = new System.Drawing.Point(286, 100);
            this.Edit_dmaxfre.Name = "Edit_dmaxfre";
            this.Edit_dmaxfre.Size = new System.Drawing.Size(100, 20);
            this.Edit_dmaxfre.TabIndex = 11;
            // 
            // Edit_powerdBm
            // 
            this.Edit_powerdBm.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.Edit_powerdBm.Location = new System.Drawing.Point(286, 60);
            this.Edit_powerdBm.Name = "Edit_powerdBm";
            this.Edit_powerdBm.Size = new System.Drawing.Size(100, 20);
            this.Edit_powerdBm.TabIndex = 10;
            // 
            // Edit_Version
            // 
            this.Edit_Version.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.Edit_Version.Location = new System.Drawing.Point(286, 20);
            this.Edit_Version.Name = "Edit_Version";
            this.Edit_Version.Size = new System.Drawing.Size(100, 20);
            this.Edit_Version.TabIndex = 9;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(197, 103);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(52, 13);
            this.label9.TabIndex = 8;
            this.label9.Text = "Dmaxfre：";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(197, 63);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(40, 13);
            this.label8.TabIndex = 7;
            this.label8.Text = "Power:";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(197, 23);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(45, 13);
            this.label7.TabIndex = 6;
            this.label7.Text = "Version:";
            // 
            // Edit_dminfre
            // 
            this.Edit_dminfre.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.Edit_dminfre.Location = new System.Drawing.Point(95, 100);
            this.Edit_dminfre.Name = "Edit_dminfre";
            this.Edit_dminfre.Size = new System.Drawing.Size(85, 20);
            this.Edit_dminfre.TabIndex = 5;
            // 
            // Edit_ComAdr
            // 
            this.Edit_ComAdr.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.Edit_ComAdr.Location = new System.Drawing.Point(95, 60);
            this.Edit_ComAdr.Name = "Edit_ComAdr";
            this.Edit_ComAdr.Size = new System.Drawing.Size(85, 20);
            this.Edit_ComAdr.TabIndex = 4;
            // 
            // Edit_Type
            // 
            this.Edit_Type.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.Edit_Type.Location = new System.Drawing.Point(95, 20);
            this.Edit_Type.Name = "Edit_Type";
            this.Edit_Type.Size = new System.Drawing.Size(85, 20);
            this.Edit_Type.TabIndex = 3;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(6, 103);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(54, 13);
            this.label6.TabIndex = 2;
            this.label6.Text = "Dminxfre：";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(6, 63);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(48, 13);
            this.label5.TabIndex = 1;
            this.label5.Text = "Address:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(6, 23);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(34, 13);
            this.label4.TabIndex = 0;
            this.label4.Text = "Type:";
            // 
            // tabPage4
            // 
            this.tabPage4.Controls.Add(this.button37);
            this.tabPage4.Controls.Add(this.button25);
            this.tabPage4.Controls.Add(this.groupBox48);
            this.tabPage4.Controls.Add(this.groupBox51);
            this.tabPage4.Controls.Add(this.groupBox50);
            this.tabPage4.Controls.Add(this.groupBox49);
            this.tabPage4.Controls.Add(this.groupBox47);
            this.tabPage4.Location = new System.Drawing.Point(4, 22);
            this.tabPage4.Name = "tabPage4";
            this.tabPage4.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage4.Size = new System.Drawing.Size(817, 678);
            this.tabPage4.TabIndex = 7;
            this.tabPage4.Text = "TCPIP Serial Config";
            this.tabPage4.UseVisualStyleBackColor = true;
            // 
            // button37
            // 
            this.button37.Location = new System.Drawing.Point(554, 472);
            this.button37.Name = "button37";
            this.button37.Size = new System.Drawing.Size(121, 25);
            this.button37.TabIndex = 64;
            this.button37.Text = "Load default value";
            this.button37.UseVisualStyleBackColor = true;
            this.button37.Click += new System.EventHandler(this.button37_Click);
            // 
            // button25
            // 
            this.button25.Location = new System.Drawing.Point(554, 506);
            this.button25.Name = "button25";
            this.button25.Size = new System.Drawing.Size(121, 25);
            this.button25.TabIndex = 63;
            this.button25.Text = "Save and restart";
            this.button25.UseVisualStyleBackColor = true;
            this.button25.Click += new System.EventHandler(this.button25_Click);
            // 
            // groupBox48
            // 
            this.groupBox48.Controls.Add(this.label71);
            this.groupBox48.Controls.Add(this.comboBox6);
            this.groupBox48.Controls.Add(this.label70);
            this.groupBox48.Controls.Add(this.button30);
            this.groupBox48.Controls.Add(this.button29);
            this.groupBox48.Controls.Add(this.textBox16);
            this.groupBox48.Controls.Add(this.textBox15);
            this.groupBox48.Location = new System.Drawing.Point(5, 540);
            this.groupBox48.Name = "groupBox48";
            this.groupBox48.Size = new System.Drawing.Size(669, 131);
            this.groupBox48.TabIndex = 62;
            this.groupBox48.TabStop = false;
            this.groupBox48.Text = "AT Transparent command";
            // 
            // label71
            // 
            this.label71.AutoSize = true;
            this.label71.Location = new System.Drawing.Point(142, 30);
            this.label71.Name = "label71";
            this.label71.Size = new System.Drawing.Size(36, 13);
            this.label71.TabIndex = 6;
            this.label71.Text = "*10ms";
            // 
            // comboBox6
            // 
            this.comboBox6.FormattingEnabled = true;
            this.comboBox6.Location = new System.Drawing.Point(73, 26);
            this.comboBox6.Name = "comboBox6";
            this.comboBox6.Size = new System.Drawing.Size(63, 21);
            this.comboBox6.TabIndex = 5;
            // 
            // label70
            // 
            this.label70.AutoSize = true;
            this.label70.Location = new System.Drawing.Point(14, 30);
            this.label70.Name = "label70";
            this.label70.Size = new System.Drawing.Size(44, 13);
            this.label70.TabIndex = 4;
            this.label70.Text = "timeout:";
            // 
            // button30
            // 
            this.button30.Location = new System.Drawing.Point(572, 25);
            this.button30.Name = "button30";
            this.button30.Size = new System.Drawing.Size(87, 25);
            this.button30.TabIndex = 3;
            this.button30.Text = "Clear";
            this.button30.UseVisualStyleBackColor = true;
            this.button30.Click += new System.EventHandler(this.button30_Click);
            // 
            // button29
            // 
            this.button29.Location = new System.Drawing.Point(479, 25);
            this.button29.Name = "button29";
            this.button29.Size = new System.Drawing.Size(82, 25);
            this.button29.TabIndex = 2;
            this.button29.Text = "Send";
            this.button29.UseVisualStyleBackColor = true;
            this.button29.Click += new System.EventHandler(this.button29_Click);
            // 
            // textBox16
            // 
            this.textBox16.Location = new System.Drawing.Point(181, 26);
            this.textBox16.Name = "textBox16";
            this.textBox16.Size = new System.Drawing.Size(289, 20);
            this.textBox16.TabIndex = 1;
            // 
            // textBox15
            // 
            this.textBox15.Location = new System.Drawing.Point(11, 59);
            this.textBox15.Multiline = true;
            this.textBox15.Name = "textBox15";
            this.textBox15.Size = new System.Drawing.Size(648, 66);
            this.textBox15.TabIndex = 0;
            // 
            // groupBox51
            // 
            this.groupBox51.Controls.Add(this.button36);
            this.groupBox51.Controls.Add(this.button33);
            this.groupBox51.Controls.Add(this.label110);
            this.groupBox51.Controls.Add(this.macTB);
            this.groupBox51.Controls.Add(this.panel_StaticIp);
            this.groupBox51.Location = new System.Drawing.Point(5, 311);
            this.groupBox51.Name = "groupBox51";
            this.groupBox51.Size = new System.Drawing.Size(543, 221);
            this.groupBox51.TabIndex = 61;
            this.groupBox51.TabStop = false;
            this.groupBox51.Text = "Net work setting";
            // 
            // button36
            // 
            this.button36.Location = new System.Drawing.Point(456, 142);
            this.button36.Name = "button36";
            this.button36.Size = new System.Drawing.Size(75, 25);
            this.button36.TabIndex = 119;
            this.button36.Text = "Get";
            this.button36.UseVisualStyleBackColor = true;
            this.button36.Click += new System.EventHandler(this.button36_Click);
            // 
            // button33
            // 
            this.button33.Location = new System.Drawing.Point(456, 184);
            this.button33.Name = "button33";
            this.button33.Size = new System.Drawing.Size(75, 25);
            this.button33.TabIndex = 118;
            this.button33.Text = "Set";
            this.button33.UseVisualStyleBackColor = true;
            this.button33.Click += new System.EventHandler(this.button33_Click);
            // 
            // label110
            // 
            this.label110.AutoSize = true;
            this.label110.Location = new System.Drawing.Point(222, 28);
            this.label110.Name = "label110";
            this.label110.Size = new System.Drawing.Size(69, 13);
            this.label110.TabIndex = 61;
            this.label110.Text = "Mac Address";
            // 
            // macTB
            // 
            this.macTB.AccessibleName = "MacAddress";
            this.macTB.Location = new System.Drawing.Point(224, 46);
            this.macTB.Name = "macTB";
            this.macTB.ReadOnly = true;
            this.macTB.Size = new System.Drawing.Size(176, 20);
            this.macTB.TabIndex = 58;
            // 
            // panel_StaticIp
            // 
            this.panel_StaticIp.Controls.Add(this.label109);
            this.panel_StaticIp.Controls.Add(this.label108);
            this.panel_StaticIp.Controls.Add(this.label107);
            this.panel_StaticIp.Controls.Add(this.label106);
            this.panel_StaticIp.Controls.Add(this.label105);
            this.panel_StaticIp.Controls.Add(this.altDNSTB);
            this.panel_StaticIp.Controls.Add(this.pDNSTB);
            this.panel_StaticIp.Controls.Add(this.gatewayTB);
            this.panel_StaticIp.Controls.Add(this.subnetTB);
            this.panel_StaticIp.Controls.Add(this.ipTB);
            this.panel_StaticIp.Location = new System.Drawing.Point(12, 22);
            this.panel_StaticIp.Name = "panel_StaticIp";
            this.panel_StaticIp.Size = new System.Drawing.Size(179, 187);
            this.panel_StaticIp.TabIndex = 56;
            // 
            // label109
            // 
            this.label109.AutoSize = true;
            this.label109.Location = new System.Drawing.Point(3, 139);
            this.label109.Name = "label109";
            this.label109.Size = new System.Drawing.Size(109, 13);
            this.label109.TabIndex = 50;
            this.label109.Text = "Alternate DNS Server";
            // 
            // label108
            // 
            this.label108.AutoSize = true;
            this.label108.Location = new System.Drawing.Point(3, 93);
            this.label108.Name = "label108";
            this.label108.Size = new System.Drawing.Size(110, 13);
            this.label108.TabIndex = 49;
            this.label108.Text = "Preferred DNS Server";
            // 
            // label107
            // 
            this.label107.AutoSize = true;
            this.label107.Location = new System.Drawing.Point(3, 65);
            this.label107.Name = "label107";
            this.label107.Size = new System.Drawing.Size(49, 13);
            this.label107.TabIndex = 48;
            this.label107.Text = "Gateway";
            // 
            // label106
            // 
            this.label106.AutoSize = true;
            this.label106.Location = new System.Drawing.Point(3, 36);
            this.label106.Name = "label106";
            this.label106.Size = new System.Drawing.Size(41, 13);
            this.label106.TabIndex = 47;
            this.label106.Text = "Subnet";
            // 
            // label105
            // 
            this.label105.AutoSize = true;
            this.label105.Location = new System.Drawing.Point(3, 7);
            this.label105.Name = "label105";
            this.label105.Size = new System.Drawing.Size(58, 13);
            this.label105.TabIndex = 46;
            this.label105.Text = "IP Address";
            // 
            // altDNSTB
            // 
            this.altDNSTB.AccessibleName = "AlternateDNS";
            this.altDNSTB.Location = new System.Drawing.Point(79, 155);
            this.altDNSTB.Name = "altDNSTB";
            this.altDNSTB.Size = new System.Drawing.Size(97, 20);
            this.altDNSTB.TabIndex = 43;
            // 
            // pDNSTB
            // 
            this.pDNSTB.AccessibleName = "PreferredDNS";
            this.pDNSTB.Location = new System.Drawing.Point(79, 109);
            this.pDNSTB.Name = "pDNSTB";
            this.pDNSTB.Size = new System.Drawing.Size(97, 20);
            this.pDNSTB.TabIndex = 42;
            // 
            // gatewayTB
            // 
            this.gatewayTB.AccessibleName = "Gateway";
            this.gatewayTB.Location = new System.Drawing.Point(79, 62);
            this.gatewayTB.Name = "gatewayTB";
            this.gatewayTB.Size = new System.Drawing.Size(97, 20);
            this.gatewayTB.TabIndex = 41;
            // 
            // subnetTB
            // 
            this.subnetTB.AccessibleName = "Subnet";
            this.subnetTB.Location = new System.Drawing.Point(79, 33);
            this.subnetTB.Name = "subnetTB";
            this.subnetTB.Size = new System.Drawing.Size(97, 20);
            this.subnetTB.TabIndex = 40;
            // 
            // ipTB
            // 
            this.ipTB.AccessibleName = "IpAddress";
            this.ipTB.Location = new System.Drawing.Point(79, 3);
            this.ipTB.Name = "ipTB";
            this.ipTB.Size = new System.Drawing.Size(97, 20);
            this.ipTB.TabIndex = 39;
            // 
            // groupBox50
            // 
            this.groupBox50.Controls.Add(this.button35);
            this.groupBox50.Controls.Add(this.button32);
            this.groupBox50.Controls.Add(this.panel_TCP);
            this.groupBox50.Location = new System.Drawing.Point(5, 141);
            this.groupBox50.Name = "groupBox50";
            this.groupBox50.Size = new System.Drawing.Size(543, 164);
            this.groupBox50.TabIndex = 60;
            this.groupBox50.TabStop = false;
            this.groupBox50.Text = "Connection setting";
            // 
            // button35
            // 
            this.button35.Location = new System.Drawing.Point(456, 85);
            this.button35.Name = "button35";
            this.button35.Size = new System.Drawing.Size(75, 25);
            this.button35.TabIndex = 119;
            this.button35.Text = "Get";
            this.button35.UseVisualStyleBackColor = true;
            this.button35.Click += new System.EventHandler(this.button35_Click);
            // 
            // button32
            // 
            this.button32.Location = new System.Drawing.Point(456, 124);
            this.button32.Name = "button32";
            this.button32.Size = new System.Drawing.Size(75, 25);
            this.button32.TabIndex = 118;
            this.button32.Text = "Set";
            this.button32.UseVisualStyleBackColor = true;
            this.button32.Click += new System.EventHandler(this.button32_Click);
            // 
            // panel_TCP
            // 
            this.panel_TCP.Controls.Add(this.label87);
            this.panel_TCP.Controls.Add(this.label88);
            this.panel_TCP.Controls.Add(this.label89);
            this.panel_TCP.Controls.Add(this.label90);
            this.panel_TCP.Controls.Add(this.label93);
            this.panel_TCP.Controls.Add(this.workasCB);
            this.panel_TCP.Controls.Add(this.tcpRomteHostTB);
            this.panel_TCP.Controls.Add(this.tcpRemotePortNUD);
            this.panel_TCP.Controls.Add(this.tcpLocalPortNUD);
            this.panel_TCP.Controls.Add(this.tcpActiveCB);
            this.panel_TCP.Location = new System.Drawing.Point(12, 22);
            this.panel_TCP.Name = "panel_TCP";
            this.panel_TCP.Size = new System.Drawing.Size(421, 127);
            this.panel_TCP.TabIndex = 113;
            // 
            // label87
            // 
            this.label87.AutoSize = true;
            this.label87.Location = new System.Drawing.Point(3, 101);
            this.label87.Name = "label87";
            this.label87.Size = new System.Drawing.Size(55, 13);
            this.label87.TabIndex = 119;
            this.label87.Text = "Local Port";
            // 
            // label88
            // 
            this.label88.AutoSize = true;
            this.label88.Location = new System.Drawing.Point(3, 70);
            this.label88.Name = "label88";
            this.label88.Size = new System.Drawing.Size(66, 13);
            this.label88.TabIndex = 118;
            this.label88.Text = "Remote Port";
            // 
            // label89
            // 
            this.label89.AutoSize = true;
            this.label89.Location = new System.Drawing.Point(3, 39);
            this.label89.Name = "label89";
            this.label89.Size = new System.Drawing.Size(69, 13);
            this.label89.TabIndex = 117;
            this.label89.Text = "Remote Host";
            // 
            // label90
            // 
            this.label90.AutoSize = true;
            this.label90.Location = new System.Drawing.Point(3, 13);
            this.label90.Name = "label90";
            this.label90.Size = new System.Drawing.Size(60, 13);
            this.label90.TabIndex = 116;
            this.label90.Text = "Worked As";
            // 
            // label93
            // 
            this.label93.AutoSize = true;
            this.label93.Location = new System.Drawing.Point(203, 13);
            this.label93.Name = "label93";
            this.label93.Size = new System.Drawing.Size(80, 13);
            this.label93.TabIndex = 107;
            this.label93.Text = "Active Connect";
            // 
            // workasCB
            // 
            this.workasCB.AccessibleName = "ConnWorkMode";
            this.workasCB.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.workasCB.FormattingEnabled = true;
            this.workasCB.Items.AddRange(new object[] {
            "Server",
            "Client"});
            this.workasCB.Location = new System.Drawing.Point(79, 10);
            this.workasCB.Name = "workasCB";
            this.workasCB.Size = new System.Drawing.Size(92, 21);
            this.workasCB.TabIndex = 106;
            // 
            // tcpRomteHostTB
            // 
            this.tcpRomteHostTB.AccessibleName = "ConnRemoteHost";
            this.tcpRomteHostTB.Location = new System.Drawing.Point(79, 35);
            this.tcpRomteHostTB.Name = "tcpRomteHostTB";
            this.tcpRomteHostTB.Size = new System.Drawing.Size(92, 20);
            this.tcpRomteHostTB.TabIndex = 98;
            // 
            // tcpRemotePortNUD
            // 
            this.tcpRemotePortNUD.AccessibleName = "ConnRemotePort";
            this.tcpRemotePortNUD.Location = new System.Drawing.Point(111, 64);
            this.tcpRemotePortNUD.Maximum = new decimal(new int[] {
            65535,
            0,
            0,
            0});
            this.tcpRemotePortNUD.Name = "tcpRemotePortNUD";
            this.tcpRemotePortNUD.Size = new System.Drawing.Size(60, 20);
            this.tcpRemotePortNUD.TabIndex = 96;
            this.tcpRemotePortNUD.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            // 
            // tcpLocalPortNUD
            // 
            this.tcpLocalPortNUD.AccessibleName = "ConnLocalPort";
            this.tcpLocalPortNUD.Location = new System.Drawing.Point(111, 93);
            this.tcpLocalPortNUD.Maximum = new decimal(new int[] {
            65535,
            0,
            0,
            0});
            this.tcpLocalPortNUD.Name = "tcpLocalPortNUD";
            this.tcpLocalPortNUD.Size = new System.Drawing.Size(60, 20);
            this.tcpLocalPortNUD.TabIndex = 95;
            this.tcpLocalPortNUD.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            // 
            // tcpActiveCB
            // 
            this.tcpActiveCB.AccessibleName = "ConnActive";
            this.tcpActiveCB.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.tcpActiveCB.FormattingEnabled = true;
            this.tcpActiveCB.Items.AddRange(new object[] {
            "None",
            "WithAnyCharacter",
            "WithStartCharacter",
            "AutoStart"});
            this.tcpActiveCB.Location = new System.Drawing.Point(292, 8);
            this.tcpActiveCB.Name = "tcpActiveCB";
            this.tcpActiveCB.Size = new System.Drawing.Size(107, 21);
            this.tcpActiveCB.TabIndex = 93;
            // 
            // groupBox49
            // 
            this.groupBox49.Controls.Add(this.button34);
            this.groupBox49.Controls.Add(this.button31);
            this.groupBox49.Controls.Add(this.panel4);
            this.groupBox49.Location = new System.Drawing.Point(5, 7);
            this.groupBox49.Name = "groupBox49";
            this.groupBox49.Size = new System.Drawing.Size(543, 128);
            this.groupBox49.TabIndex = 59;
            this.groupBox49.TabStop = false;
            this.groupBox49.Text = "Serial setting";
            // 
            // button34
            // 
            this.button34.Location = new System.Drawing.Point(456, 44);
            this.button34.Name = "button34";
            this.button34.Size = new System.Drawing.Size(75, 25);
            this.button34.TabIndex = 118;
            this.button34.Text = "Get";
            this.button34.UseVisualStyleBackColor = true;
            this.button34.Click += new System.EventHandler(this.button34_Click);
            // 
            // button31
            // 
            this.button31.Location = new System.Drawing.Point(456, 86);
            this.button31.Name = "button31";
            this.button31.Size = new System.Drawing.Size(75, 25);
            this.button31.TabIndex = 117;
            this.button31.Text = "Set";
            this.button31.UseVisualStyleBackColor = true;
            this.button31.Click += new System.EventHandler(this.button31_Click);
            // 
            // panel4
            // 
            this.panel4.Controls.Add(this.label72);
            this.panel4.Controls.Add(this.label73);
            this.panel4.Controls.Add(this.label74);
            this.panel4.Controls.Add(this.label75);
            this.panel4.Controls.Add(this.label76);
            this.panel4.Controls.Add(this.label77);
            this.panel4.Controls.Add(this.label78);
            this.panel4.Controls.Add(this.protocolCB);
            this.panel4.Controls.Add(this.stopbitCB);
            this.panel4.Controls.Add(this.parityCB);
            this.panel4.Controls.Add(this.databitCB);
            this.panel4.Controls.Add(this.baudrateCB);
            this.panel4.Controls.Add(this.flowCB);
            this.panel4.Controls.Add(this.fifoCB);
            this.panel4.Location = new System.Drawing.Point(18, 22);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(415, 92);
            this.panel4.TabIndex = 113;
            // 
            // label72
            // 
            this.label72.AutoSize = true;
            this.label72.Location = new System.Drawing.Point(281, 14);
            this.label72.Name = "label72";
            this.label72.Size = new System.Drawing.Size(50, 13);
            this.label72.TabIndex = 112;
            this.label72.Text = "Data Bits";
            // 
            // label73
            // 
            this.label73.AutoSize = true;
            this.label73.Location = new System.Drawing.Point(221, 69);
            this.label73.Name = "label73";
            this.label73.Size = new System.Drawing.Size(49, 13);
            this.label73.TabIndex = 111;
            this.label73.Text = "Stop Bits";
            // 
            // label74
            // 
            this.label74.AutoSize = true;
            this.label74.Location = new System.Drawing.Point(221, 42);
            this.label74.Name = "label74";
            this.label74.Size = new System.Drawing.Size(65, 13);
            this.label74.TabIndex = 110;
            this.label74.Text = "Flow Control";
            // 
            // label75
            // 
            this.label75.AutoSize = true;
            this.label75.Location = new System.Drawing.Point(15, 69);
            this.label75.Name = "label75";
            this.label75.Size = new System.Drawing.Size(33, 13);
            this.label75.TabIndex = 109;
            this.label75.Text = "Parity";
            // 
            // label76
            // 
            this.label76.AutoSize = true;
            this.label76.Location = new System.Drawing.Point(15, 42);
            this.label76.Name = "label76";
            this.label76.Size = new System.Drawing.Size(58, 13);
            this.label76.TabIndex = 107;
            this.label76.Text = "Baud Rate";
            // 
            // label77
            // 
            this.label77.AutoSize = true;
            this.label77.Location = new System.Drawing.Point(186, 14);
            this.label77.Name = "label77";
            this.label77.Size = new System.Drawing.Size(30, 13);
            this.label77.TabIndex = 108;
            this.label77.Text = "FIFO";
            // 
            // label78
            // 
            this.label78.AutoSize = true;
            this.label78.Location = new System.Drawing.Point(15, 14);
            this.label78.Name = "label78";
            this.label78.Size = new System.Drawing.Size(46, 13);
            this.label78.TabIndex = 107;
            this.label78.Text = "Protocol";
            // 
            // protocolCB
            // 
            this.protocolCB.AccessibleName = "SerialProtocol";
            this.protocolCB.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.protocolCB.FormattingEnabled = true;
            this.protocolCB.Items.AddRange(new object[] {
            "RS232",
            "RS422",
            "RS485"});
            this.protocolCB.Location = new System.Drawing.Point(92, 11);
            this.protocolCB.Name = "protocolCB";
            this.protocolCB.Size = new System.Drawing.Size(64, 21);
            this.protocolCB.TabIndex = 83;
            // 
            // stopbitCB
            // 
            this.stopbitCB.AccessibleName = "StopBits";
            this.stopbitCB.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.stopbitCB.FormattingEnabled = true;
            this.stopbitCB.Items.AddRange(new object[] {
            "1",
            "1.5",
            "2"});
            this.stopbitCB.Location = new System.Drawing.Point(311, 66);
            this.stopbitCB.Name = "stopbitCB";
            this.stopbitCB.Size = new System.Drawing.Size(45, 21);
            this.stopbitCB.TabIndex = 48;
            // 
            // parityCB
            // 
            this.parityCB.AccessibleName = "SerialParity";
            this.parityCB.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.parityCB.FormattingEnabled = true;
            this.parityCB.Items.AddRange(new object[] {
            "NONE",
            "ODD",
            "EVEN",
            "MARK",
            "SPACE"});
            this.parityCB.Location = new System.Drawing.Point(92, 66);
            this.parityCB.Name = "parityCB";
            this.parityCB.Size = new System.Drawing.Size(88, 21);
            this.parityCB.TabIndex = 47;
            // 
            // databitCB
            // 
            this.databitCB.AccessibleName = "DataBits";
            this.databitCB.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.databitCB.FormattingEnabled = true;
            this.databitCB.Items.AddRange(new object[] {
            "5",
            "6",
            "7",
            "8"});
            this.databitCB.Location = new System.Drawing.Point(354, 11);
            this.databitCB.Name = "databitCB";
            this.databitCB.Size = new System.Drawing.Size(45, 21);
            this.databitCB.TabIndex = 46;
            // 
            // baudrateCB
            // 
            this.baudrateCB.AccessibleName = "BaudRate";
            this.baudrateCB.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.baudrateCB.FormattingEnabled = true;
            this.baudrateCB.Items.AddRange(new object[] {
            "110",
            "134",
            "150",
            "300",
            "600",
            "1200",
            "1800",
            "2400",
            "4800",
            "7200",
            "9600",
            "14400",
            "19200",
            "38400",
            "57600",
            "115200",
            "230400",
            "460800"});
            this.baudrateCB.Location = new System.Drawing.Point(92, 38);
            this.baudrateCB.Name = "baudrateCB";
            this.baudrateCB.Size = new System.Drawing.Size(98, 21);
            this.baudrateCB.TabIndex = 45;
            // 
            // flowCB
            // 
            this.flowCB.AccessibleName = "FlowControl";
            this.flowCB.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.flowCB.FormattingEnabled = true;
            this.flowCB.Items.AddRange(new object[] {
            "None",
            "Software",
            "Hardware"});
            this.flowCB.Location = new System.Drawing.Point(311, 39);
            this.flowCB.Name = "flowCB";
            this.flowCB.Size = new System.Drawing.Size(88, 21);
            this.flowCB.TabIndex = 44;
            // 
            // fifoCB
            // 
            this.fifoCB.AccessibleName = "SerialFIFO";
            this.fifoCB.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.fifoCB.FormattingEnabled = true;
            this.fifoCB.Items.AddRange(new object[] {
            "14",
            "8",
            "4"});
            this.fifoCB.Location = new System.Drawing.Point(221, 11);
            this.fifoCB.Name = "fifoCB";
            this.fifoCB.Size = new System.Drawing.Size(45, 21);
            this.fifoCB.TabIndex = 43;
            // 
            // groupBox47
            // 
            this.groupBox47.Controls.Add(this.button28);
            this.groupBox47.Controls.Add(this.button27);
            this.groupBox47.Location = new System.Drawing.Point(554, 373);
            this.groupBox47.Name = "groupBox47";
            this.groupBox47.Size = new System.Drawing.Size(121, 92);
            this.groupBox47.TabIndex = 58;
            this.groupBox47.TabStop = false;
            this.groupBox47.Text = "AT Mode Change";
            // 
            // button28
            // 
            this.button28.Location = new System.Drawing.Point(7, 53);
            this.button28.Name = "button28";
            this.button28.Size = new System.Drawing.Size(107, 25);
            this.button28.TabIndex = 1;
            this.button28.Text = "EXIT";
            this.button28.UseVisualStyleBackColor = true;
            this.button28.Click += new System.EventHandler(this.button28_Click);
            // 
            // button27
            // 
            this.button27.Location = new System.Drawing.Point(7, 21);
            this.button27.Name = "button27";
            this.button27.Size = new System.Drawing.Size(107, 25);
            this.button27.TabIndex = 0;
            this.button27.Text = "GOTO";
            this.button27.UseVisualStyleBackColor = true;
            this.button27.Click += new System.EventHandler(this.button27_Click);
            // 
            // TabSheet_EPCC1G2
            // 
            this.TabSheet_EPCC1G2.Controls.Add(this.groupBox31);
            this.TabSheet_EPCC1G2.Controls.Add(this.groupBox18);
            this.TabSheet_EPCC1G2.Controls.Add(this.groupBox16);
            this.TabSheet_EPCC1G2.Controls.Add(this.groupBox15);
            this.TabSheet_EPCC1G2.Controls.Add(this.groupBox14);
            this.TabSheet_EPCC1G2.Controls.Add(this.groupBox13);
            this.TabSheet_EPCC1G2.Controls.Add(this.groupBox12);
            this.TabSheet_EPCC1G2.Controls.Add(this.groupBox7);
            this.TabSheet_EPCC1G2.Controls.Add(this.groupBox5);
            this.TabSheet_EPCC1G2.Controls.Add(this.groupBox4);
            this.TabSheet_EPCC1G2.Location = new System.Drawing.Point(4, 22);
            this.TabSheet_EPCC1G2.Name = "TabSheet_EPCC1G2";
            this.TabSheet_EPCC1G2.Size = new System.Drawing.Size(817, 678);
            this.TabSheet_EPCC1G2.TabIndex = 2;
            this.TabSheet_EPCC1G2.Text = "EPCC1-G2 Test";
            this.TabSheet_EPCC1G2.UseVisualStyleBackColor = true;
            // 
            // groupBox31
            // 
            this.groupBox31.Controls.Add(this.maskData_textBox);
            this.groupBox31.Controls.Add(this.label60);
            this.groupBox31.Controls.Add(this.groupBox40);
            this.groupBox31.Controls.Add(this.checkBox1);
            this.groupBox31.Controls.Add(this.maskLen_textBox);
            this.groupBox31.Controls.Add(this.label44);
            this.groupBox31.Controls.Add(this.maskadr_textbox);
            this.groupBox31.Controls.Add(this.label43);
            this.groupBox31.Location = new System.Drawing.Point(2, 182);
            this.groupBox31.Name = "groupBox31";
            this.groupBox31.Size = new System.Drawing.Size(479, 76);
            this.groupBox31.TabIndex = 9;
            this.groupBox31.TabStop = false;
            this.groupBox31.Text = "Mask conditions";
            // 
            // maskData_textBox
            // 
            this.maskData_textBox.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.maskData_textBox.Enabled = false;
            this.maskData_textBox.Location = new System.Drawing.Point(303, 44);
            this.maskData_textBox.Name = "maskData_textBox";
            this.maskData_textBox.Size = new System.Drawing.Size(170, 20);
            this.maskData_textBox.TabIndex = 8;
            this.maskData_textBox.Text = "00";
            // 
            // label60
            // 
            this.label60.AutoSize = true;
            this.label60.Location = new System.Drawing.Point(214, 48);
            this.label60.Name = "label60";
            this.label60.Size = new System.Drawing.Size(90, 13);
            this.label60.TabIndex = 7;
            this.label60.Text = "Mask Data(Hex)：";
            // 
            // groupBox40
            // 
            this.groupBox40.Controls.Add(this.R_User);
            this.groupBox40.Controls.Add(this.R_TID);
            this.groupBox40.Controls.Add(this.R_EPC);
            this.groupBox40.Location = new System.Drawing.Point(4, 33);
            this.groupBox40.Name = "groupBox40";
            this.groupBox40.Size = new System.Drawing.Size(200, 39);
            this.groupBox40.TabIndex = 6;
            this.groupBox40.TabStop = false;
            // 
            // R_User
            // 
            this.R_User.AutoSize = true;
            this.R_User.Enabled = false;
            this.R_User.Location = new System.Drawing.Point(124, 15);
            this.R_User.Name = "R_User";
            this.R_User.Size = new System.Drawing.Size(47, 17);
            this.R_User.TabIndex = 2;
            this.R_User.TabStop = true;
            this.R_User.Text = "User";
            this.R_User.UseVisualStyleBackColor = true;
            // 
            // R_TID
            // 
            this.R_TID.AutoSize = true;
            this.R_TID.Enabled = false;
            this.R_TID.Location = new System.Drawing.Point(65, 15);
            this.R_TID.Name = "R_TID";
            this.R_TID.Size = new System.Drawing.Size(43, 17);
            this.R_TID.TabIndex = 1;
            this.R_TID.TabStop = true;
            this.R_TID.Text = "TID";
            this.R_TID.UseVisualStyleBackColor = true;
            // 
            // R_EPC
            // 
            this.R_EPC.AutoSize = true;
            this.R_EPC.Enabled = false;
            this.R_EPC.Location = new System.Drawing.Point(6, 15);
            this.R_EPC.Name = "R_EPC";
            this.R_EPC.Size = new System.Drawing.Size(46, 17);
            this.R_EPC.TabIndex = 0;
            this.R_EPC.TabStop = true;
            this.R_EPC.Text = "EPC";
            this.R_EPC.UseVisualStyleBackColor = true;
            // 
            // checkBox1
            // 
            this.checkBox1.AutoSize = true;
            this.checkBox1.Location = new System.Drawing.Point(425, 17);
            this.checkBox1.Name = "checkBox1";
            this.checkBox1.Size = new System.Drawing.Size(59, 17);
            this.checkBox1.TabIndex = 5;
            this.checkBox1.Text = "Enable";
            this.checkBox1.UseVisualStyleBackColor = true;
            this.checkBox1.CheckedChanged += new System.EventHandler(this.checkBox1_CheckedChanged);
            // 
            // maskLen_textBox
            // 
            this.maskLen_textBox.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.maskLen_textBox.Enabled = false;
            this.maskLen_textBox.Location = new System.Drawing.Point(357, 12);
            this.maskLen_textBox.MaxLength = 2;
            this.maskLen_textBox.Name = "maskLen_textBox";
            this.maskLen_textBox.Size = new System.Drawing.Size(45, 20);
            this.maskLen_textBox.TabIndex = 4;
            this.maskLen_textBox.Text = "00";
            // 
            // label44
            // 
            this.label44.AutoSize = true;
            this.label44.Location = new System.Drawing.Point(231, 18);
            this.label44.Name = "label44";
            this.label44.Size = new System.Drawing.Size(115, 13);
            this.label44.TabIndex = 3;
            this.label44.Text = "Mask Bit Length(Hex)：";
            // 
            // maskadr_textbox
            // 
            this.maskadr_textbox.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.maskadr_textbox.Enabled = false;
            this.maskadr_textbox.Location = new System.Drawing.Point(176, 13);
            this.maskadr_textbox.MaxLength = 4;
            this.maskadr_textbox.Name = "maskadr_textbox";
            this.maskadr_textbox.Size = new System.Drawing.Size(50, 20);
            this.maskadr_textbox.TabIndex = 2;
            this.maskadr_textbox.Text = "0000";
            // 
            // label43
            // 
            this.label43.AutoSize = true;
            this.label43.Location = new System.Drawing.Point(6, 18);
            this.label43.Name = "label43";
            this.label43.Size = new System.Drawing.Size(145, 13);
            this.label43.TabIndex = 1;
            this.label43.Text = "Mask Start Bit Address(Hex)：";
            // 
            // groupBox18
            // 
            this.groupBox18.Controls.Add(this.Button_LockUserBlock_G2);
            this.groupBox18.Controls.Add(this.Edit_AccessCode6);
            this.groupBox18.Controls.Add(this.ComboBox_BlockNum);
            this.groupBox18.Controls.Add(this.label30);
            this.groupBox18.Controls.Add(this.label29);
            this.groupBox18.Controls.Add(this.ComboBox_EPC6);
            this.groupBox18.Location = new System.Drawing.Point(485, 575);
            this.groupBox18.Name = "groupBox18";
            this.groupBox18.Size = new System.Drawing.Size(325, 99);
            this.groupBox18.TabIndex = 8;
            this.groupBox18.TabStop = false;
            this.groupBox18.Text = "Lock Block for User (Permanently Lock)";
            // 
            // Button_LockUserBlock_G2
            // 
            this.Button_LockUserBlock_G2.Location = new System.Drawing.Point(226, 68);
            this.Button_LockUserBlock_G2.Name = "Button_LockUserBlock_G2";
            this.Button_LockUserBlock_G2.Size = new System.Drawing.Size(89, 25);
            this.Button_LockUserBlock_G2.TabIndex = 5;
            this.Button_LockUserBlock_G2.Text = "Block Lock";
            this.Button_LockUserBlock_G2.UseVisualStyleBackColor = true;
            this.Button_LockUserBlock_G2.Click += new System.EventHandler(this.Button_LockUserBlock_G2_Click);
            // 
            // Edit_AccessCode6
            // 
            this.Edit_AccessCode6.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.Edit_AccessCode6.Location = new System.Drawing.Point(134, 72);
            this.Edit_AccessCode6.MaxLength = 8;
            this.Edit_AccessCode6.Name = "Edit_AccessCode6";
            this.Edit_AccessCode6.Size = new System.Drawing.Size(85, 20);
            this.Edit_AccessCode6.TabIndex = 4;
            this.Edit_AccessCode6.Text = "00000000";
            // 
            // ComboBox_BlockNum
            // 
            this.ComboBox_BlockNum.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.ComboBox_BlockNum.FormattingEnabled = true;
            this.ComboBox_BlockNum.Location = new System.Drawing.Point(134, 43);
            this.ComboBox_BlockNum.Name = "ComboBox_BlockNum";
            this.ComboBox_BlockNum.Size = new System.Drawing.Size(87, 21);
            this.ComboBox_BlockNum.TabIndex = 3;
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.Location = new System.Drawing.Point(9, 67);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(91, 26);
            this.label30.TabIndex = 2;
            this.label30.Text = "Access Password\r\n(8 Hex):";
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.Location = new System.Drawing.Point(9, 40);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(105, 26);
            this.label29.TabIndex = 1;
            this.label29.Text = "Address of Tag Data\r\n(Word):";
            // 
            // ComboBox_EPC6
            // 
            this.ComboBox_EPC6.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.ComboBox_EPC6.FormattingEnabled = true;
            this.ComboBox_EPC6.Location = new System.Drawing.Point(6, 16);
            this.ComboBox_EPC6.Name = "ComboBox_EPC6";
            this.ComboBox_EPC6.Size = new System.Drawing.Size(313, 21);
            this.ComboBox_EPC6.TabIndex = 0;
            // 
            // groupBox16
            // 
            this.groupBox16.Controls.Add(this.Label_Alarm);
            this.groupBox16.Controls.Add(this.button4);
            this.groupBox16.Controls.Add(this.Button_SetEASAlarm_G2);
            this.groupBox16.Controls.Add(this.groupBox17);
            this.groupBox16.Controls.Add(this.Edit_AccessCode5);
            this.groupBox16.Controls.Add(this.label28);
            this.groupBox16.Controls.Add(this.ComboBox_EPC5);
            this.groupBox16.Location = new System.Drawing.Point(485, 457);
            this.groupBox16.Name = "groupBox16";
            this.groupBox16.Size = new System.Drawing.Size(325, 116);
            this.groupBox16.TabIndex = 7;
            this.groupBox16.TabStop = false;
            this.groupBox16.Text = "EAS Alarm";
            // 
            // Label_Alarm
            // 
            this.Label_Alarm.AutoSize = true;
            this.Label_Alarm.Font = new System.Drawing.Font("MS Reference Sans Serif", 30.3F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(2)), true);
            this.Label_Alarm.ForeColor = System.Drawing.Color.Red;
            this.Label_Alarm.Location = new System.Drawing.Point(243, 38);
            this.Label_Alarm.Name = "Label_Alarm";
            this.Label_Alarm.Size = new System.Drawing.Size(51, 46);
            this.Label_Alarm.TabIndex = 14;
            this.Label_Alarm.Text = "l";
            // 
            // button4
            // 
            this.button4.Enabled = false;
            this.button4.Location = new System.Drawing.Point(226, 86);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(89, 25);
            this.button4.TabIndex = 13;
            this.button4.Text = "EAS Alarm";
            this.button4.UseVisualStyleBackColor = true;
            this.button4.Click += new System.EventHandler(this.button4_Click);
            // 
            // Button_SetEASAlarm_G2
            // 
            this.Button_SetEASAlarm_G2.Location = new System.Drawing.Point(110, 86);
            this.Button_SetEASAlarm_G2.Name = "Button_SetEASAlarm_G2";
            this.Button_SetEASAlarm_G2.Size = new System.Drawing.Size(97, 25);
            this.Button_SetEASAlarm_G2.TabIndex = 12;
            this.Button_SetEASAlarm_G2.Text = "EAS Configure";
            this.Button_SetEASAlarm_G2.UseVisualStyleBackColor = true;
            this.Button_SetEASAlarm_G2.Click += new System.EventHandler(this.Button_SetEASAlarm_G2_Click);
            // 
            // groupBox17
            // 
            this.groupBox17.Controls.Add(this.NoAlarm_G2);
            this.groupBox17.Controls.Add(this.Alarm_G2);
            this.groupBox17.Location = new System.Drawing.Point(6, 62);
            this.groupBox17.Name = "groupBox17";
            this.groupBox17.Size = new System.Drawing.Size(100, 51);
            this.groupBox17.TabIndex = 11;
            this.groupBox17.TabStop = false;
            // 
            // NoAlarm_G2
            // 
            this.NoAlarm_G2.AutoSize = true;
            this.NoAlarm_G2.Location = new System.Drawing.Point(5, 29);
            this.NoAlarm_G2.Name = "NoAlarm_G2";
            this.NoAlarm_G2.Size = new System.Drawing.Size(68, 17);
            this.NoAlarm_G2.TabIndex = 1;
            this.NoAlarm_G2.TabStop = true;
            this.NoAlarm_G2.Text = "No Alarm";
            this.NoAlarm_G2.UseVisualStyleBackColor = true;
            // 
            // Alarm_G2
            // 
            this.Alarm_G2.AutoSize = true;
            this.Alarm_G2.Location = new System.Drawing.Point(5, 11);
            this.Alarm_G2.Name = "Alarm_G2";
            this.Alarm_G2.Size = new System.Drawing.Size(51, 17);
            this.Alarm_G2.TabIndex = 0;
            this.Alarm_G2.TabStop = true;
            this.Alarm_G2.Text = "Alarm";
            this.Alarm_G2.UseVisualStyleBackColor = true;
            // 
            // Edit_AccessCode5
            // 
            this.Edit_AccessCode5.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.Edit_AccessCode5.Location = new System.Drawing.Point(107, 40);
            this.Edit_AccessCode5.MaxLength = 8;
            this.Edit_AccessCode5.Name = "Edit_AccessCode5";
            this.Edit_AccessCode5.Size = new System.Drawing.Size(100, 20);
            this.Edit_AccessCode5.TabIndex = 10;
            this.Edit_AccessCode5.Text = "00000000";
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Location = new System.Drawing.Point(6, 37);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(91, 26);
            this.label28.TabIndex = 9;
            this.label28.Text = "Access Password\r\n(8 Hex):";
            // 
            // ComboBox_EPC5
            // 
            this.ComboBox_EPC5.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.ComboBox_EPC5.FormattingEnabled = true;
            this.ComboBox_EPC5.Location = new System.Drawing.Point(6, 14);
            this.ComboBox_EPC5.Name = "ComboBox_EPC5";
            this.ComboBox_EPC5.Size = new System.Drawing.Size(313, 21);
            this.ComboBox_EPC5.TabIndex = 8;
            // 
            // groupBox15
            // 
            this.groupBox15.Controls.Add(this.Button_CheckReadProtected_G2);
            this.groupBox15.Controls.Add(this.Button_RemoveReadProtect_G2);
            this.groupBox15.Controls.Add(this.Button_SetMultiReadProtect_G2);
            this.groupBox15.Controls.Add(this.Button_SetReadProtect_G2);
            this.groupBox15.Controls.Add(this.Edit_AccessCode4);
            this.groupBox15.Controls.Add(this.label27);
            this.groupBox15.Controls.Add(this.ComboBox_EPC4);
            this.groupBox15.Location = new System.Drawing.Point(485, 267);
            this.groupBox15.Name = "groupBox15";
            this.groupBox15.Size = new System.Drawing.Size(325, 190);
            this.groupBox15.TabIndex = 6;
            this.groupBox15.TabStop = false;
            this.groupBox15.Text = "Read Protection";
            // 
            // Button_CheckReadProtected_G2
            // 
            this.Button_CheckReadProtected_G2.Enabled = false;
            this.Button_CheckReadProtected_G2.Location = new System.Drawing.Point(6, 159);
            this.Button_CheckReadProtected_G2.Name = "Button_CheckReadProtected_G2";
            this.Button_CheckReadProtected_G2.Size = new System.Drawing.Size(313, 25);
            this.Button_CheckReadProtected_G2.TabIndex = 6;
            this.Button_CheckReadProtected_G2.Text = "Check Privacy";
            this.Button_CheckReadProtected_G2.UseVisualStyleBackColor = true;
            this.Button_CheckReadProtected_G2.Click += new System.EventHandler(this.Button_CheckReadProtected_G2_Click);
            // 
            // Button_RemoveReadProtect_G2
            // 
            this.Button_RemoveReadProtect_G2.Enabled = false;
            this.Button_RemoveReadProtect_G2.Location = new System.Drawing.Point(6, 130);
            this.Button_RemoveReadProtect_G2.Name = "Button_RemoveReadProtect_G2";
            this.Button_RemoveReadProtect_G2.Size = new System.Drawing.Size(313, 25);
            this.Button_RemoveReadProtect_G2.TabIndex = 5;
            this.Button_RemoveReadProtect_G2.Text = "Reset Privacy";
            this.Button_RemoveReadProtect_G2.UseVisualStyleBackColor = true;
            this.Button_RemoveReadProtect_G2.Click += new System.EventHandler(this.Button_RemoveReadProtect_G2_Click);
            // 
            // Button_SetMultiReadProtect_G2
            // 
            this.Button_SetMultiReadProtect_G2.Enabled = false;
            this.Button_SetMultiReadProtect_G2.Location = new System.Drawing.Point(6, 101);
            this.Button_SetMultiReadProtect_G2.Name = "Button_SetMultiReadProtect_G2";
            this.Button_SetMultiReadProtect_G2.Size = new System.Drawing.Size(313, 25);
            this.Button_SetMultiReadProtect_G2.TabIndex = 4;
            this.Button_SetMultiReadProtect_G2.Text = "Set Privacy Without EPC";
            this.Button_SetMultiReadProtect_G2.UseVisualStyleBackColor = true;
            this.Button_SetMultiReadProtect_G2.Click += new System.EventHandler(this.Button_SetMultiReadProtect_G2_Click);
            // 
            // Button_SetReadProtect_G2
            // 
            this.Button_SetReadProtect_G2.Enabled = false;
            this.Button_SetReadProtect_G2.Location = new System.Drawing.Point(6, 72);
            this.Button_SetReadProtect_G2.Name = "Button_SetReadProtect_G2";
            this.Button_SetReadProtect_G2.Size = new System.Drawing.Size(313, 25);
            this.Button_SetReadProtect_G2.TabIndex = 3;
            this.Button_SetReadProtect_G2.Text = "Set Privacy By EPC";
            this.Button_SetReadProtect_G2.UseVisualStyleBackColor = true;
            this.Button_SetReadProtect_G2.Click += new System.EventHandler(this.Button_SetReadProtect_G2_Click);
            // 
            // Edit_AccessCode4
            // 
            this.Edit_AccessCode4.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.Edit_AccessCode4.Location = new System.Drawing.Point(107, 43);
            this.Edit_AccessCode4.MaxLength = 8;
            this.Edit_AccessCode4.Name = "Edit_AccessCode4";
            this.Edit_AccessCode4.Size = new System.Drawing.Size(100, 20);
            this.Edit_AccessCode4.TabIndex = 2;
            this.Edit_AccessCode4.Text = "00000000";
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Location = new System.Drawing.Point(6, 40);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(91, 26);
            this.label27.TabIndex = 1;
            this.label27.Text = "Access Password\r\n(8 Hex):";
            // 
            // ComboBox_EPC4
            // 
            this.ComboBox_EPC4.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.ComboBox_EPC4.FormattingEnabled = true;
            this.ComboBox_EPC4.Location = new System.Drawing.Point(8, 15);
            this.ComboBox_EPC4.Name = "ComboBox_EPC4";
            this.ComboBox_EPC4.Size = new System.Drawing.Size(311, 21);
            this.ComboBox_EPC4.TabIndex = 0;
            // 
            // groupBox14
            // 
            this.groupBox14.Controls.Add(this.Button_WriteEPC_G2);
            this.groupBox14.Controls.Add(this.Edit_AccessCode3);
            this.groupBox14.Controls.Add(this.label26);
            this.groupBox14.Controls.Add(this.Edit_WriteEPC);
            this.groupBox14.Controls.Add(this.label25);
            this.groupBox14.Location = new System.Drawing.Point(485, 185);
            this.groupBox14.Name = "groupBox14";
            this.groupBox14.Size = new System.Drawing.Size(325, 79);
            this.groupBox14.TabIndex = 5;
            this.groupBox14.TabStop = false;
            this.groupBox14.Text = "Write EPC(Random write one tag in the antenna)";
            // 
            // Button_WriteEPC_G2
            // 
            this.Button_WriteEPC_G2.Enabled = false;
            this.Button_WriteEPC_G2.Location = new System.Drawing.Point(244, 48);
            this.Button_WriteEPC_G2.Name = "Button_WriteEPC_G2";
            this.Button_WriteEPC_G2.Size = new System.Drawing.Size(75, 25);
            this.Button_WriteEPC_G2.TabIndex = 4;
            this.Button_WriteEPC_G2.Text = "Write EPC";
            this.Button_WriteEPC_G2.UseVisualStyleBackColor = true;
            this.Button_WriteEPC_G2.Click += new System.EventHandler(this.Button_WriteEPC_G2_Click);
            // 
            // Edit_AccessCode3
            // 
            this.Edit_AccessCode3.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.Edit_AccessCode3.Location = new System.Drawing.Point(107, 50);
            this.Edit_AccessCode3.MaxLength = 8;
            this.Edit_AccessCode3.Name = "Edit_AccessCode3";
            this.Edit_AccessCode3.Size = new System.Drawing.Size(100, 20);
            this.Edit_AccessCode3.TabIndex = 3;
            this.Edit_AccessCode3.Text = "00000000";
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Location = new System.Drawing.Point(6, 44);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(91, 26);
            this.label26.TabIndex = 2;
            this.label26.Text = "Access Password\r\n(8 Hex):";
            // 
            // Edit_WriteEPC
            // 
            this.Edit_WriteEPC.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.Edit_WriteEPC.Location = new System.Drawing.Point(77, 18);
            this.Edit_WriteEPC.MaxLength = 60;
            this.Edit_WriteEPC.Name = "Edit_WriteEPC";
            this.Edit_WriteEPC.Size = new System.Drawing.Size(242, 20);
            this.Edit_WriteEPC.TabIndex = 1;
            this.Edit_WriteEPC.Text = "0000";
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Location = new System.Drawing.Point(6, 15);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(60, 26);
            this.label25.TabIndex = 0;
            this.label25.Text = "Write EPC:\r\n(1-15Word)";
            // 
            // groupBox13
            // 
            this.groupBox13.Controls.Add(this.Button_DestroyCard);
            this.groupBox13.Controls.Add(this.Edit_DestroyCode);
            this.groupBox13.Controls.Add(this.label24);
            this.groupBox13.Controls.Add(this.ComboBox_EPC3);
            this.groupBox13.Location = new System.Drawing.Point(485, 111);
            this.groupBox13.Name = "groupBox13";
            this.groupBox13.Size = new System.Drawing.Size(325, 73);
            this.groupBox13.TabIndex = 4;
            this.groupBox13.TabStop = false;
            this.groupBox13.Text = "Kill Tag";
            // 
            // Button_DestroyCard
            // 
            this.Button_DestroyCard.Location = new System.Drawing.Point(244, 42);
            this.Button_DestroyCard.Name = "Button_DestroyCard";
            this.Button_DestroyCard.Size = new System.Drawing.Size(75, 25);
            this.Button_DestroyCard.TabIndex = 3;
            this.Button_DestroyCard.Text = "Kill Tag";
            this.Button_DestroyCard.UseVisualStyleBackColor = true;
            this.Button_DestroyCard.Click += new System.EventHandler(this.Button_DestroyCard_Click);
            // 
            // Edit_DestroyCode
            // 
            this.Edit_DestroyCode.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.Edit_DestroyCode.Location = new System.Drawing.Point(115, 44);
            this.Edit_DestroyCode.MaxLength = 8;
            this.Edit_DestroyCode.Name = "Edit_DestroyCode";
            this.Edit_DestroyCode.Size = new System.Drawing.Size(92, 20);
            this.Edit_DestroyCode.TabIndex = 2;
            this.Edit_DestroyCode.Text = "00000000";
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Location = new System.Drawing.Point(6, 42);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(69, 26);
            this.label24.TabIndex = 1;
            this.label24.Text = "Kill Password\r\n(8 Hex):";
            // 
            // ComboBox_EPC3
            // 
            this.ComboBox_EPC3.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.ComboBox_EPC3.FormattingEnabled = true;
            this.ComboBox_EPC3.Location = new System.Drawing.Point(8, 16);
            this.ComboBox_EPC3.Name = "ComboBox_EPC3";
            this.ComboBox_EPC3.Size = new System.Drawing.Size(311, 21);
            this.ComboBox_EPC3.TabIndex = 0;
            // 
            // groupBox12
            // 
            this.groupBox12.Controls.Add(this.CheckBox_TID);
            this.groupBox12.Controls.Add(this.groupBox45);
            this.groupBox12.Controls.Add(this.button2);
            this.groupBox12.Controls.Add(this.ComboBox_IntervalTime);
            this.groupBox12.Controls.Add(this.label23);
            this.groupBox12.Location = new System.Drawing.Point(485, 0);
            this.groupBox12.Name = "groupBox12";
            this.groupBox12.Size = new System.Drawing.Size(325, 105);
            this.groupBox12.TabIndex = 3;
            this.groupBox12.TabStop = false;
            this.groupBox12.Text = "Query Tag";
            // 
            // CheckBox_TID
            // 
            this.CheckBox_TID.AutoSize = true;
            this.CheckBox_TID.Location = new System.Drawing.Point(235, 62);
            this.CheckBox_TID.Name = "CheckBox_TID";
            this.CheckBox_TID.Size = new System.Drawing.Size(44, 17);
            this.CheckBox_TID.TabIndex = 14;
            this.CheckBox_TID.Text = "TID";
            this.CheckBox_TID.UseVisualStyleBackColor = true;
            // 
            // groupBox45
            // 
            this.groupBox45.Controls.Add(this.textBox12);
            this.groupBox45.Controls.Add(this.label68);
            this.groupBox45.Controls.Add(this.textBox13);
            this.groupBox45.Controls.Add(this.label69);
            this.groupBox45.Location = new System.Drawing.Point(8, 43);
            this.groupBox45.Name = "groupBox45";
            this.groupBox45.Size = new System.Drawing.Size(214, 52);
            this.groupBox45.TabIndex = 13;
            this.groupBox45.TabStop = false;
            this.groupBox45.Text = "Query TID Parameter";
            // 
            // textBox12
            // 
            this.textBox12.Location = new System.Drawing.Point(69, 18);
            this.textBox12.MaxLength = 2;
            this.textBox12.Name = "textBox12";
            this.textBox12.Size = new System.Drawing.Size(37, 20);
            this.textBox12.TabIndex = 3;
            this.textBox12.Text = "02";
            // 
            // label68
            // 
            this.label68.AutoSize = true;
            this.label68.Location = new System.Drawing.Point(126, 25);
            this.label68.Name = "label68";
            this.label68.Size = new System.Drawing.Size(31, 13);
            this.label68.TabIndex = 2;
            this.label68.Text = "Len：";
            // 
            // textBox13
            // 
            this.textBox13.Location = new System.Drawing.Point(162, 18);
            this.textBox13.MaxLength = 2;
            this.textBox13.Name = "textBox13";
            this.textBox13.Size = new System.Drawing.Size(37, 20);
            this.textBox13.TabIndex = 1;
            this.textBox13.Text = "04";
            // 
            // label69
            // 
            this.label69.AutoSize = true;
            this.label69.Location = new System.Drawing.Point(4, 26);
            this.label69.Name = "label69";
            this.label69.Size = new System.Drawing.Size(57, 13);
            this.label69.TabIndex = 0;
            this.label69.Text = "StartAddr：";
            // 
            // button2
            // 
            this.button2.Enabled = false;
            this.button2.Location = new System.Drawing.Point(235, 12);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(84, 25);
            this.button2.TabIndex = 2;
            this.button2.Text = "Query Tag";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // ComboBox_IntervalTime
            // 
            this.ComboBox_IntervalTime.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.ComboBox_IntervalTime.FormattingEnabled = true;
            this.ComboBox_IntervalTime.Location = new System.Drawing.Point(117, 15);
            this.ComboBox_IntervalTime.Name = "ComboBox_IntervalTime";
            this.ComboBox_IntervalTime.Size = new System.Drawing.Size(105, 21);
            this.ComboBox_IntervalTime.TabIndex = 1;
            this.ComboBox_IntervalTime.SelectedIndexChanged += new System.EventHandler(this.ComboBox_IntervalTime_SelectedIndexChanged);
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Location = new System.Drawing.Point(6, 20);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(74, 13);
            this.label23.TabIndex = 0;
            this.label23.Text = "Read Interval:";
            // 
            // groupBox7
            // 
            this.groupBox7.Controls.Add(this.Button_SetProtectState);
            this.groupBox7.Controls.Add(this.textBox2);
            this.groupBox7.Controls.Add(this.label22);
            this.groupBox7.Controls.Add(this.groupBox11);
            this.groupBox7.Controls.Add(this.groupBox10);
            this.groupBox7.Controls.Add(this.groupBox8);
            this.groupBox7.Controls.Add(this.ComboBox_EPC1);
            this.groupBox7.Location = new System.Drawing.Point(1, 482);
            this.groupBox7.Name = "groupBox7";
            this.groupBox7.Size = new System.Drawing.Size(481, 192);
            this.groupBox7.TabIndex = 2;
            this.groupBox7.TabStop = false;
            this.groupBox7.Text = "Set Protect For Reading Or Writing";
            // 
            // Button_SetProtectState
            // 
            this.Button_SetProtectState.Location = new System.Drawing.Point(375, 159);
            this.Button_SetProtectState.Name = "Button_SetProtectState";
            this.Button_SetProtectState.Size = new System.Drawing.Size(99, 25);
            this.Button_SetProtectState.TabIndex = 6;
            this.Button_SetProtectState.Text = "Lock";
            this.Button_SetProtectState.UseVisualStyleBackColor = true;
            this.Button_SetProtectState.Click += new System.EventHandler(this.Button_SetProtectState_Click);
            // 
            // textBox2
            // 
            this.textBox2.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.textBox2.Location = new System.Drawing.Point(263, 161);
            this.textBox2.MaxLength = 8;
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(100, 20);
            this.textBox2.TabIndex = 5;
            this.textBox2.Text = "00000000";
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Location = new System.Drawing.Point(261, 142);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(131, 13);
            this.label22.TabIndex = 4;
            this.label22.Text = "Access Password (8 Hex):";
            // 
            // groupBox11
            // 
            this.groupBox11.Controls.Add(this.AlwaysNot2);
            this.groupBox11.Controls.Add(this.Always2);
            this.groupBox11.Controls.Add(this.Proect2);
            this.groupBox11.Controls.Add(this.NoProect2);
            this.groupBox11.Location = new System.Drawing.Point(258, 47);
            this.groupBox11.Name = "groupBox11";
            this.groupBox11.Size = new System.Drawing.Size(217, 90);
            this.groupBox11.TabIndex = 3;
            this.groupBox11.TabStop = false;
            this.groupBox11.Text = "Lock of EPC TID and User Bank";
            // 
            // AlwaysNot2
            // 
            this.AlwaysNot2.AutoSize = true;
            this.AlwaysNot2.Location = new System.Drawing.Point(4, 69);
            this.AlwaysNot2.Name = "AlwaysNot2";
            this.AlwaysNot2.Size = new System.Drawing.Size(99, 17);
            this.AlwaysNot2.TabIndex = 3;
            this.AlwaysNot2.TabStop = true;
            this.AlwaysNot2.Text = "Never writeable";
            this.AlwaysNot2.UseVisualStyleBackColor = true;
            // 
            // Always2
            // 
            this.Always2.AutoSize = true;
            this.Always2.Location = new System.Drawing.Point(4, 52);
            this.Always2.Name = "Always2";
            this.Always2.Size = new System.Drawing.Size(128, 17);
            this.Always2.TabIndex = 2;
            this.Always2.TabStop = true;
            this.Always2.Text = "Permanently writeable";
            this.Always2.UseVisualStyleBackColor = true;
            // 
            // Proect2
            // 
            this.Proect2.AutoSize = true;
            this.Proect2.Location = new System.Drawing.Point(4, 34);
            this.Proect2.Name = "Proect2";
            this.Proect2.Size = new System.Drawing.Size(178, 17);
            this.Proect2.TabIndex = 1;
            this.Proect2.TabStop = true;
            this.Proect2.Text = "Writeable from the secured state";
            this.Proect2.UseVisualStyleBackColor = true;
            // 
            // NoProect2
            // 
            this.NoProect2.AutoSize = true;
            this.NoProect2.Location = new System.Drawing.Point(4, 15);
            this.NoProect2.Name = "NoProect2";
            this.NoProect2.Size = new System.Drawing.Size(139, 17);
            this.NoProect2.TabIndex = 0;
            this.NoProect2.TabStop = true;
            this.NoProect2.Text = "Writeable from any state";
            this.NoProect2.UseVisualStyleBackColor = true;
            // 
            // groupBox10
            // 
            this.groupBox10.Controls.Add(this.P_User);
            this.groupBox10.Controls.Add(this.P_TID);
            this.groupBox10.Controls.Add(this.P_EPC);
            this.groupBox10.Controls.Add(this.P_Reserve);
            this.groupBox10.Location = new System.Drawing.Point(259, 13);
            this.groupBox10.Name = "groupBox10";
            this.groupBox10.Size = new System.Drawing.Size(215, 34);
            this.groupBox10.TabIndex = 2;
            this.groupBox10.TabStop = false;
            // 
            // P_User
            // 
            this.P_User.AutoSize = true;
            this.P_User.Location = new System.Drawing.Point(166, 12);
            this.P_User.Name = "P_User";
            this.P_User.Size = new System.Drawing.Size(47, 17);
            this.P_User.TabIndex = 3;
            this.P_User.TabStop = true;
            this.P_User.Text = "User";
            this.P_User.UseVisualStyleBackColor = true;
            this.P_User.CheckedChanged += new System.EventHandler(this.P_User_CheckedChanged);
            // 
            // P_TID
            // 
            this.P_TID.AutoSize = true;
            this.P_TID.Location = new System.Drawing.Point(121, 12);
            this.P_TID.Name = "P_TID";
            this.P_TID.Size = new System.Drawing.Size(43, 17);
            this.P_TID.TabIndex = 2;
            this.P_TID.TabStop = true;
            this.P_TID.Text = "TID";
            this.P_TID.UseVisualStyleBackColor = true;
            this.P_TID.CheckedChanged += new System.EventHandler(this.P_TID_CheckedChanged);
            // 
            // P_EPC
            // 
            this.P_EPC.AutoSize = true;
            this.P_EPC.Location = new System.Drawing.Point(76, 12);
            this.P_EPC.Name = "P_EPC";
            this.P_EPC.Size = new System.Drawing.Size(46, 17);
            this.P_EPC.TabIndex = 1;
            this.P_EPC.TabStop = true;
            this.P_EPC.Text = "EPC";
            this.P_EPC.UseVisualStyleBackColor = true;
            this.P_EPC.CheckedChanged += new System.EventHandler(this.P_EPC_CheckedChanged);
            // 
            // P_Reserve
            // 
            this.P_Reserve.AutoSize = true;
            this.P_Reserve.Location = new System.Drawing.Point(4, 12);
            this.P_Reserve.Name = "P_Reserve";
            this.P_Reserve.Size = new System.Drawing.Size(71, 17);
            this.P_Reserve.TabIndex = 0;
            this.P_Reserve.TabStop = true;
            this.P_Reserve.Text = "Password";
            this.P_Reserve.UseVisualStyleBackColor = true;
            this.P_Reserve.CheckedChanged += new System.EventHandler(this.P_Reserve_CheckedChanged);
            // 
            // groupBox8
            // 
            this.groupBox8.Controls.Add(this.AlwaysNot);
            this.groupBox8.Controls.Add(this.Always);
            this.groupBox8.Controls.Add(this.Proect);
            this.groupBox8.Controls.Add(this.NoProect);
            this.groupBox8.Controls.Add(this.groupBox9);
            this.groupBox8.Location = new System.Drawing.Point(4, 38);
            this.groupBox8.Name = "groupBox8";
            this.groupBox8.Size = new System.Drawing.Size(248, 147);
            this.groupBox8.TabIndex = 1;
            this.groupBox8.TabStop = false;
            this.groupBox8.Text = "Lock of Password";
            // 
            // AlwaysNot
            // 
            this.AlwaysNot.AutoSize = true;
            this.AlwaysNot.Location = new System.Drawing.Point(6, 127);
            this.AlwaysNot.Name = "AlwaysNot";
            this.AlwaysNot.Size = new System.Drawing.Size(164, 17);
            this.AlwaysNot.TabIndex = 4;
            this.AlwaysNot.TabStop = true;
            this.AlwaysNot.Text = "Never readable and writeable";
            this.AlwaysNot.UseVisualStyleBackColor = true;
            // 
            // Always
            // 
            this.Always.AutoSize = true;
            this.Always.Location = new System.Drawing.Point(6, 109);
            this.Always.Name = "Always";
            this.Always.Size = new System.Drawing.Size(193, 17);
            this.Always.TabIndex = 3;
            this.Always.TabStop = true;
            this.Always.Text = "Permanently readable and writeable";
            this.Always.UseVisualStyleBackColor = true;
            // 
            // Proect
            // 
            this.Proect.AutoSize = true;
            this.Proect.Location = new System.Drawing.Point(6, 80);
            this.Proect.Name = "Proect";
            this.Proect.Size = new System.Drawing.Size(181, 30);
            this.Proect.TabIndex = 2;
            this.Proect.TabStop = true;
            this.Proect.Text = "Readable and writeable from the \r\nsecured state";
            this.Proect.UseVisualStyleBackColor = true;
            // 
            // NoProect
            // 
            this.NoProect.AutoSize = true;
            this.NoProect.Location = new System.Drawing.Point(6, 50);
            this.NoProect.Name = "NoProect";
            this.NoProect.Size = new System.Drawing.Size(143, 30);
            this.NoProect.TabIndex = 1;
            this.NoProect.TabStop = true;
            this.NoProect.Text = "Readable and  writeable \r\nfrom any state";
            this.NoProect.UseVisualStyleBackColor = true;
            // 
            // groupBox9
            // 
            this.groupBox9.Controls.Add(this.AccessCode);
            this.groupBox9.Controls.Add(this.DestroyCode);
            this.groupBox9.Location = new System.Drawing.Point(5, 11);
            this.groupBox9.Name = "groupBox9";
            this.groupBox9.Size = new System.Drawing.Size(237, 34);
            this.groupBox9.TabIndex = 0;
            this.groupBox9.TabStop = false;
            // 
            // AccessCode
            // 
            this.AccessCode.AutoSize = true;
            this.AccessCode.Location = new System.Drawing.Point(108, 13);
            this.AccessCode.Name = "AccessCode";
            this.AccessCode.Size = new System.Drawing.Size(109, 17);
            this.AccessCode.TabIndex = 1;
            this.AccessCode.TabStop = true;
            this.AccessCode.Text = "Access Password";
            this.AccessCode.UseVisualStyleBackColor = true;
            // 
            // DestroyCode
            // 
            this.DestroyCode.AutoSize = true;
            this.DestroyCode.Location = new System.Drawing.Point(6, 13);
            this.DestroyCode.Name = "DestroyCode";
            this.DestroyCode.Size = new System.Drawing.Size(87, 17);
            this.DestroyCode.TabIndex = 0;
            this.DestroyCode.TabStop = true;
            this.DestroyCode.Text = "Kill Password";
            this.DestroyCode.UseVisualStyleBackColor = true;
            // 
            // ComboBox_EPC1
            // 
            this.ComboBox_EPC1.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.ComboBox_EPC1.FormattingEnabled = true;
            this.ComboBox_EPC1.Location = new System.Drawing.Point(4, 15);
            this.ComboBox_EPC1.Name = "ComboBox_EPC1";
            this.ComboBox_EPC1.Size = new System.Drawing.Size(249, 21);
            this.ComboBox_EPC1.TabIndex = 0;
            // 
            // groupBox5
            // 
            this.groupBox5.Controls.Add(this.textBox_pc);
            this.groupBox5.Controls.Add(this.checkBox_pc);
            this.groupBox5.Controls.Add(this.BlockWrite);
            this.groupBox5.Controls.Add(this.ComboBox_EPC2);
            this.groupBox5.Controls.Add(this.button7);
            this.groupBox5.Controls.Add(this.Button_BlockErase);
            this.groupBox5.Controls.Add(this.Button_DataWrite);
            this.groupBox5.Controls.Add(this.SpeedButton_Read_G2);
            this.groupBox5.Controls.Add(this.Edit_WriteData);
            this.groupBox5.Controls.Add(this.Edit_AccessCode2);
            this.groupBox5.Controls.Add(this.textBox1);
            this.groupBox5.Controls.Add(this.Edit_WordPtr);
            this.groupBox5.Controls.Add(this.listBox1);
            this.groupBox5.Controls.Add(this.label21);
            this.groupBox5.Controls.Add(this.label20);
            this.groupBox5.Controls.Add(this.label19);
            this.groupBox5.Controls.Add(this.label18);
            this.groupBox5.Controls.Add(this.groupBox6);
            this.groupBox5.Location = new System.Drawing.Point(1, 258);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Size = new System.Drawing.Size(481, 220);
            this.groupBox5.TabIndex = 1;
            this.groupBox5.TabStop = false;
            this.groupBox5.Text = "Read Data / Write Data / Block Erase";
            // 
            // textBox_pc
            // 
            this.textBox_pc.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.textBox_pc.Location = new System.Drawing.Point(431, 14);
            this.textBox_pc.Name = "textBox_pc";
            this.textBox_pc.ReadOnly = true;
            this.textBox_pc.Size = new System.Drawing.Size(43, 20);
            this.textBox_pc.TabIndex = 29;
            this.textBox_pc.Text = "0800";
            // 
            // checkBox_pc
            // 
            this.checkBox_pc.AutoSize = true;
            this.checkBox_pc.Location = new System.Drawing.Point(293, 20);
            this.checkBox_pc.Name = "checkBox_pc";
            this.checkBox_pc.Size = new System.Drawing.Size(127, 17);
            this.checkBox_pc.TabIndex = 28;
            this.checkBox_pc.Text = "Compute and add PC";
            this.checkBox_pc.UseVisualStyleBackColor = true;
            this.checkBox_pc.CheckedChanged += new System.EventHandler(this.checkBox_pc_CheckedChanged);
            // 
            // BlockWrite
            // 
            this.BlockWrite.Location = new System.Drawing.Point(90, 190);
            this.BlockWrite.Name = "BlockWrite";
            this.BlockWrite.Size = new System.Drawing.Size(73, 25);
            this.BlockWrite.TabIndex = 17;
            this.BlockWrite.Text = "BlockWrite";
            this.BlockWrite.UseVisualStyleBackColor = true;
            this.BlockWrite.Click += new System.EventHandler(this.BlockWrite_Click);
            // 
            // ComboBox_EPC2
            // 
            this.ComboBox_EPC2.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.ComboBox_EPC2.FormattingEnabled = true;
            this.ComboBox_EPC2.Location = new System.Drawing.Point(4, 17);
            this.ComboBox_EPC2.Name = "ComboBox_EPC2";
            this.ComboBox_EPC2.Size = new System.Drawing.Size(282, 21);
            this.ComboBox_EPC2.TabIndex = 15;
            // 
            // button7
            // 
            this.button7.Location = new System.Drawing.Point(244, 189);
            this.button7.Name = "button7";
            this.button7.Size = new System.Drawing.Size(43, 26);
            this.button7.TabIndex = 14;
            this.button7.Text = "Clear";
            this.button7.UseVisualStyleBackColor = true;
            this.button7.Click += new System.EventHandler(this.button7_Click);
            // 
            // Button_BlockErase
            // 
            this.Button_BlockErase.Location = new System.Drawing.Point(166, 190);
            this.Button_BlockErase.Name = "Button_BlockErase";
            this.Button_BlockErase.Size = new System.Drawing.Size(73, 25);
            this.Button_BlockErase.TabIndex = 13;
            this.Button_BlockErase.Text = "BlockErase";
            this.Button_BlockErase.UseVisualStyleBackColor = true;
            this.Button_BlockErase.Click += new System.EventHandler(this.Button_BlockErase_Click);
            // 
            // Button_DataWrite
            // 
            this.Button_DataWrite.Location = new System.Drawing.Point(43, 190);
            this.Button_DataWrite.Name = "Button_DataWrite";
            this.Button_DataWrite.Size = new System.Drawing.Size(43, 25);
            this.Button_DataWrite.TabIndex = 12;
            this.Button_DataWrite.Text = "Write";
            this.Button_DataWrite.UseVisualStyleBackColor = true;
            this.Button_DataWrite.Click += new System.EventHandler(this.Button_DataWrite_Click);
            // 
            // SpeedButton_Read_G2
            // 
            this.SpeedButton_Read_G2.Location = new System.Drawing.Point(4, 190);
            this.SpeedButton_Read_G2.Name = "SpeedButton_Read_G2";
            this.SpeedButton_Read_G2.Size = new System.Drawing.Size(37, 25);
            this.SpeedButton_Read_G2.TabIndex = 11;
            this.SpeedButton_Read_G2.Text = "Read";
            this.SpeedButton_Read_G2.UseVisualStyleBackColor = true;
            this.SpeedButton_Read_G2.Click += new System.EventHandler(this.SpeedButton_Read_G2_Click);
            // 
            // Edit_WriteData
            // 
            this.Edit_WriteData.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.Edit_WriteData.Location = new System.Drawing.Point(116, 165);
            this.Edit_WriteData.Name = "Edit_WriteData";
            this.Edit_WriteData.Size = new System.Drawing.Size(170, 20);
            this.Edit_WriteData.TabIndex = 10;
            this.Edit_WriteData.Text = "0000";
            this.Edit_WriteData.TextChanged += new System.EventHandler(this.Edit_WriteData_TextChanged);
            // 
            // Edit_AccessCode2
            // 
            this.Edit_AccessCode2.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.Edit_AccessCode2.Location = new System.Drawing.Point(170, 137);
            this.Edit_AccessCode2.MaxLength = 8;
            this.Edit_AccessCode2.Name = "Edit_AccessCode2";
            this.Edit_AccessCode2.Size = new System.Drawing.Size(115, 20);
            this.Edit_AccessCode2.TabIndex = 9;
            this.Edit_AccessCode2.Text = "00000000";
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(205, 107);
            this.textBox1.MaxLength = 2;
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(81, 20);
            this.textBox1.TabIndex = 8;
            this.textBox1.Text = "4";
            // 
            // Edit_WordPtr
            // 
            this.Edit_WordPtr.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.Edit_WordPtr.Location = new System.Drawing.Point(205, 74);
            this.Edit_WordPtr.MaxLength = 2;
            this.Edit_WordPtr.Name = "Edit_WordPtr";
            this.Edit_WordPtr.Size = new System.Drawing.Size(81, 20);
            this.Edit_WordPtr.TabIndex = 7;
            this.Edit_WordPtr.Text = "00";
            // 
            // listBox1
            // 
            this.listBox1.FormattingEnabled = true;
            this.listBox1.Location = new System.Drawing.Point(293, 41);
            this.listBox1.Name = "listBox1";
            this.listBox1.Size = new System.Drawing.Size(181, 173);
            this.listBox1.TabIndex = 6;
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Location = new System.Drawing.Point(8, 170);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(89, 13);
            this.label21.TabIndex = 5;
            this.label21.Text = "Write Data (Hex):";
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Location = new System.Drawing.Point(5, 133);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(147, 26);
            this.label20.TabIndex = 4;
            this.label20.Text = "Password(Read/Block Erase)\r\n(0-120/Word/D):";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(7, 111);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(172, 13);
            this.label19.TabIndex = 3;
            this.label19.Text = "Length of Data(Read/Block Erase:";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(8, 83);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(164, 13);
            this.label18.TabIndex = 2;
            this.label18.Text = "Address of Tag Data(Word/Hex):";
            // 
            // groupBox6
            // 
            this.groupBox6.Controls.Add(this.C_User);
            this.groupBox6.Controls.Add(this.C_TID);
            this.groupBox6.Controls.Add(this.C_EPC);
            this.groupBox6.Controls.Add(this.C_Reserve);
            this.groupBox6.Location = new System.Drawing.Point(6, 34);
            this.groupBox6.Name = "groupBox6";
            this.groupBox6.Size = new System.Drawing.Size(280, 34);
            this.groupBox6.TabIndex = 1;
            this.groupBox6.TabStop = false;
            // 
            // C_User
            // 
            this.C_User.AutoSize = true;
            this.C_User.Location = new System.Drawing.Point(207, 12);
            this.C_User.Name = "C_User";
            this.C_User.Size = new System.Drawing.Size(47, 17);
            this.C_User.TabIndex = 3;
            this.C_User.TabStop = true;
            this.C_User.Text = "User";
            this.C_User.UseVisualStyleBackColor = true;
            this.C_User.CheckedChanged += new System.EventHandler(this.C_User_CheckedChanged);
            // 
            // C_TID
            // 
            this.C_TID.AutoSize = true;
            this.C_TID.Location = new System.Drawing.Point(149, 12);
            this.C_TID.Name = "C_TID";
            this.C_TID.Size = new System.Drawing.Size(43, 17);
            this.C_TID.TabIndex = 2;
            this.C_TID.TabStop = true;
            this.C_TID.Text = "TID";
            this.C_TID.UseVisualStyleBackColor = true;
            this.C_TID.CheckedChanged += new System.EventHandler(this.C_TID_CheckedChanged);
            // 
            // C_EPC
            // 
            this.C_EPC.AutoSize = true;
            this.C_EPC.Location = new System.Drawing.Point(90, 12);
            this.C_EPC.Name = "C_EPC";
            this.C_EPC.Size = new System.Drawing.Size(46, 17);
            this.C_EPC.TabIndex = 1;
            this.C_EPC.TabStop = true;
            this.C_EPC.Text = "EPC";
            this.C_EPC.UseVisualStyleBackColor = true;
            this.C_EPC.CheckedChanged += new System.EventHandler(this.C_EPC_CheckedChanged);
            // 
            // C_Reserve
            // 
            this.C_Reserve.AutoSize = true;
            this.C_Reserve.Location = new System.Drawing.Point(4, 12);
            this.C_Reserve.Name = "C_Reserve";
            this.C_Reserve.Size = new System.Drawing.Size(71, 17);
            this.C_Reserve.TabIndex = 0;
            this.C_Reserve.TabStop = true;
            this.C_Reserve.Text = "Password";
            this.C_Reserve.UseVisualStyleBackColor = true;
            this.C_Reserve.CheckedChanged += new System.EventHandler(this.C_Reserve_CheckedChanged);
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.textBox18);
            this.groupBox4.Controls.Add(this.label80);
            this.groupBox4.Controls.Add(this.textBox17);
            this.groupBox4.Controls.Add(this.label79);
            this.groupBox4.Controls.Add(this.ListView1_EPC);
            this.groupBox4.Location = new System.Drawing.Point(1, 0);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(480, 182);
            this.groupBox4.TabIndex = 0;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "List EPC of Tags";
            // 
            // textBox18
            // 
            this.textBox18.Font = new System.Drawing.Font("SimSun", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.textBox18.ForeColor = System.Drawing.Color.Blue;
            this.textBox18.Location = new System.Drawing.Point(365, 13);
            this.textBox18.Name = "textBox18";
            this.textBox18.Size = new System.Drawing.Size(110, 44);
            this.textBox18.TabIndex = 5;
            // 
            // label80
            // 
            this.label80.AutoSize = true;
            this.label80.Location = new System.Drawing.Point(280, 36);
            this.label80.Name = "label80";
            this.label80.Size = new System.Drawing.Size(77, 13);
            this.label80.TabIndex = 4;
            this.label80.Text = "Total Number：";
            // 
            // textBox17
            // 
            this.textBox17.ForeColor = System.Drawing.Color.Blue;
            this.textBox17.Location = new System.Drawing.Point(4, 36);
            this.textBox17.Name = "textBox17";
            this.textBox17.Size = new System.Drawing.Size(255, 20);
            this.textBox17.TabIndex = 3;
            // 
            // label79
            // 
            this.label79.AutoSize = true;
            this.label79.Location = new System.Drawing.Point(3, 17);
            this.label79.Name = "label79";
            this.label79.Size = new System.Drawing.Size(71, 13);
            this.label79.TabIndex = 2;
            this.label79.Text = "Current EPC：";
            // 
            // ListView1_EPC
            // 
            this.ListView1_EPC.AccessibleRole = System.Windows.Forms.AccessibleRole.IpAddress;
            this.ListView1_EPC.AutoArrange = false;
            this.ListView1_EPC.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.ListView1_EPC.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.listViewCol_Number,
            this.listViewCol_ID,
            this.listViewCol_Length,
            this.columnHeader10,
            this.listViewCol_Times});
            this.ListView1_EPC.FullRowSelect = true;
            this.ListView1_EPC.GridLines = true;
            this.ListView1_EPC.Location = new System.Drawing.Point(3, 65);
            this.ListView1_EPC.Name = "ListView1_EPC";
            this.ListView1_EPC.Size = new System.Drawing.Size(474, 109);
            this.ListView1_EPC.TabIndex = 1;
            this.ListView1_EPC.UseCompatibleStateImageBehavior = false;
            this.ListView1_EPC.View = System.Windows.Forms.View.Details;
            this.ListView1_EPC.SelectedIndexChanged += new System.EventHandler(this.ListView1_EPC_SelectedIndexChanged);
            // 
            // listViewCol_Number
            // 
            this.listViewCol_Number.Text = "NO.";
            this.listViewCol_Number.Width = 40;
            // 
            // listViewCol_ID
            // 
            this.listViewCol_ID.Text = "EPC";
            this.listViewCol_ID.Width = 215;
            // 
            // listViewCol_Length
            // 
            this.listViewCol_Length.Text = "EPC Length";
            this.listViewCol_Length.Width = 75;
            // 
            // columnHeader10
            // 
            this.columnHeader10.Text = "ANT(4,3,2,1)";
            this.columnHeader10.Width = 90;
            // 
            // listViewCol_Times
            // 
            this.listViewCol_Times.Text = "Times";
            this.listViewCol_Times.Width = 50;
            // 
            // tabPage2
            // 
            this.tabPage2.Location = new System.Drawing.Point(4, 22);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(817, 678);
            this.tabPage2.TabIndex = 5;
            this.tabPage2.Text = "Auto_running Mode";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // TabSheet_6B
            // 
            this.TabSheet_6B.Location = new System.Drawing.Point(4, 22);
            this.TabSheet_6B.Name = "TabSheet_6B";
            this.TabSheet_6B.Size = new System.Drawing.Size(817, 678);
            this.TabSheet_6B.TabIndex = 3;
            this.TabSheet_6B.Text = "18000-6B Test";
            this.TabSheet_6B.UseVisualStyleBackColor = true;
            // 
            // tabPage1
            // 
            this.tabPage1.Location = new System.Drawing.Point(4, 22);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Size = new System.Drawing.Size(817, 678);
            this.tabPage1.TabIndex = 4;
            this.tabPage1.Text = "Frequency Analysis";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // tabPage3
            // 
            this.tabPage3.Location = new System.Drawing.Point(4, 22);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Size = new System.Drawing.Size(817, 678);
            this.tabPage3.TabIndex = 6;
            this.tabPage3.Text = "TCPIP net Config";
            this.tabPage3.UseVisualStyleBackColor = true;
            // 
            // columnHeader5
            // 
            this.columnHeader5.Text = "No.";
            this.columnHeader5.Width = 50;
            // 
            // columnHeader6
            // 
            this.columnHeader6.Text = "ID";
            this.columnHeader6.Width = 600;
            // 
            // columnHeader7
            // 
            this.columnHeader7.Text = "Times";
            this.columnHeader7.Width = 90;
            // 
            // columnHeader1
            // 
            this.columnHeader1.Text = "NO.";
            this.columnHeader1.Width = 50;
            // 
            // columnHeader2
            // 
            this.columnHeader2.Text = "EPC";
            this.columnHeader2.Width = 290;
            // 
            // columnHeader3
            // 
            this.columnHeader3.Text = "First read tag time";
            this.columnHeader3.Width = 150;
            // 
            // columnHeader4
            // 
            this.columnHeader4.Text = "Last read tag time";
            this.columnHeader4.Width = 150;
            // 
            // columnHeader8
            // 
            this.columnHeader8.Text = "ANT";
            this.columnHeader8.Width = 100;
            // 
            // columnHeader9
            // 
            this.columnHeader9.Text = "Times";
            this.columnHeader9.Width = 55;
            // 
            // StatusBar1
            // 
            this.StatusBar1.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.StatusBar1.Location = new System.Drawing.Point(0, 703);
            this.StatusBar1.Name = "StatusBar1";
            this.StatusBar1.Panels.AddRange(new System.Windows.Forms.StatusBarPanel[] {
            this.TStatusPanel,
            this.Port,
            this.Manufacturername});
            this.StatusBar1.ShowPanels = true;
            this.StatusBar1.Size = new System.Drawing.Size(826, 22);
            this.StatusBar1.SizingGrip = false;
            this.StatusBar1.TabIndex = 26;
            this.StatusBar1.Text = "StatusBar1";
            // 
            // TStatusPanel
            // 
            this.TStatusPanel.Name = "TStatusPanel";
            this.TStatusPanel.Width = 740;
            // 
            // Port
            // 
            this.Port.MinWidth = 66;
            this.Port.Name = "Port";
            this.Port.Text = "Port:";
            // 
            // Manufacturername
            // 
            this.Manufacturername.Name = "Manufacturername";
            this.Manufacturername.Text = "statusManufacturer nameBarPanel1";
            // 
            // Timer_Test_
            // 
            this.Timer_Test_.Tick += new System.EventHandler(this.Timer_Test__Tick);
            // 
            // Timer_G2_Read
            // 
            this.Timer_G2_Read.Interval = 200;
            this.Timer_G2_Read.Tick += new System.EventHandler(this.Timer_G2_Read_Tick);
            // 
            // Timer_G2_Alarm
            // 
            this.Timer_G2_Alarm.Tick += new System.EventHandler(this.Timer_G2_Alarm_Tick);
            // 
            // Timer_Test_6B
            // 
            this.Timer_Test_6B.Tick += new System.EventHandler(this.Timer_Test_6B_Tick);
            // 
            // Timer_6B_Read
            // 
            this.Timer_6B_Read.Tick += new System.EventHandler(this.Timer_6B_Read_Tick);
            // 
            // Timer_6B_Write
            // 
            this.Timer_6B_Write.Tick += new System.EventHandler(this.Timer_6B_Write_Tick);
            // 
            // timer1
            // 
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.ClientSize = new System.Drawing.Size(826, 725);
            this.Controls.Add(this.StatusBar1);
            this.Controls.Add(this.tabControl1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "UHFReader28CSHarp Demo Software V1.5";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.Form1_FormClosing);
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.Form1_FormClosed);
            this.Load += new System.EventHandler(this.Form1_Load);
            this.tabControl1.ResumeLayout(false);
            this.TabSheet_CMD.ResumeLayout(false);
            this.groupBox46.ResumeLayout(false);
            this.groupBox46.PerformLayout();
            this.groupBox42.ResumeLayout(false);
            this.groupBox42.PerformLayout();
            this.groupBox41.ResumeLayout(false);
            this.groupBox41.PerformLayout();
            this.GroupBox1.ResumeLayout(false);
            this.GroupBox1.PerformLayout();
            this.groupBox28.ResumeLayout(false);
            this.groupBox28.PerformLayout();
            this.groupBox27.ResumeLayout(false);
            this.groupBox27.PerformLayout();
            this.groupBox26.ResumeLayout(false);
            this.groupBox26.PerformLayout();
            this.groupBox25.ResumeLayout(false);
            this.groupBox25.PerformLayout();
            this.groupBox24.ResumeLayout(false);
            this.groupBox24.PerformLayout();
            this.groupBox23.ResumeLayout(false);
            this.groupBox23.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.groupBox30.ResumeLayout(false);
            this.groupBox30.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.tabPage4.ResumeLayout(false);
            this.groupBox48.ResumeLayout(false);
            this.groupBox48.PerformLayout();
            this.groupBox51.ResumeLayout(false);
            this.groupBox51.PerformLayout();
            this.panel_StaticIp.ResumeLayout(false);
            this.panel_StaticIp.PerformLayout();
            this.groupBox50.ResumeLayout(false);
            this.panel_TCP.ResumeLayout(false);
            this.panel_TCP.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.tcpRemotePortNUD)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tcpLocalPortNUD)).EndInit();
            this.groupBox49.ResumeLayout(false);
            this.panel4.ResumeLayout(false);
            this.panel4.PerformLayout();
            this.groupBox47.ResumeLayout(false);
            this.TabSheet_EPCC1G2.ResumeLayout(false);
            this.groupBox31.ResumeLayout(false);
            this.groupBox31.PerformLayout();
            this.groupBox40.ResumeLayout(false);
            this.groupBox40.PerformLayout();
            this.groupBox18.ResumeLayout(false);
            this.groupBox18.PerformLayout();
            this.groupBox16.ResumeLayout(false);
            this.groupBox16.PerformLayout();
            this.groupBox17.ResumeLayout(false);
            this.groupBox17.PerformLayout();
            this.groupBox15.ResumeLayout(false);
            this.groupBox15.PerformLayout();
            this.groupBox14.ResumeLayout(false);
            this.groupBox14.PerformLayout();
            this.groupBox13.ResumeLayout(false);
            this.groupBox13.PerformLayout();
            this.groupBox12.ResumeLayout(false);
            this.groupBox12.PerformLayout();
            this.groupBox45.ResumeLayout(false);
            this.groupBox45.PerformLayout();
            this.groupBox7.ResumeLayout(false);
            this.groupBox7.PerformLayout();
            this.groupBox11.ResumeLayout(false);
            this.groupBox11.PerformLayout();
            this.groupBox10.ResumeLayout(false);
            this.groupBox10.PerformLayout();
            this.groupBox8.ResumeLayout(false);
            this.groupBox8.PerformLayout();
            this.groupBox9.ResumeLayout(false);
            this.groupBox9.PerformLayout();
            this.groupBox5.ResumeLayout(false);
            this.groupBox5.PerformLayout();
            this.groupBox6.ResumeLayout(false);
            this.groupBox6.PerformLayout();
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.TStatusPanel)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Port)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Manufacturername)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage TabSheet_CMD;
        internal System.Windows.Forms.StatusBar StatusBar1;
        private System.Windows.Forms.StatusBarPanel TStatusPanel;
        private System.Windows.Forms.StatusBarPanel Port;
        private System.Windows.Forms.StatusBarPanel Manufacturername;
        private System.Windows.Forms.TabPage TabSheet_EPCC1G2;
        private System.Windows.Forms.TabPage TabSheet_6B;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.TextBox Edit_dmaxfre;
        private System.Windows.Forms.TextBox Edit_powerdBm;
        private System.Windows.Forms.TextBox Edit_Version;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox Edit_dminfre;
        private System.Windows.Forms.TextBox Edit_ComAdr;
        private System.Windows.Forms.TextBox Edit_Type;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Button Button3;
        private System.Windows.Forms.TextBox Edit_scantime;
        private System.Windows.Forms.CheckBox EPCC1G2;
        private System.Windows.Forms.CheckBox ISO180006B;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.ComboBox ComboBox_PowerDbm;
        private System.Windows.Forms.TextBox Edit_NewComAdr;
        private System.Windows.Forms.ComboBox ComboBox_dmaxfre;
        private System.Windows.Forms.ComboBox ComboBox_dminfre;
        private System.Windows.Forms.Button Button1;
        private System.Windows.Forms.Button Button5;
        private System.Windows.Forms.ComboBox ComboBox_scantime;
        private System.Windows.Forms.ComboBox ComboBox_baud;
        private System.Windows.Forms.CheckBox CheckBox_SameFre;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.GroupBox groupBox5;
        private System.Windows.Forms.GroupBox groupBox6;
        private System.Windows.Forms.RadioButton C_TID;
        private System.Windows.Forms.RadioButton C_EPC;
        private System.Windows.Forms.RadioButton C_Reserve;
        private System.Windows.Forms.RadioButton C_User;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.ListBox listBox1;
        private System.Windows.Forms.Button button7;
        private System.Windows.Forms.Button Button_BlockErase;
        private System.Windows.Forms.Button Button_DataWrite;
        private System.Windows.Forms.Button SpeedButton_Read_G2;
        private System.Windows.Forms.TextBox Edit_WriteData;
        private System.Windows.Forms.TextBox Edit_AccessCode2;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.TextBox Edit_WordPtr;
        private System.Windows.Forms.GroupBox groupBox7;
        private System.Windows.Forms.GroupBox groupBox8;
        private System.Windows.Forms.ComboBox ComboBox_EPC1;
        private System.Windows.Forms.RadioButton AlwaysNot;
        private System.Windows.Forms.RadioButton Always;
        private System.Windows.Forms.RadioButton Proect;
        private System.Windows.Forms.RadioButton NoProect;
        private System.Windows.Forms.GroupBox groupBox9;
        private System.Windows.Forms.RadioButton AccessCode;
        private System.Windows.Forms.RadioButton DestroyCode;
        private System.Windows.Forms.GroupBox groupBox10;
        private System.Windows.Forms.RadioButton P_User;
        private System.Windows.Forms.RadioButton P_TID;
        private System.Windows.Forms.RadioButton P_EPC;
        private System.Windows.Forms.RadioButton P_Reserve;
        private System.Windows.Forms.GroupBox groupBox11;
        private System.Windows.Forms.RadioButton Always2;
        private System.Windows.Forms.RadioButton Proect2;
        private System.Windows.Forms.RadioButton NoProect2;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.RadioButton AlwaysNot2;
        private System.Windows.Forms.Button Button_SetProtectState;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.GroupBox groupBox12;
        private System.Windows.Forms.GroupBox groupBox13;
        private System.Windows.Forms.ComboBox ComboBox_IntervalTime;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Button Button_DestroyCard;
        private System.Windows.Forms.TextBox Edit_DestroyCode;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.ComboBox ComboBox_EPC3;
        private System.Windows.Forms.GroupBox groupBox14;
        private System.Windows.Forms.Button Button_WriteEPC_G2;
        private System.Windows.Forms.TextBox Edit_AccessCode3;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.TextBox Edit_WriteEPC;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.GroupBox groupBox15;
        private System.Windows.Forms.Button Button_CheckReadProtected_G2;
        private System.Windows.Forms.Button Button_RemoveReadProtect_G2;
        private System.Windows.Forms.Button Button_SetMultiReadProtect_G2;
        private System.Windows.Forms.Button Button_SetReadProtect_G2;
        private System.Windows.Forms.TextBox Edit_AccessCode4;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.ComboBox ComboBox_EPC4;
        private System.Windows.Forms.GroupBox groupBox16;
        private System.Windows.Forms.ComboBox ComboBox_EPC5;
        private System.Windows.Forms.GroupBox groupBox17;
        private System.Windows.Forms.TextBox Edit_AccessCode5;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.RadioButton NoAlarm_G2;
        private System.Windows.Forms.RadioButton Alarm_G2;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Button Button_SetEASAlarm_G2;
        private System.Windows.Forms.Label Label_Alarm;
        private System.Windows.Forms.GroupBox groupBox18;
        private System.Windows.Forms.ComboBox ComboBox_BlockNum;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.ComboBox ComboBox_EPC6;
        private System.Windows.Forms.Button Button_LockUserBlock_G2;
        private System.Windows.Forms.TextBox Edit_AccessCode6;
        private System.Windows.Forms.ColumnHeader columnHeader5;
        private System.Windows.Forms.ColumnHeader columnHeader6;
        private System.Windows.Forms.ColumnHeader columnHeader7;
        private System.Windows.Forms.ProgressBar progressBar1;
        private System.Windows.Forms.Timer Timer_Test_;
        private System.Windows.Forms.ComboBox ComboBox_EPC2;
        private System.Windows.Forms.Timer Timer_G2_Read;
        private System.Windows.Forms.Timer Timer_G2_Alarm;
        private System.Windows.Forms.ListView ListView1_EPC;
        private System.Windows.Forms.ColumnHeader listViewCol_Number;
        private System.Windows.Forms.ColumnHeader listViewCol_ID;
        private System.Windows.Forms.ColumnHeader listViewCol_Length;
        private System.Windows.Forms.ColumnHeader listViewCol_Times;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Timer Timer_Test_6B;
        private System.Windows.Forms.Timer Timer_6B_Read;
        private System.Windows.Forms.Timer Timer_6B_Write;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.GroupBox groupBox30;
        private System.Windows.Forms.RadioButton radioButton_band4;
        private System.Windows.Forms.RadioButton radioButton_band3;
        private System.Windows.Forms.RadioButton radioButton_band2;
        private System.Windows.Forms.RadioButton radioButton_band1;
        private System.Windows.Forms.GroupBox groupBox31;
        private System.Windows.Forms.TextBox maskLen_textBox;
        private System.Windows.Forms.Label label44;
        private System.Windows.Forms.TextBox maskadr_textbox;
        private System.Windows.Forms.Label label43;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.Button BlockWrite;
        private System.Windows.Forms.RadioButton radioButton_band5;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.GroupBox groupBox23;
        private System.Windows.Forms.Button Button_GetGPIO;
        private System.Windows.Forms.Button Button_SetGPIO;
        private System.Windows.Forms.CheckBox checkBox9;
        private System.Windows.Forms.CheckBox checkBox8;
        private System.Windows.Forms.CheckBox checkBox7;
        private System.Windows.Forms.CheckBox checkBox6;
        private System.Windows.Forms.CheckBox checkBox5;
        private System.Windows.Forms.CheckBox checkBox4;
        private System.Windows.Forms.CheckBox checkBox3;
        private System.Windows.Forms.CheckBox checkBox2;
        private System.Windows.Forms.GroupBox groupBox25;
        private System.Windows.Forms.Label label37;
        private System.Windows.Forms.GroupBox groupBox24;
        private System.Windows.Forms.Button Button_Ant;
        private System.Windows.Forms.CheckBox checkBox13;
        private System.Windows.Forms.CheckBox checkBox12;
        private System.Windows.Forms.CheckBox checkBox11;
        private System.Windows.Forms.CheckBox checkBox10;
        internal System.Windows.Forms.GroupBox groupBox26;
        internal System.Windows.Forms.Button ClockCMD;
        internal System.Windows.Forms.RadioButton GetClock;
        internal System.Windows.Forms.RadioButton SetClock;
        internal System.Windows.Forms.Label label39;
        internal System.Windows.Forms.Label label40;
        internal System.Windows.Forms.Label label41;
        internal System.Windows.Forms.Label label42;
        internal System.Windows.Forms.Label label45;
        internal System.Windows.Forms.TextBox Text_sec;
        internal System.Windows.Forms.TextBox Text_min;
        internal System.Windows.Forms.TextBox Text_hour;
        internal System.Windows.Forms.TextBox Text_day;
        internal System.Windows.Forms.TextBox Text_month;
        internal System.Windows.Forms.Label label46;
        internal System.Windows.Forms.TextBox Text_year;
        internal System.Windows.Forms.TextBox TextBox5;
        private System.Windows.Forms.Button Button_RelayTime;
        private System.Windows.Forms.Label label38;
        private System.Windows.Forms.ComboBox ComboBox_RelayTime;
        private System.Windows.Forms.GroupBox groupBox27;
        private System.Windows.Forms.Button Button_OutputRep;
        private System.Windows.Forms.CheckBox checkBox14;
        private System.Windows.Forms.CheckBox checkBox15;
        private System.Windows.Forms.CheckBox checkBox16;
        private System.Windows.Forms.CheckBox checkBox17;
        private System.Windows.Forms.GroupBox groupBox28;
        private System.Windows.Forms.RadioButton Radio_beepDis;
        private System.Windows.Forms.RadioButton Radio_beepEn;
        private System.Windows.Forms.Button Button_Beep;
        private System.Windows.Forms.ColumnHeader columnHeader1;
        private System.Windows.Forms.ColumnHeader columnHeader2;
        private System.Windows.Forms.ColumnHeader columnHeader3;
        private System.Windows.Forms.ColumnHeader columnHeader4;
        private System.Windows.Forms.ColumnHeader columnHeader8;
        private System.Windows.Forms.ColumnHeader columnHeader9;
        private System.Windows.Forms.GroupBox groupBox40;
        private System.Windows.Forms.CheckBox checkBox1;
        private System.Windows.Forms.RadioButton R_EPC;
        private System.Windows.Forms.TextBox maskData_textBox;
        private System.Windows.Forms.Label label60;
        private System.Windows.Forms.RadioButton R_User;
        private System.Windows.Forms.RadioButton R_TID;
        private System.Windows.Forms.ColumnHeader columnHeader10;
        private System.Windows.Forms.TabPage tabPage3;
        private System.Windows.Forms.GroupBox groupBox42;
        private System.Windows.Forms.RadioButton radioButton1;
        internal System.Windows.Forms.GroupBox GroupBox1;
        private System.Windows.Forms.ComboBox ComboBox_baud2;
        private System.Windows.Forms.Label label47;
        private System.Windows.Forms.ComboBox ComboBox_AlreadyOpenCOM;
        private System.Windows.Forms.Label label3;
        internal System.Windows.Forms.Button ClosePort;
        internal System.Windows.Forms.Button OpenPort;
        internal System.Windows.Forms.TextBox Edit_CmdComAddr;
        internal System.Windows.Forms.Label Label2;
        internal System.Windows.Forms.ComboBox ComboBox_COM;
        internal System.Windows.Forms.Label Label1;
        private System.Windows.Forms.GroupBox groupBox41;
        private System.Windows.Forms.Button CloseNetPort;
        private System.Windows.Forms.Button OpenNetPort;
        private System.Windows.Forms.TextBox textBox9;
        private System.Windows.Forms.Label label63;
        private System.Windows.Forms.TextBox textBox8;
        private System.Windows.Forms.Label label62;
        private System.Windows.Forms.TextBox textBox7;
        private System.Windows.Forms.Label label61;
        private System.Windows.Forms.RadioButton radioButton2;
        private System.Windows.Forms.CheckBox CheckBox_TID;
        private System.Windows.Forms.GroupBox groupBox45;
        private System.Windows.Forms.TextBox textBox12;
        private System.Windows.Forms.Label label68;
        private System.Windows.Forms.TextBox textBox13;
        private System.Windows.Forms.Label label69;
        private System.Windows.Forms.TextBox textBox_pc;
        private System.Windows.Forms.CheckBox checkBox_pc;
        private System.Windows.Forms.TabPage tabPage4;
        private System.Windows.Forms.GroupBox groupBox48;
        private System.Windows.Forms.Label label71;
        private System.Windows.Forms.ComboBox comboBox6;
        private System.Windows.Forms.Label label70;
        private System.Windows.Forms.Button button30;
        private System.Windows.Forms.Button button29;
        private System.Windows.Forms.TextBox textBox16;
        private System.Windows.Forms.TextBox textBox15;
        private System.Windows.Forms.GroupBox groupBox51;
        private System.Windows.Forms.Button button36;
        private System.Windows.Forms.Button button33;
        private System.Windows.Forms.Label label110;
        private System.Windows.Forms.TextBox macTB;
        private System.Windows.Forms.Panel panel_StaticIp;
        private System.Windows.Forms.Label label109;
        private System.Windows.Forms.Label label108;
        private System.Windows.Forms.Label label107;
        private System.Windows.Forms.Label label106;
        private System.Windows.Forms.Label label105;
        private System.Windows.Forms.TextBox altDNSTB;
        private System.Windows.Forms.TextBox pDNSTB;
        private System.Windows.Forms.TextBox gatewayTB;
        private System.Windows.Forms.TextBox subnetTB;
        private System.Windows.Forms.TextBox ipTB;
        private System.Windows.Forms.GroupBox groupBox50;
        private System.Windows.Forms.Button button35;
        private System.Windows.Forms.Button button32;
        private System.Windows.Forms.Panel panel_TCP;
        private System.Windows.Forms.Label label87;
        private System.Windows.Forms.Label label88;
        private System.Windows.Forms.Label label89;
        private System.Windows.Forms.Label label90;
        private System.Windows.Forms.Label label93;
        private System.Windows.Forms.ComboBox workasCB;
        private System.Windows.Forms.TextBox tcpRomteHostTB;
        private System.Windows.Forms.NumericUpDown tcpRemotePortNUD;
        private System.Windows.Forms.NumericUpDown tcpLocalPortNUD;
        private System.Windows.Forms.ComboBox tcpActiveCB;
        private System.Windows.Forms.GroupBox groupBox49;
        private System.Windows.Forms.Button button34;
        private System.Windows.Forms.Button button31;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Label label72;
        private System.Windows.Forms.Label label73;
        private System.Windows.Forms.Label label74;
        private System.Windows.Forms.Label label75;
        private System.Windows.Forms.Label label76;
        private System.Windows.Forms.Label label77;
        private System.Windows.Forms.Label label78;
        private System.Windows.Forms.ComboBox protocolCB;
        private System.Windows.Forms.ComboBox stopbitCB;
        private System.Windows.Forms.ComboBox parityCB;
        private System.Windows.Forms.ComboBox databitCB;
        private System.Windows.Forms.ComboBox baudrateCB;
        private System.Windows.Forms.ComboBox flowCB;
        private System.Windows.Forms.ComboBox fifoCB;
        private System.Windows.Forms.GroupBox groupBox47;
        private System.Windows.Forms.Button button28;
        private System.Windows.Forms.Button button27;
        private System.Windows.Forms.GroupBox groupBox46;
        private System.Windows.Forms.Button button26;
        private System.Windows.Forms.TextBox textBox14;
        private System.Windows.Forms.Button button25;
        private System.Windows.Forms.Button button37;
        private System.Windows.Forms.TextBox textBox18;
        private System.Windows.Forms.Label label80;
        private System.Windows.Forms.TextBox textBox17;
        private System.Windows.Forms.Label label79;
    }
}

