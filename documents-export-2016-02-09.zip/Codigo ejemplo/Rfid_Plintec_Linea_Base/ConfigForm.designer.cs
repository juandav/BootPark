﻿namespace RFid_Plintec
{
    partial class ConfigForm
    {
        /// <summary>
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows 窗体设计器生成的代码

        /// <summary>
        /// 设计器支持所需的方法 - 不要
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            this.tabControl = new System.Windows.Forms.TabControl();
            this.tabPage_Basic = new System.Windows.Forms.TabPage();
            this.numericUpDown7 = new System.Windows.Forms.NumericUpDown();
            this.numericUpDown6 = new System.Windows.Forms.NumericUpDown();
            this.numericUpDown5 = new System.Windows.Forms.NumericUpDown();
            this.numericUpDown4 = new System.Windows.Forms.NumericUpDown();
            this.numericUpDown3 = new System.Windows.Forms.NumericUpDown();
            this.numericUpDown2 = new System.Windows.Forms.NumericUpDown();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.telnetCB = new System.Windows.Forms.CheckBox();
            this.webCB = new System.Windows.Forms.CheckBox();
            this.terminalTB = new System.Windows.Forms.TextBox();
            this.timeServerTB = new System.Windows.Forms.TextBox();
            this.timeZoneCB = new System.Windows.Forms.ComboBox();
            this.nameTB = new System.Windows.Forms.TextBox();
            this.tabPage_Network = new System.Windows.Forms.TabPage();
            this.label113 = new System.Windows.Forms.Label();
            this.comboBox_IpConfig = new System.Windows.Forms.ComboBox();
            this.checkBox2 = new System.Windows.Forms.CheckBox();
            this.label110 = new System.Windows.Forms.Label();
            this.macTB = new System.Windows.Forms.TextBox();
            this.panel3 = new System.Windows.Forms.Panel();
            this.label112 = new System.Windows.Forms.Label();
            this.label111 = new System.Windows.Forms.Label();
            this.duplexCB = new System.Windows.Forms.ComboBox();
            this.speedCB = new System.Windows.Forms.ComboBox();
            this.panel_StaticIp = new System.Windows.Forms.Panel();
            this.label109 = new System.Windows.Forms.Label();
            this.label108 = new System.Windows.Forms.Label();
            this.label107 = new System.Windows.Forms.Label();
            this.label106 = new System.Windows.Forms.Label();
            this.label105 = new System.Windows.Forms.Label();
            this.altDNSTB = new System.Windows.Forms.TextBox();
            this.pDNSTB = new System.Windows.Forms.TextBox();
            this.gatewayTB = new System.Windows.Forms.TextBox();
            this.subnetTB = new System.Windows.Forms.TextBox();
            this.ipTB = new System.Windows.Forms.TextBox();
            this.panel_AutoIp = new System.Windows.Forms.Panel();
            this.label104 = new System.Windows.Forms.Label();
            this.label103 = new System.Windows.Forms.Label();
            this.label102 = new System.Windows.Forms.Label();
            this.label101 = new System.Windows.Forms.Label();
            this.dhcpNameTB = new System.Windows.Forms.TextBox();
            this.autoIPCB = new System.Windows.Forms.CheckBox();
            this.dhcpCB = new System.Windows.Forms.CheckBox();
            this.bootpCB = new System.Windows.Forms.CheckBox();
            this.tabPage_PPP = new System.Windows.Forms.TabPage();
            this.label47 = new System.Windows.Forms.Label();
            this.label42 = new System.Windows.Forms.Label();
            this.label41 = new System.Windows.Forms.Label();
            this.label40 = new System.Windows.Forms.Label();
            this.label39 = new System.Windows.Forms.Label();
            this.label38 = new System.Windows.Forms.Label();
            this.label37 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.pppComCB = new System.Windows.Forms.ComboBox();
            this.pppDNS2TB = new System.Windows.Forms.TextBox();
            this.pppDNS1TB = new System.Windows.Forms.TextBox();
            this.pppGatewayTB = new System.Windows.Forms.TextBox();
            this.pppIPTB = new System.Windows.Forms.TextBox();
            this.pppStatusTB = new System.Windows.Forms.TextBox();
            this.pppIDLENUD = new System.Windows.Forms.NumericUpDown();
            this.pppRINUD = new System.Windows.Forms.NumericUpDown();
            this.pppMaxRTNUD = new System.Windows.Forms.NumericUpDown();
            this.pppWorkModeCB = new System.Windows.Forms.ComboBox();
            this.pppPwdTB = new System.Windows.Forms.TextBox();
            this.pppUserNameTB = new System.Windows.Forms.TextBox();
            this.tabPage_PPPoE = new System.Windows.Forms.TabPage();
            this.tabPage_Sever = new System.Windows.Forms.TabPage();
            this.label13 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.cpuCB = new System.Windows.Forms.ComboBox();
            this.mtuTB = new System.Windows.Forms.TextBox();
            this.httpPortNUD = new System.Windows.Forms.NumericUpDown();
            this.arpNUD = new System.Windows.Forms.NumericUpDown();
            this.tabPage_Serial = new System.Windows.Forms.TabPage();
            this.label99 = new System.Windows.Forms.Label();
            this.comboBox_SerialChannel = new System.Windows.Forms.ComboBox();
            this.panel9 = new System.Windows.Forms.Panel();
            this.label63 = new System.Windows.Forms.Label();
            this.panel6 = new System.Windows.Forms.Panel();
            this.label61 = new System.Windows.Forms.Label();
            this.label60 = new System.Windows.Forms.Label();
            this.lastTB = new System.Windows.Forms.TextBox();
            this.firstCharTB = new System.Windows.Forms.TextBox();
            this.sendBytesCB = new System.Windows.Forms.ComboBox();
            this.match2CB = new System.Windows.Forms.CheckBox();
            this.sendFrameCB = new System.Windows.Forms.CheckBox();
            this.idleCB = new System.Windows.Forms.ComboBox();
            this.enablePackCB = new System.Windows.Forms.CheckBox();
            this.panel4 = new System.Windows.Forms.Panel();
            this.label62 = new System.Windows.Forms.Label();
            this.protocolCB = new System.Windows.Forms.ComboBox();
            this.stopbitCB = new System.Windows.Forms.ComboBox();
            this.parityCB = new System.Windows.Forms.ComboBox();
            this.databitCB = new System.Windows.Forms.ComboBox();
            this.baudrateCB = new System.Windows.Forms.ComboBox();
            this.flowCB = new System.Windows.Forms.ComboBox();
            this.fifoCB = new System.Windows.Forms.ComboBox();
            this.serialOptionCB = new System.Windows.Forms.CheckBox();
            this.channelNameL1 = new System.Windows.Forms.Label();
            this.tabPage_Connection = new System.Windows.Forms.TabPage();
            this.label100 = new System.Windows.Forms.Label();
            this.comboBox_ConnChannel = new System.Windows.Forms.ComboBox();
            this.netProtocolCB = new System.Windows.Forms.ComboBox();
            this.channelNameL2 = new System.Windows.Forms.Label();
            this.panel_TCP = new System.Windows.Forms.Panel();
            this.numericUpDown1 = new System.Windows.Forms.NumericUpDown();
            this.label84 = new System.Windows.Forms.Label();
            this.label83 = new System.Windows.Forms.Label();
            this.label82 = new System.Windows.Forms.Label();
            this.label81 = new System.Windows.Forms.Label();
            this.label80 = new System.Windows.Forms.Label();
            this.label79 = new System.Windows.Forms.Label();
            this.label78 = new System.Windows.Forms.Label();
            this.label77 = new System.Windows.Forms.Label();
            this.label76 = new System.Windows.Forms.Label();
            this.label75 = new System.Windows.Forms.Label();
            this.label68 = new System.Windows.Forms.Label();
            this.inactivityNUD = new System.Windows.Forms.NumericUpDown();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.label74 = new System.Windows.Forms.Label();
            this.label73 = new System.Windows.Forms.Label();
            this.label72 = new System.Windows.Forms.Label();
            this.oatdCB = new System.Windows.Forms.CheckBox();
            this.owacCB = new System.Windows.Forms.CheckBox();
            this.owpcCB = new System.Windows.Forms.CheckBox();
            this.workasCB = new System.Windows.Forms.ComboBox();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.label71 = new System.Windows.Forms.Label();
            this.label70 = new System.Windows.Forms.Label();
            this.label69 = new System.Windows.Forms.Label();
            this.iwacCB = new System.Windows.Forms.CheckBox();
            this.iwpcCB = new System.Windows.Forms.CheckBox();
            this.iatdCB = new System.Windows.Forms.CheckBox();
            this.dnsQueryPeriodNUD = new System.Windows.Forms.NumericUpDown();
            this.hardDisconnectCB = new System.Windows.Forms.CheckBox();
            this.checkEOTCB = new System.Windows.Forms.CheckBox();
            this.onDSRDropCB = new System.Windows.Forms.CheckBox();
            this.connectResponseCB = new System.Windows.Forms.ComboBox();
            this.tcpRomteHostTB = new System.Windows.Forms.TextBox();
            this.useHostlistCB = new System.Windows.Forms.CheckBox();
            this.tcpRemotePortNUD = new System.Windows.Forms.NumericUpDown();
            this.tcpLocalPortNUD = new System.Windows.Forms.NumericUpDown();
            this.startCharTB = new System.Windows.Forms.TextBox();
            this.tcpActiveCB = new System.Windows.Forms.ComboBox();
            this.panel_UDP = new System.Windows.Forms.Panel();
            this.label98 = new System.Windows.Forms.Label();
            this.label94 = new System.Windows.Forms.Label();
            this.label93 = new System.Windows.Forms.Label();
            this.udpUCLPNUD = new System.Windows.Forms.NumericUpDown();
            this.tableLayoutPanel2 = new System.Windows.Forms.TableLayoutPanel();
            this.eAddr3TB = new System.Windows.Forms.TextBox();
            this.bAddr3TB = new System.Windows.Forms.TextBox();
            this.eAddr2TB = new System.Windows.Forms.TextBox();
            this.bAddr2TB = new System.Windows.Forms.TextBox();
            this.eAddr1TB = new System.Windows.Forms.TextBox();
            this.bAddr1TB = new System.Windows.Forms.TextBox();
            this.eAddr0TB = new System.Windows.Forms.TextBox();
            this.bAddr0TB = new System.Windows.Forms.TextBox();
            this.label85 = new System.Windows.Forms.Label();
            this.label86 = new System.Windows.Forms.Label();
            this.label87 = new System.Windows.Forms.Label();
            this.label88 = new System.Windows.Forms.Label();
            this.label89 = new System.Windows.Forms.Label();
            this.label90 = new System.Windows.Forms.Label();
            this.label91 = new System.Windows.Forms.Label();
            this.label92 = new System.Windows.Forms.Label();
            this.udpPort0TB = new System.Windows.Forms.NumericUpDown();
            this.udpPort1TB = new System.Windows.Forms.NumericUpDown();
            this.udpPort2TB = new System.Windows.Forms.NumericUpDown();
            this.udpPort3TB = new System.Windows.Forms.NumericUpDown();
            this.panel7 = new System.Windows.Forms.Panel();
            this.label97 = new System.Windows.Forms.Label();
            this.label96 = new System.Windows.Forms.Label();
            this.label95 = new System.Windows.Forms.Label();
            this.udpRemoteIpTB = new System.Windows.Forms.TextBox();
            this.udpRemotePortNUD = new System.Windows.Forms.NumericUpDown();
            this.udpLocalPortNUD = new System.Windows.Forms.NumericUpDown();
            this.datagramCB = new System.Windows.Forms.ComboBox();
            this.tabPage_Hostlist = new System.Windows.Forms.TabPage();
            this.label43 = new System.Windows.Forms.Label();
            this.comboBox_HostChannel = new System.Windows.Forms.ComboBox();
            this.groupBox6 = new System.Windows.Forms.GroupBox();
            this.label10 = new System.Windows.Forms.Label();
            this.checkBox1 = new System.Windows.Forms.CheckBox();
            this.label9 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.retryCNUD = new System.Windows.Forms.NumericUpDown();
            this.retryTNUD = new System.Windows.Forms.NumericUpDown();
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.hostPort12TB = new System.Windows.Forms.TextBox();
            this.hostIP12TB = new System.Windows.Forms.TextBox();
            this.hostPort11TB = new System.Windows.Forms.TextBox();
            this.hostIP11TB = new System.Windows.Forms.TextBox();
            this.hostPort10TB = new System.Windows.Forms.TextBox();
            this.hostIP10TB = new System.Windows.Forms.TextBox();
            this.hostPort9TB = new System.Windows.Forms.TextBox();
            this.hostIP9TB = new System.Windows.Forms.TextBox();
            this.hostPort8TB = new System.Windows.Forms.TextBox();
            this.hostIP8TB = new System.Windows.Forms.TextBox();
            this.hostPort7TB = new System.Windows.Forms.TextBox();
            this.hostIP7TB = new System.Windows.Forms.TextBox();
            this.hostPort6TB = new System.Windows.Forms.TextBox();
            this.hostIP6TB = new System.Windows.Forms.TextBox();
            this.hostPort5TB = new System.Windows.Forms.TextBox();
            this.hostIP5TB = new System.Windows.Forms.TextBox();
            this.hostPort4TB = new System.Windows.Forms.TextBox();
            this.hostIP4TB = new System.Windows.Forms.TextBox();
            this.hostPort3TB = new System.Windows.Forms.TextBox();
            this.hostIP3TB = new System.Windows.Forms.TextBox();
            this.hostPort2TB = new System.Windows.Forms.TextBox();
            this.hostIP2TB = new System.Windows.Forms.TextBox();
            this.hostPort1TB = new System.Windows.Forms.TextBox();
            this.label20 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this.label24 = new System.Windows.Forms.Label();
            this.label25 = new System.Windows.Forms.Label();
            this.label26 = new System.Windows.Forms.Label();
            this.label27 = new System.Windows.Forms.Label();
            this.label28 = new System.Windows.Forms.Label();
            this.label29 = new System.Windows.Forms.Label();
            this.label30 = new System.Windows.Forms.Label();
            this.hostIP1TB = new System.Windows.Forms.TextBox();
            this.channelNameL = new System.Windows.Forms.Label();
            this.tabPage_Password = new System.Windows.Forms.TabPage();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.oldPwdTB = new System.Windows.Forms.TextBox();
            this.retypePwdTB = new System.Windows.Forms.TextBox();
            this.newPwdTB = new System.Windows.Forms.TextBox();
            this.label46 = new System.Windows.Forms.Label();
            this.label45 = new System.Windows.Forms.Label();
            this.label44 = new System.Windows.Forms.Label();
            this.tabPage_Power = new System.Windows.Forms.TabPage();
            this.groupBox7 = new System.Windows.Forms.GroupBox();
            this.radioButton_Default = new System.Windows.Forms.RadioButton();
            this.radioButton_SaveReboot = new System.Windows.Forms.RadioButton();
            this.radioButton_DefaultReboot = new System.Windows.Forms.RadioButton();
            this.radioButton_Reboot = new System.Windows.Forms.RadioButton();
            this.button_Refresh = new System.Windows.Forms.Button();
            this.button_OK = new System.Windows.Forms.Button();
            this.button_Close = new System.Windows.Forms.Button();
            this.Lable_Message = new System.Windows.Forms.Label();
            this.tabControl.SuspendLayout();
            this.tabPage_Basic.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown2)).BeginInit();
            this.tabPage_Network.SuspendLayout();
            this.panel3.SuspendLayout();
            this.panel_StaticIp.SuspendLayout();
            this.panel_AutoIp.SuspendLayout();
            this.tabPage_PPP.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pppIDLENUD)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pppRINUD)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pppMaxRTNUD)).BeginInit();
            this.tabPage_Sever.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.httpPortNUD)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.arpNUD)).BeginInit();
            this.tabPage_Serial.SuspendLayout();
            this.panel9.SuspendLayout();
            this.panel6.SuspendLayout();
            this.panel4.SuspendLayout();
            this.tabPage_Connection.SuspendLayout();
            this.panel_TCP.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.inactivityNUD)).BeginInit();
            this.groupBox5.SuspendLayout();
            this.groupBox4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dnsQueryPeriodNUD)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tcpRemotePortNUD)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tcpLocalPortNUD)).BeginInit();
            this.panel_UDP.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.udpUCLPNUD)).BeginInit();
            this.tableLayoutPanel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.udpPort0TB)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.udpPort1TB)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.udpPort2TB)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.udpPort3TB)).BeginInit();
            this.panel7.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.udpRemotePortNUD)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.udpLocalPortNUD)).BeginInit();
            this.tabPage_Hostlist.SuspendLayout();
            this.groupBox6.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.retryCNUD)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.retryTNUD)).BeginInit();
            this.tableLayoutPanel1.SuspendLayout();
            this.tabPage_Password.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.tabPage_Power.SuspendLayout();
            this.groupBox7.SuspendLayout();
            this.SuspendLayout();
            // 
            // tabControl
            // 
            this.tabControl.Controls.Add(this.tabPage_Basic);
            this.tabControl.Controls.Add(this.tabPage_Network);
            this.tabControl.Controls.Add(this.tabPage_PPP);
            this.tabControl.Controls.Add(this.tabPage_PPPoE);
            this.tabControl.Controls.Add(this.tabPage_Sever);
            this.tabControl.Controls.Add(this.tabPage_Serial);
            this.tabControl.Controls.Add(this.tabPage_Connection);
            this.tabControl.Controls.Add(this.tabPage_Hostlist);
            this.tabControl.Controls.Add(this.tabPage_Password);
            this.tabControl.Controls.Add(this.tabPage_Power);
            this.tabControl.Location = new System.Drawing.Point(12, 12);
            this.tabControl.Multiline = true;
            this.tabControl.Name = "tabControl";
            this.tabControl.SelectedIndex = 0;
            this.tabControl.Size = new System.Drawing.Size(474, 333);
            this.tabControl.TabIndex = 0;
            this.tabControl.Selected += new System.Windows.Forms.TabControlEventHandler(this.tabControl_Selected);
            // 
            // tabPage_Basic
            // 
            this.tabPage_Basic.Controls.Add(this.numericUpDown7);
            this.tabPage_Basic.Controls.Add(this.numericUpDown6);
            this.tabPage_Basic.Controls.Add(this.numericUpDown5);
            this.tabPage_Basic.Controls.Add(this.numericUpDown4);
            this.tabPage_Basic.Controls.Add(this.numericUpDown3);
            this.tabPage_Basic.Controls.Add(this.numericUpDown2);
            this.tabPage_Basic.Controls.Add(this.label7);
            this.tabPage_Basic.Controls.Add(this.label6);
            this.tabPage_Basic.Controls.Add(this.label5);
            this.tabPage_Basic.Controls.Add(this.label4);
            this.tabPage_Basic.Controls.Add(this.label3);
            this.tabPage_Basic.Controls.Add(this.label2);
            this.tabPage_Basic.Controls.Add(this.label1);
            this.tabPage_Basic.Controls.Add(this.telnetCB);
            this.tabPage_Basic.Controls.Add(this.webCB);
            this.tabPage_Basic.Controls.Add(this.terminalTB);
            this.tabPage_Basic.Controls.Add(this.timeServerTB);
            this.tabPage_Basic.Controls.Add(this.timeZoneCB);
            this.tabPage_Basic.Controls.Add(this.nameTB);
            this.tabPage_Basic.Location = new System.Drawing.Point(4, 38);
            this.tabPage_Basic.Name = "tabPage_Basic";
            this.tabPage_Basic.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage_Basic.Size = new System.Drawing.Size(466, 291);
            this.tabPage_Basic.TabIndex = 0;
            this.tabPage_Basic.Text = "Basic Setting";
            this.tabPage_Basic.UseVisualStyleBackColor = true;
            // 
            // numericUpDown7
            // 
            this.numericUpDown7.AccessibleName = "TimeSec";
            this.numericUpDown7.Location = new System.Drawing.Point(391, 125);
            this.numericUpDown7.Maximum = new decimal(new int[] {
            255,
            0,
            0,
            0});
            this.numericUpDown7.Name = "numericUpDown7";
            this.numericUpDown7.Size = new System.Drawing.Size(37, 21);
            this.numericUpDown7.TabIndex = 132;
            // 
            // numericUpDown6
            // 
            this.numericUpDown6.AccessibleName = "TimeMin";
            this.numericUpDown6.Location = new System.Drawing.Point(348, 125);
            this.numericUpDown6.Maximum = new decimal(new int[] {
            255,
            0,
            0,
            0});
            this.numericUpDown6.Name = "numericUpDown6";
            this.numericUpDown6.Size = new System.Drawing.Size(37, 21);
            this.numericUpDown6.TabIndex = 131;
            // 
            // numericUpDown5
            // 
            this.numericUpDown5.AccessibleName = "TimeHour";
            this.numericUpDown5.Location = new System.Drawing.Point(305, 125);
            this.numericUpDown5.Maximum = new decimal(new int[] {
            255,
            0,
            0,
            0});
            this.numericUpDown5.Name = "numericUpDown5";
            this.numericUpDown5.Size = new System.Drawing.Size(37, 21);
            this.numericUpDown5.TabIndex = 130;
            // 
            // numericUpDown4
            // 
            this.numericUpDown4.AccessibleName = "TimeDay";
            this.numericUpDown4.Location = new System.Drawing.Point(251, 125);
            this.numericUpDown4.Maximum = new decimal(new int[] {
            255,
            0,
            0,
            0});
            this.numericUpDown4.Name = "numericUpDown4";
            this.numericUpDown4.Size = new System.Drawing.Size(37, 21);
            this.numericUpDown4.TabIndex = 129;
            // 
            // numericUpDown3
            // 
            this.numericUpDown3.AccessibleName = "TimeMon";
            this.numericUpDown3.Location = new System.Drawing.Point(208, 125);
            this.numericUpDown3.Maximum = new decimal(new int[] {
            255,
            0,
            0,
            0});
            this.numericUpDown3.Name = "numericUpDown3";
            this.numericUpDown3.Size = new System.Drawing.Size(37, 21);
            this.numericUpDown3.TabIndex = 128;
            // 
            // numericUpDown2
            // 
            this.numericUpDown2.AccessibleName = "TimeYear";
            this.numericUpDown2.Location = new System.Drawing.Point(157, 125);
            this.numericUpDown2.Maximum = new decimal(new int[] {
            5000,
            0,
            0,
            0});
            this.numericUpDown2.Name = "numericUpDown2";
            this.numericUpDown2.Size = new System.Drawing.Size(45, 21);
            this.numericUpDown2.TabIndex = 127;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(248, 229);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(89, 12);
            this.label7.TabIndex = 41;
            this.label7.Text = "Telnet Console";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(40, 255);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(83, 12);
            this.label6.TabIndex = 40;
            this.label6.Text = "Terminal Name";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(40, 230);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(71, 12);
            this.label5.TabIndex = 39;
            this.label5.Text = "Web Console";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(40, 154);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(71, 12);
            this.label4.TabIndex = 38;
            this.label4.Text = "Time Server";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(40, 126);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(65, 12);
            this.label3.TabIndex = 37;
            this.label3.Text = "Local Time";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(40, 99);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(59, 12);
            this.label2.TabIndex = 36;
            this.label2.Text = "Time Zone";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(40, 37);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(71, 12);
            this.label1.TabIndex = 35;
            this.label1.Text = "Server Name";
            // 
            // telnetCB
            // 
            this.telnetCB.AccessibleName = "TelnetConsole";
            this.telnetCB.AutoSize = true;
            this.telnetCB.Location = new System.Drawing.Point(354, 229);
            this.telnetCB.Name = "telnetCB";
            this.telnetCB.Size = new System.Drawing.Size(60, 16);
            this.telnetCB.TabIndex = 34;
            this.telnetCB.Text = "Enable";
            this.telnetCB.UseVisualStyleBackColor = true;
            // 
            // webCB
            // 
            this.webCB.AccessibleName = "WebConsole";
            this.webCB.AutoSize = true;
            this.webCB.Location = new System.Drawing.Point(155, 229);
            this.webCB.Name = "webCB";
            this.webCB.Size = new System.Drawing.Size(60, 16);
            this.webCB.TabIndex = 33;
            this.webCB.Text = "Enable";
            this.webCB.UseVisualStyleBackColor = true;
            // 
            // terminalTB
            // 
            this.terminalTB.AccessibleName = "TerminalName";
            this.terminalTB.Location = new System.Drawing.Point(153, 255);
            this.terminalTB.MaxLength = 32;
            this.terminalTB.Name = "terminalTB";
            this.terminalTB.Size = new System.Drawing.Size(266, 21);
            this.terminalTB.TabIndex = 32;
            // 
            // timeServerTB
            // 
            this.timeServerTB.AccessibleName = "TimeServer";
            this.timeServerTB.Location = new System.Drawing.Point(157, 154);
            this.timeServerTB.MaxLength = 32;
            this.timeServerTB.Name = "timeServerTB";
            this.timeServerTB.Size = new System.Drawing.Size(266, 21);
            this.timeServerTB.TabIndex = 31;
            // 
            // timeZoneCB
            // 
            this.timeZoneCB.AccessibleName = "TimeZone";
            this.timeZoneCB.FormattingEnabled = true;
            this.timeZoneCB.Items.AddRange(new object[] {
            "(GMT)Greenwich Mean Time: Dublin, Edinburgh, Lisbon, London",
            "(GMT+08:00)Beijing, Chongqing, Hong Kong, Urumqi",
            "(GMT-05:00)Eastern Time (US & Canada)"});
            this.timeZoneCB.Location = new System.Drawing.Point(157, 99);
            this.timeZoneCB.Name = "timeZoneCB";
            this.timeZoneCB.Size = new System.Drawing.Size(266, 20);
            this.timeZoneCB.TabIndex = 29;
            // 
            // nameTB
            // 
            this.nameTB.AccessibleName = "ServerName";
            this.nameTB.Location = new System.Drawing.Point(157, 37);
            this.nameTB.MaxLength = 32;
            this.nameTB.Name = "nameTB";
            this.nameTB.Size = new System.Drawing.Size(266, 21);
            this.nameTB.TabIndex = 28;
            // 
            // tabPage_Network
            // 
            this.tabPage_Network.Controls.Add(this.label113);
            this.tabPage_Network.Controls.Add(this.comboBox_IpConfig);
            this.tabPage_Network.Controls.Add(this.checkBox2);
            this.tabPage_Network.Controls.Add(this.label110);
            this.tabPage_Network.Controls.Add(this.macTB);
            this.tabPage_Network.Controls.Add(this.panel3);
            this.tabPage_Network.Controls.Add(this.panel_StaticIp);
            this.tabPage_Network.Controls.Add(this.panel_AutoIp);
            this.tabPage_Network.Location = new System.Drawing.Point(4, 38);
            this.tabPage_Network.Name = "tabPage_Network";
            this.tabPage_Network.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage_Network.Size = new System.Drawing.Size(466, 291);
            this.tabPage_Network.TabIndex = 1;
            this.tabPage_Network.Text = "Network Settings";
            this.tabPage_Network.UseVisualStyleBackColor = true;
            // 
            // label113
            // 
            this.label113.AutoSize = true;
            this.label113.Location = new System.Drawing.Point(43, 10);
            this.label113.Name = "label113";
            this.label113.Size = new System.Drawing.Size(101, 12);
            this.label113.TabIndex = 46;
            this.label113.Text = "IP Configuration";
            // 
            // comboBox_IpConfig
            // 
            this.comboBox_IpConfig.AccessibleName = "IpConfig";
            this.comboBox_IpConfig.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox_IpConfig.FormattingEnabled = true;
            this.comboBox_IpConfig.Items.AddRange(new object[] {
            "User Config",
            "Obtain Automatically"});
            this.comboBox_IpConfig.Location = new System.Drawing.Point(45, 25);
            this.comboBox_IpConfig.Name = "comboBox_IpConfig";
            this.comboBox_IpConfig.Size = new System.Drawing.Size(183, 20);
            this.comboBox_IpConfig.TabIndex = 54;
            // 
            // checkBox2
            // 
            this.checkBox2.AccessibleName = "AutoNegotiate";
            this.checkBox2.AutoSize = true;
            this.checkBox2.Location = new System.Drawing.Point(257, 98);
            this.checkBox2.Name = "checkBox2";
            this.checkBox2.Size = new System.Drawing.Size(108, 16);
            this.checkBox2.TabIndex = 46;
            this.checkBox2.Text = "Auto Negotiate";
            this.checkBox2.UseVisualStyleBackColor = true;
            // 
            // label110
            // 
            this.label110.AutoSize = true;
            this.label110.Location = new System.Drawing.Point(255, 57);
            this.label110.Name = "label110";
            this.label110.Size = new System.Drawing.Size(71, 12);
            this.label110.TabIndex = 51;
            this.label110.Text = "Mac Address";
            // 
            // macTB
            // 
            this.macTB.AccessibleName = "MacAddress";
            this.macTB.Location = new System.Drawing.Point(257, 73);
            this.macTB.Name = "macTB";
            this.macTB.Size = new System.Drawing.Size(176, 21);
            this.macTB.TabIndex = 41;
            // 
            // panel3
            // 
            this.panel3.Controls.Add(this.label112);
            this.panel3.Controls.Add(this.label111);
            this.panel3.Controls.Add(this.duplexCB);
            this.panel3.Controls.Add(this.speedCB);
            this.panel3.Location = new System.Drawing.Point(257, 120);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(158, 56);
            this.panel3.TabIndex = 40;
            // 
            // label112
            // 
            this.label112.AutoSize = true;
            this.label112.Location = new System.Drawing.Point(15, 31);
            this.label112.Name = "label112";
            this.label112.Size = new System.Drawing.Size(41, 12);
            this.label112.TabIndex = 53;
            this.label112.Text = "Duplex";
            // 
            // label111
            // 
            this.label111.AutoSize = true;
            this.label111.Location = new System.Drawing.Point(15, 7);
            this.label111.Name = "label111";
            this.label111.Size = new System.Drawing.Size(35, 12);
            this.label111.TabIndex = 52;
            this.label111.Text = "Speed";
            // 
            // duplexCB
            // 
            this.duplexCB.AccessibleName = "NetcardDuplex";
            this.duplexCB.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.duplexCB.FormattingEnabled = true;
            this.duplexCB.Items.AddRange(new object[] {
            "Half",
            "Full"});
            this.duplexCB.Location = new System.Drawing.Point(81, 28);
            this.duplexCB.Name = "duplexCB";
            this.duplexCB.Size = new System.Drawing.Size(65, 20);
            this.duplexCB.TabIndex = 31;
            // 
            // speedCB
            // 
            this.speedCB.AccessibleName = "NetcardSpeed";
            this.speedCB.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.speedCB.FormattingEnabled = true;
            this.speedCB.Items.AddRange(new object[] {
            "10Mbps",
            "100Mbps"});
            this.speedCB.Location = new System.Drawing.Point(81, 4);
            this.speedCB.Name = "speedCB";
            this.speedCB.Size = new System.Drawing.Size(65, 20);
            this.speedCB.TabIndex = 30;
            // 
            // panel_StaticIp
            // 
            this.panel_StaticIp.Controls.Add(this.label109);
            this.panel_StaticIp.Controls.Add(this.label108);
            this.panel_StaticIp.Controls.Add(this.label107);
            this.panel_StaticIp.Controls.Add(this.label106);
            this.panel_StaticIp.Controls.Add(this.label105);
            this.panel_StaticIp.Controls.Add(this.altDNSTB);
            this.panel_StaticIp.Controls.Add(this.pDNSTB);
            this.panel_StaticIp.Controls.Add(this.gatewayTB);
            this.panel_StaticIp.Controls.Add(this.subnetTB);
            this.panel_StaticIp.Controls.Add(this.ipTB);
            this.panel_StaticIp.Location = new System.Drawing.Point(45, 51);
            this.panel_StaticIp.Name = "panel_StaticIp";
            this.panel_StaticIp.Size = new System.Drawing.Size(179, 173);
            this.panel_StaticIp.TabIndex = 39;
            // 
            // label109
            // 
            this.label109.AutoSize = true;
            this.label109.Location = new System.Drawing.Point(3, 128);
            this.label109.Name = "label109";
            this.label109.Size = new System.Drawing.Size(125, 12);
            this.label109.TabIndex = 50;
            this.label109.Text = "Alternate DNS Server";
            // 
            // label108
            // 
            this.label108.AutoSize = true;
            this.label108.Location = new System.Drawing.Point(3, 86);
            this.label108.Name = "label108";
            this.label108.Size = new System.Drawing.Size(125, 12);
            this.label108.TabIndex = 49;
            this.label108.Text = "Preferred DNS Server";
            // 
            // label107
            // 
            this.label107.AutoSize = true;
            this.label107.Location = new System.Drawing.Point(3, 60);
            this.label107.Name = "label107";
            this.label107.Size = new System.Drawing.Size(47, 12);
            this.label107.TabIndex = 48;
            this.label107.Text = "Gateway";
            // 
            // label106
            // 
            this.label106.AutoSize = true;
            this.label106.Location = new System.Drawing.Point(3, 33);
            this.label106.Name = "label106";
            this.label106.Size = new System.Drawing.Size(41, 12);
            this.label106.TabIndex = 47;
            this.label106.Text = "Subnet";
            // 
            // label105
            // 
            this.label105.AutoSize = true;
            this.label105.Location = new System.Drawing.Point(3, 6);
            this.label105.Name = "label105";
            this.label105.Size = new System.Drawing.Size(65, 12);
            this.label105.TabIndex = 46;
            this.label105.Text = "IP Address";
            // 
            // altDNSTB
            // 
            this.altDNSTB.AccessibleName = "AlternateDNS";
            this.altDNSTB.Location = new System.Drawing.Point(79, 143);
            this.altDNSTB.Name = "altDNSTB";
            this.altDNSTB.Size = new System.Drawing.Size(97, 21);
            this.altDNSTB.TabIndex = 43;
            // 
            // pDNSTB
            // 
            this.pDNSTB.AccessibleName = "PreferredDNS";
            this.pDNSTB.Location = new System.Drawing.Point(79, 101);
            this.pDNSTB.Name = "pDNSTB";
            this.pDNSTB.Size = new System.Drawing.Size(97, 21);
            this.pDNSTB.TabIndex = 42;
            // 
            // gatewayTB
            // 
            this.gatewayTB.AccessibleName = "Gateway";
            this.gatewayTB.Location = new System.Drawing.Point(79, 57);
            this.gatewayTB.Name = "gatewayTB";
            this.gatewayTB.Size = new System.Drawing.Size(97, 21);
            this.gatewayTB.TabIndex = 41;
            // 
            // subnetTB
            // 
            this.subnetTB.AccessibleName = "Subnet";
            this.subnetTB.Location = new System.Drawing.Point(79, 30);
            this.subnetTB.Name = "subnetTB";
            this.subnetTB.Size = new System.Drawing.Size(97, 21);
            this.subnetTB.TabIndex = 40;
            // 
            // ipTB
            // 
            this.ipTB.AccessibleName = "IpAddress";
            this.ipTB.Location = new System.Drawing.Point(79, 3);
            this.ipTB.Name = "ipTB";
            this.ipTB.Size = new System.Drawing.Size(97, 21);
            this.ipTB.TabIndex = 39;
            // 
            // panel_AutoIp
            // 
            this.panel_AutoIp.Controls.Add(this.label104);
            this.panel_AutoIp.Controls.Add(this.label103);
            this.panel_AutoIp.Controls.Add(this.label102);
            this.panel_AutoIp.Controls.Add(this.label101);
            this.panel_AutoIp.Controls.Add(this.dhcpNameTB);
            this.panel_AutoIp.Controls.Add(this.autoIPCB);
            this.panel_AutoIp.Controls.Add(this.dhcpCB);
            this.panel_AutoIp.Controls.Add(this.bootpCB);
            this.panel_AutoIp.Location = new System.Drawing.Point(45, 51);
            this.panel_AutoIp.Name = "panel_AutoIp";
            this.panel_AutoIp.Size = new System.Drawing.Size(204, 97);
            this.panel_AutoIp.TabIndex = 38;
            // 
            // label104
            // 
            this.label104.AutoSize = true;
            this.label104.Location = new System.Drawing.Point(3, 73);
            this.label104.Name = "label104";
            this.label104.Size = new System.Drawing.Size(89, 12);
            this.label104.TabIndex = 45;
            this.label104.Text = "DHCP Host Name";
            // 
            // label103
            // 
            this.label103.AutoSize = true;
            this.label103.Location = new System.Drawing.Point(3, 49);
            this.label103.Name = "label103";
            this.label103.Size = new System.Drawing.Size(41, 12);
            this.label103.TabIndex = 44;
            this.label103.Text = "AutoIP";
            // 
            // label102
            // 
            this.label102.AutoSize = true;
            this.label102.Location = new System.Drawing.Point(3, 29);
            this.label102.Name = "label102";
            this.label102.Size = new System.Drawing.Size(29, 12);
            this.label102.TabIndex = 43;
            this.label102.Text = "DHCP";
            // 
            // label101
            // 
            this.label101.AutoSize = true;
            this.label101.Location = new System.Drawing.Point(3, 9);
            this.label101.Name = "label101";
            this.label101.Size = new System.Drawing.Size(35, 12);
            this.label101.TabIndex = 42;
            this.label101.Text = "BOOTP";
            // 
            // dhcpNameTB
            // 
            this.dhcpNameTB.AccessibleName = "DHCPName";
            this.dhcpNameTB.Location = new System.Drawing.Point(98, 70);
            this.dhcpNameTB.Name = "dhcpNameTB";
            this.dhcpNameTB.Size = new System.Drawing.Size(97, 21);
            this.dhcpNameTB.TabIndex = 34;
            // 
            // autoIPCB
            // 
            this.autoIPCB.AccessibleName = "AutoIP";
            this.autoIPCB.AutoSize = true;
            this.autoIPCB.Location = new System.Drawing.Point(98, 48);
            this.autoIPCB.Name = "autoIPCB";
            this.autoIPCB.Size = new System.Drawing.Size(60, 16);
            this.autoIPCB.TabIndex = 32;
            this.autoIPCB.Text = "Enable";
            this.autoIPCB.UseVisualStyleBackColor = true;
            // 
            // dhcpCB
            // 
            this.dhcpCB.AccessibleName = "DHCP";
            this.dhcpCB.AutoSize = true;
            this.dhcpCB.Location = new System.Drawing.Point(98, 28);
            this.dhcpCB.Name = "dhcpCB";
            this.dhcpCB.Size = new System.Drawing.Size(60, 16);
            this.dhcpCB.TabIndex = 30;
            this.dhcpCB.Text = "Enable";
            this.dhcpCB.UseVisualStyleBackColor = true;
            // 
            // bootpCB
            // 
            this.bootpCB.AccessibleName = "BOOTP";
            this.bootpCB.AutoSize = true;
            this.bootpCB.Location = new System.Drawing.Point(98, 8);
            this.bootpCB.Name = "bootpCB";
            this.bootpCB.Size = new System.Drawing.Size(60, 16);
            this.bootpCB.TabIndex = 28;
            this.bootpCB.Text = "Enable";
            this.bootpCB.UseVisualStyleBackColor = true;
            // 
            // tabPage_PPP
            // 
            this.tabPage_PPP.Controls.Add(this.label47);
            this.tabPage_PPP.Controls.Add(this.label42);
            this.tabPage_PPP.Controls.Add(this.label41);
            this.tabPage_PPP.Controls.Add(this.label40);
            this.tabPage_PPP.Controls.Add(this.label39);
            this.tabPage_PPP.Controls.Add(this.label38);
            this.tabPage_PPP.Controls.Add(this.label37);
            this.tabPage_PPP.Controls.Add(this.label12);
            this.tabPage_PPP.Controls.Add(this.pppComCB);
            this.tabPage_PPP.Controls.Add(this.pppDNS2TB);
            this.tabPage_PPP.Controls.Add(this.pppDNS1TB);
            this.tabPage_PPP.Controls.Add(this.pppGatewayTB);
            this.tabPage_PPP.Controls.Add(this.pppIPTB);
            this.tabPage_PPP.Controls.Add(this.pppStatusTB);
            this.tabPage_PPP.Controls.Add(this.pppIDLENUD);
            this.tabPage_PPP.Controls.Add(this.pppRINUD);
            this.tabPage_PPP.Controls.Add(this.pppMaxRTNUD);
            this.tabPage_PPP.Controls.Add(this.pppWorkModeCB);
            this.tabPage_PPP.Controls.Add(this.pppPwdTB);
            this.tabPage_PPP.Controls.Add(this.pppUserNameTB);
            this.tabPage_PPP.Location = new System.Drawing.Point(4, 38);
            this.tabPage_PPP.Name = "tabPage_PPP";
            this.tabPage_PPP.Size = new System.Drawing.Size(466, 291);
            this.tabPage_PPP.TabIndex = 3;
            this.tabPage_PPP.Text = "PPP";
            this.tabPage_PPP.UseVisualStyleBackColor = true;
            // 
            // label47
            // 
            this.label47.AutoSize = true;
            this.label47.Location = new System.Drawing.Point(47, 189);
            this.label47.Name = "label47";
            this.label47.Size = new System.Drawing.Size(59, 12);
            this.label47.TabIndex = 138;
            this.label47.Text = "Idle Time";
            // 
            // label42
            // 
            this.label42.AutoSize = true;
            this.label42.Location = new System.Drawing.Point(47, 164);
            this.label42.Name = "label42";
            this.label42.Size = new System.Drawing.Size(95, 12);
            this.label42.TabIndex = 137;
            this.label42.Text = "Redial Interval";
            // 
            // label41
            // 
            this.label41.AutoSize = true;
            this.label41.Location = new System.Drawing.Point(47, 135);
            this.label41.Name = "label41";
            this.label41.Size = new System.Drawing.Size(101, 12);
            this.label41.TabIndex = 136;
            this.label41.Text = "Max Redial Times";
            // 
            // label40
            // 
            this.label40.AutoSize = true;
            this.label40.Location = new System.Drawing.Point(239, 164);
            this.label40.Name = "label40";
            this.label40.Size = new System.Drawing.Size(53, 12);
            this.label40.TabIndex = 135;
            this.label40.Text = "PPP DNS2";
            // 
            // label39
            // 
            this.label39.AutoSize = true;
            this.label39.Location = new System.Drawing.Point(239, 137);
            this.label39.Name = "label39";
            this.label39.Size = new System.Drawing.Size(53, 12);
            this.label39.TabIndex = 134;
            this.label39.Text = "PPP DNS1";
            // 
            // label38
            // 
            this.label38.AutoSize = true;
            this.label38.Location = new System.Drawing.Point(239, 110);
            this.label38.Name = "label38";
            this.label38.Size = new System.Drawing.Size(71, 12);
            this.label38.TabIndex = 133;
            this.label38.Text = "PPP Gateway";
            // 
            // label37
            // 
            this.label37.AutoSize = true;
            this.label37.Location = new System.Drawing.Point(239, 83);
            this.label37.Name = "label37";
            this.label37.Size = new System.Drawing.Size(41, 12);
            this.label37.TabIndex = 132;
            this.label37.Text = "PPP IP";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(47, 56);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(59, 12);
            this.label12.TabIndex = 128;
            this.label12.Text = "User Name";
            // 
            // pppComCB
            // 
            this.pppComCB.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.pppComCB.FormattingEnabled = true;
            this.pppComCB.Location = new System.Drawing.Point(163, 219);
            this.pppComCB.Name = "pppComCB";
            this.pppComCB.Size = new System.Drawing.Size(60, 20);
            this.pppComCB.TabIndex = 127;
            // 
            // pppDNS2TB
            // 
            this.pppDNS2TB.Enabled = false;
            this.pppDNS2TB.Location = new System.Drawing.Point(314, 161);
            this.pppDNS2TB.Name = "pppDNS2TB";
            this.pppDNS2TB.Size = new System.Drawing.Size(100, 21);
            this.pppDNS2TB.TabIndex = 126;
            // 
            // pppDNS1TB
            // 
            this.pppDNS1TB.Enabled = false;
            this.pppDNS1TB.Location = new System.Drawing.Point(314, 134);
            this.pppDNS1TB.Name = "pppDNS1TB";
            this.pppDNS1TB.Size = new System.Drawing.Size(100, 21);
            this.pppDNS1TB.TabIndex = 125;
            // 
            // pppGatewayTB
            // 
            this.pppGatewayTB.Enabled = false;
            this.pppGatewayTB.Location = new System.Drawing.Point(314, 107);
            this.pppGatewayTB.Name = "pppGatewayTB";
            this.pppGatewayTB.Size = new System.Drawing.Size(100, 21);
            this.pppGatewayTB.TabIndex = 124;
            // 
            // pppIPTB
            // 
            this.pppIPTB.Enabled = false;
            this.pppIPTB.Location = new System.Drawing.Point(314, 80);
            this.pppIPTB.Name = "pppIPTB";
            this.pppIPTB.Size = new System.Drawing.Size(100, 21);
            this.pppIPTB.TabIndex = 123;
            // 
            // pppStatusTB
            // 
            this.pppStatusTB.Enabled = false;
            this.pppStatusTB.Location = new System.Drawing.Point(314, 53);
            this.pppStatusTB.Name = "pppStatusTB";
            this.pppStatusTB.Size = new System.Drawing.Size(100, 21);
            this.pppStatusTB.TabIndex = 122;
            // 
            // pppIDLENUD
            // 
            this.pppIDLENUD.Location = new System.Drawing.Point(163, 187);
            this.pppIDLENUD.Maximum = new decimal(new int[] {
            65535,
            0,
            0,
            0});
            this.pppIDLENUD.Name = "pppIDLENUD";
            this.pppIDLENUD.Size = new System.Drawing.Size(60, 21);
            this.pppIDLENUD.TabIndex = 121;
            this.pppIDLENUD.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            // 
            // pppRINUD
            // 
            this.pppRINUD.Location = new System.Drawing.Point(163, 160);
            this.pppRINUD.Maximum = new decimal(new int[] {
            255,
            0,
            0,
            0});
            this.pppRINUD.Name = "pppRINUD";
            this.pppRINUD.Size = new System.Drawing.Size(60, 21);
            this.pppRINUD.TabIndex = 120;
            this.pppRINUD.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            // 
            // pppMaxRTNUD
            // 
            this.pppMaxRTNUD.AccessibleName = "MaxRedial";
            this.pppMaxRTNUD.Location = new System.Drawing.Point(163, 133);
            this.pppMaxRTNUD.Maximum = new decimal(new int[] {
            255,
            0,
            0,
            0});
            this.pppMaxRTNUD.Name = "pppMaxRTNUD";
            this.pppMaxRTNUD.Size = new System.Drawing.Size(60, 21);
            this.pppMaxRTNUD.TabIndex = 119;
            this.pppMaxRTNUD.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            // 
            // pppWorkModeCB
            // 
            this.pppWorkModeCB.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.pppWorkModeCB.FormattingEnabled = true;
            this.pppWorkModeCB.Items.AddRange(new object[] {
            "Disable",
            "Dial_on_Demand",
            "Auto_Dial",
            "Adaptive"});
            this.pppWorkModeCB.Location = new System.Drawing.Point(123, 107);
            this.pppWorkModeCB.Name = "pppWorkModeCB";
            this.pppWorkModeCB.Size = new System.Drawing.Size(100, 20);
            this.pppWorkModeCB.TabIndex = 118;
            // 
            // pppPwdTB
            // 
            this.pppPwdTB.Location = new System.Drawing.Point(123, 80);
            this.pppPwdTB.Name = "pppPwdTB";
            this.pppPwdTB.PasswordChar = '*';
            this.pppPwdTB.Size = new System.Drawing.Size(100, 21);
            this.pppPwdTB.TabIndex = 117;
            // 
            // pppUserNameTB
            // 
            this.pppUserNameTB.Location = new System.Drawing.Point(123, 53);
            this.pppUserNameTB.Name = "pppUserNameTB";
            this.pppUserNameTB.Size = new System.Drawing.Size(100, 21);
            this.pppUserNameTB.TabIndex = 116;
            // 
            // tabPage_PPPoE
            // 
            this.tabPage_PPPoE.Location = new System.Drawing.Point(4, 38);
            this.tabPage_PPPoE.Name = "tabPage_PPPoE";
            this.tabPage_PPPoE.Size = new System.Drawing.Size(466, 291);
            this.tabPage_PPPoE.TabIndex = 2;
            this.tabPage_PPPoE.Text = "PPPoE";
            this.tabPage_PPPoE.UseVisualStyleBackColor = true;
            // 
            // tabPage_Sever
            // 
            this.tabPage_Sever.Controls.Add(this.label13);
            this.tabPage_Sever.Controls.Add(this.label11);
            this.tabPage_Sever.Controls.Add(this.cpuCB);
            this.tabPage_Sever.Controls.Add(this.mtuTB);
            this.tabPage_Sever.Controls.Add(this.httpPortNUD);
            this.tabPage_Sever.Controls.Add(this.arpNUD);
            this.tabPage_Sever.Location = new System.Drawing.Point(4, 38);
            this.tabPage_Sever.Name = "tabPage_Sever";
            this.tabPage_Sever.Size = new System.Drawing.Size(466, 291);
            this.tabPage_Sever.TabIndex = 4;
            this.tabPage_Sever.Text = "Server";
            this.tabPage_Sever.UseVisualStyleBackColor = true;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(78, 107);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(125, 12);
            this.label13.TabIndex = 52;
            this.label13.Text = "CPU Performance Mode";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(78, 70);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(101, 12);
            this.label11.TabIndex = 50;
            this.label11.Text = "ARPcache Timeout";
            // 
            // cpuCB
            // 
            this.cpuCB.AccessibleName = "CPUMode";
            this.cpuCB.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cpuCB.FormattingEnabled = true;
            this.cpuCB.Items.AddRange(new object[] {
            "High",
            "Regular"});
            this.cpuCB.Location = new System.Drawing.Point(214, 101);
            this.cpuCB.Name = "cpuCB";
            this.cpuCB.Size = new System.Drawing.Size(60, 20);
            this.cpuCB.TabIndex = 49;
            // 
            // mtuTB
            // 
            this.mtuTB.AccessibleName = "MTU";
            this.mtuTB.Location = new System.Drawing.Point(214, 173);
            this.mtuTB.Name = "mtuTB";
            this.mtuTB.ReadOnly = true;
            this.mtuTB.Size = new System.Drawing.Size(60, 21);
            this.mtuTB.TabIndex = 48;
            // 
            // httpPortNUD
            // 
            this.httpPortNUD.AccessibleName = "HttpPort";
            this.httpPortNUD.Location = new System.Drawing.Point(214, 136);
            this.httpPortNUD.Maximum = new decimal(new int[] {
            65535,
            0,
            0,
            0});
            this.httpPortNUD.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.httpPortNUD.Name = "httpPortNUD";
            this.httpPortNUD.Size = new System.Drawing.Size(60, 21);
            this.httpPortNUD.TabIndex = 46;
            this.httpPortNUD.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            // 
            // arpNUD
            // 
            this.arpNUD.AccessibleName = "ARPTimeout";
            this.arpNUD.Location = new System.Drawing.Point(214, 65);
            this.arpNUD.Maximum = new decimal(new int[] {
            255,
            0,
            0,
            0});
            this.arpNUD.Minimum = new decimal(new int[] {
            60,
            0,
            0,
            0});
            this.arpNUD.Name = "arpNUD";
            this.arpNUD.Size = new System.Drawing.Size(60, 21);
            this.arpNUD.TabIndex = 45;
            this.arpNUD.Value = new decimal(new int[] {
            60,
            0,
            0,
            0});
            // 
            // tabPage_Serial
            // 
            this.tabPage_Serial.Controls.Add(this.label99);
            this.tabPage_Serial.Controls.Add(this.comboBox_SerialChannel);
            this.tabPage_Serial.Controls.Add(this.panel9);
            this.tabPage_Serial.Controls.Add(this.panel4);
            this.tabPage_Serial.Controls.Add(this.serialOptionCB);
            this.tabPage_Serial.Controls.Add(this.channelNameL1);
            this.tabPage_Serial.Location = new System.Drawing.Point(4, 38);
            this.tabPage_Serial.Name = "tabPage_Serial";
            this.tabPage_Serial.Size = new System.Drawing.Size(466, 291);
            this.tabPage_Serial.TabIndex = 5;
            this.tabPage_Serial.Text = "Serial Settings";
            this.tabPage_Serial.UseVisualStyleBackColor = true;
            // 
            // label99
            // 
            this.label99.AutoSize = true;
            this.label99.Location = new System.Drawing.Point(30, 17);
            this.label99.Name = "label99";
            this.label99.Size = new System.Drawing.Size(89, 12);
            this.label99.TabIndex = 111;
            this.label99.Text = "Channel Number";
            // 
            // comboBox_SerialChannel
            // 
            this.comboBox_SerialChannel.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox_SerialChannel.FormattingEnabled = true;
            this.comboBox_SerialChannel.Location = new System.Drawing.Point(125, 14);
            this.comboBox_SerialChannel.Name = "comboBox_SerialChannel";
            this.comboBox_SerialChannel.Size = new System.Drawing.Size(50, 20);
            this.comboBox_SerialChannel.TabIndex = 110;
            // 
            // panel9
            // 
            this.panel9.Controls.Add(this.label63);
            this.panel9.Controls.Add(this.panel6);
            this.panel9.Controls.Add(this.enablePackCB);
            this.panel9.Location = new System.Drawing.Point(32, 125);
            this.panel9.Name = "panel9";
            this.panel9.Size = new System.Drawing.Size(402, 148);
            this.panel9.TabIndex = 68;
            // 
            // label63
            // 
            this.label63.AutoSize = true;
            this.label63.Location = new System.Drawing.Point(15, 5);
            this.label63.Name = "label63";
            this.label63.Size = new System.Drawing.Size(89, 12);
            this.label63.TabIndex = 116;
            this.label63.Text = "Enable Packing";
            // 
            // panel6
            // 
            this.panel6.Controls.Add(this.label61);
            this.panel6.Controls.Add(this.label60);
            this.panel6.Controls.Add(this.lastTB);
            this.panel6.Controls.Add(this.firstCharTB);
            this.panel6.Controls.Add(this.sendBytesCB);
            this.panel6.Controls.Add(this.match2CB);
            this.panel6.Controls.Add(this.sendFrameCB);
            this.panel6.Controls.Add(this.idleCB);
            this.panel6.Location = new System.Drawing.Point(3, 26);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(396, 117);
            this.panel6.TabIndex = 72;
            // 
            // label61
            // 
            this.label61.AutoSize = true;
            this.label61.Location = new System.Drawing.Point(52, 88);
            this.label61.Name = "label61";
            this.label61.Size = new System.Drawing.Size(119, 12);
            this.label61.TabIndex = 115;
            this.label61.Text = "Send Trailing Bytes";
            // 
            // label60
            // 
            this.label60.AutoSize = true;
            this.label60.Location = new System.Drawing.Point(52, 61);
            this.label60.Name = "label60";
            this.label60.Size = new System.Drawing.Size(83, 12);
            this.label60.TabIndex = 114;
            this.label60.Text = "SendFrameOnly";
            // 
            // lastTB
            // 
            this.lastTB.AccessibleName = "Byte2Packing";
            this.lastTB.Location = new System.Drawing.Point(323, 31);
            this.lastTB.Name = "lastTB";
            this.lastTB.Size = new System.Drawing.Size(32, 21);
            this.lastTB.TabIndex = 76;
            // 
            // firstCharTB
            // 
            this.firstCharTB.AccessibleName = "Byte1Packing";
            this.firstCharTB.Location = new System.Drawing.Point(269, 32);
            this.firstCharTB.Name = "firstCharTB";
            this.firstCharTB.Size = new System.Drawing.Size(32, 21);
            this.firstCharTB.TabIndex = 75;
            // 
            // sendBytesCB
            // 
            this.sendBytesCB.AccessibleName = "TrailingPacking";
            this.sendBytesCB.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.sendBytesCB.FormattingEnabled = true;
            this.sendBytesCB.Items.AddRange(new object[] {
            "None",
            "One",
            "Two"});
            this.sendBytesCB.Location = new System.Drawing.Point(189, 86);
            this.sendBytesCB.Name = "sendBytesCB";
            this.sendBytesCB.Size = new System.Drawing.Size(73, 20);
            this.sendBytesCB.TabIndex = 73;
            // 
            // match2CB
            // 
            this.match2CB.AccessibleName = "2BytesPacking";
            this.match2CB.AutoSize = true;
            this.match2CB.Location = new System.Drawing.Point(189, 35);
            this.match2CB.Name = "match2CB";
            this.match2CB.Size = new System.Drawing.Size(42, 16);
            this.match2CB.TabIndex = 72;
            this.match2CB.Text = "Yes";
            this.match2CB.UseVisualStyleBackColor = true;
            // 
            // sendFrameCB
            // 
            this.sendFrameCB.AccessibleName = "FramePacking";
            this.sendFrameCB.AutoSize = true;
            this.sendFrameCB.Location = new System.Drawing.Point(189, 61);
            this.sendFrameCB.Name = "sendFrameCB";
            this.sendFrameCB.Size = new System.Drawing.Size(42, 16);
            this.sendFrameCB.TabIndex = 71;
            this.sendFrameCB.Text = "Yes";
            this.sendFrameCB.UseVisualStyleBackColor = true;
            // 
            // idleCB
            // 
            this.idleCB.AccessibleName = "IdlePacking";
            this.idleCB.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.idleCB.FormattingEnabled = true;
            this.idleCB.Items.AddRange(new object[] {
            "12msec",
            "11msec",
            "10msec"});
            this.idleCB.Location = new System.Drawing.Point(189, 7);
            this.idleCB.Name = "idleCB";
            this.idleCB.Size = new System.Drawing.Size(62, 20);
            this.idleCB.TabIndex = 70;
            // 
            // enablePackCB
            // 
            this.enablePackCB.AccessibleName = "SerialPacking";
            this.enablePackCB.AutoSize = true;
            this.enablePackCB.Location = new System.Drawing.Point(104, 5);
            this.enablePackCB.Name = "enablePackCB";
            this.enablePackCB.Size = new System.Drawing.Size(60, 16);
            this.enablePackCB.TabIndex = 66;
            this.enablePackCB.Text = "Enable";
            this.enablePackCB.UseVisualStyleBackColor = true;
            // 
            // panel4
            // 
            this.panel4.Controls.Add(this.label62);
            this.panel4.Controls.Add(this.protocolCB);
            this.panel4.Controls.Add(this.stopbitCB);
            this.panel4.Controls.Add(this.parityCB);
            this.panel4.Controls.Add(this.databitCB);
            this.panel4.Controls.Add(this.baudrateCB);
            this.panel4.Controls.Add(this.flowCB);
            this.panel4.Controls.Add(this.fifoCB);
            this.panel4.Location = new System.Drawing.Point(32, 40);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(402, 85);
            this.panel4.TabIndex = 70;
            // 
            // label62
            // 
            this.label62.AutoSize = true;
            this.label62.Location = new System.Drawing.Point(281, 13);
            this.label62.Name = "label62";
            this.label62.Size = new System.Drawing.Size(59, 12);
            this.label62.TabIndex = 112;
            this.label62.Text = "Data Bits";
            // 
            // protocolCB
            // 
            this.protocolCB.AccessibleName = "SerialProtocol";
            this.protocolCB.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.protocolCB.FormattingEnabled = true;
            this.protocolCB.Items.AddRange(new object[] {
            "RS232",
            "RS422",
            "RS485"});
            this.protocolCB.Location = new System.Drawing.Point(104, 10);
            this.protocolCB.Name = "protocolCB";
            this.protocolCB.Size = new System.Drawing.Size(64, 20);
            this.protocolCB.TabIndex = 83;
            // 
            // stopbitCB
            // 
            this.stopbitCB.AccessibleName = "StopBits";
            this.stopbitCB.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.stopbitCB.FormattingEnabled = true;
            this.stopbitCB.Items.AddRange(new object[] {
            "1",
            "1.5",
            "2"});
            this.stopbitCB.Location = new System.Drawing.Point(311, 61);
            this.stopbitCB.Name = "stopbitCB";
            this.stopbitCB.Size = new System.Drawing.Size(45, 20);
            this.stopbitCB.TabIndex = 48;
            // 
            // parityCB
            // 
            this.parityCB.AccessibleName = "SerialParity";
            this.parityCB.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.parityCB.FormattingEnabled = true;
            this.parityCB.Items.AddRange(new object[] {
            "NONE",
            "ODD",
            "EVEN",
            "MARK",
            "SPACE"});
            this.parityCB.Location = new System.Drawing.Point(104, 61);
            this.parityCB.Name = "parityCB";
            this.parityCB.Size = new System.Drawing.Size(88, 20);
            this.parityCB.TabIndex = 47;
            // 
            // databitCB
            // 
            this.databitCB.AccessibleName = "DataBits";
            this.databitCB.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.databitCB.FormattingEnabled = true;
            this.databitCB.Items.AddRange(new object[] {
            "5",
            "6",
            "7",
            "8"});
            this.databitCB.Location = new System.Drawing.Point(354, 10);
            this.databitCB.Name = "databitCB";
            this.databitCB.Size = new System.Drawing.Size(45, 20);
            this.databitCB.TabIndex = 46;
            // 
            // baudrateCB
            // 
            this.baudrateCB.AccessibleName = "BaudRate";
            this.baudrateCB.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.baudrateCB.FormattingEnabled = true;
            this.baudrateCB.Items.AddRange(new object[] {
            "110",
            "134",
            "150",
            "300",
            "600",
            "1200",
            "1800",
            "2400",
            "4800",
            "7200",
            "9600",
            "14400",
            "19200",
            "38400",
            "57600",
            "115200",
            "230400",
            "460800"});
            this.baudrateCB.Location = new System.Drawing.Point(104, 35);
            this.baudrateCB.Name = "baudrateCB";
            this.baudrateCB.Size = new System.Drawing.Size(98, 20);
            this.baudrateCB.TabIndex = 45;
            // 
            // flowCB
            // 
            this.flowCB.AccessibleName = "FlowControl";
            this.flowCB.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.flowCB.FormattingEnabled = true;
            this.flowCB.Items.AddRange(new object[] {
            "None",
            "Software",
            "Hardware"});
            this.flowCB.Location = new System.Drawing.Point(311, 36);
            this.flowCB.Name = "flowCB";
            this.flowCB.Size = new System.Drawing.Size(88, 20);
            this.flowCB.TabIndex = 44;
            // 
            // fifoCB
            // 
            this.fifoCB.AccessibleName = "SerialFIFO";
            this.fifoCB.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.fifoCB.FormattingEnabled = true;
            this.fifoCB.Items.AddRange(new object[] {
            "14",
            "8",
            "4"});
            this.fifoCB.Location = new System.Drawing.Point(221, 10);
            this.fifoCB.Name = "fifoCB";
            this.fifoCB.Size = new System.Drawing.Size(45, 20);
            this.fifoCB.TabIndex = 43;
            // 
            // serialOptionCB
            // 
            this.serialOptionCB.AccessibleName = "SerialEnable";
            this.serialOptionCB.AutoSize = true;
            this.serialOptionCB.Location = new System.Drawing.Point(368, 18);
            this.serialOptionCB.Name = "serialOptionCB";
            this.serialOptionCB.Size = new System.Drawing.Size(60, 16);
            this.serialOptionCB.TabIndex = 69;
            this.serialOptionCB.Text = "Enable";
            this.serialOptionCB.UseVisualStyleBackColor = true;
            // 
            // channelNameL1
            // 
            this.channelNameL1.AutoSize = true;
            this.channelNameL1.Font = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.channelNameL1.Location = new System.Drawing.Point(53, 17);
            this.channelNameL1.Name = "channelNameL1";
            this.channelNameL1.Size = new System.Drawing.Size(0, 12);
            this.channelNameL1.TabIndex = 67;
            // 
            // tabPage_Connection
            // 
            this.tabPage_Connection.Controls.Add(this.label100);
            this.tabPage_Connection.Controls.Add(this.comboBox_ConnChannel);
            this.tabPage_Connection.Controls.Add(this.netProtocolCB);
            this.tabPage_Connection.Controls.Add(this.channelNameL2);
            this.tabPage_Connection.Controls.Add(this.panel_TCP);
            this.tabPage_Connection.Controls.Add(this.panel_UDP);
            this.tabPage_Connection.Location = new System.Drawing.Point(4, 38);
            this.tabPage_Connection.Name = "tabPage_Connection";
            this.tabPage_Connection.Size = new System.Drawing.Size(466, 291);
            this.tabPage_Connection.TabIndex = 6;
            this.tabPage_Connection.Text = "Connection Settings";
            this.tabPage_Connection.UseVisualStyleBackColor = true;
            // 
            // label100
            // 
            this.label100.AutoSize = true;
            this.label100.Location = new System.Drawing.Point(23, 14);
            this.label100.Name = "label100";
            this.label100.Size = new System.Drawing.Size(89, 12);
            this.label100.TabIndex = 111;
            this.label100.Text = "Channel Number";
            // 
            // comboBox_ConnChannel
            // 
            this.comboBox_ConnChannel.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox_ConnChannel.FormattingEnabled = true;
            this.comboBox_ConnChannel.Location = new System.Drawing.Point(118, 11);
            this.comboBox_ConnChannel.Name = "comboBox_ConnChannel";
            this.comboBox_ConnChannel.Size = new System.Drawing.Size(50, 20);
            this.comboBox_ConnChannel.TabIndex = 110;
            // 
            // netProtocolCB
            // 
            this.netProtocolCB.AccessibleName = "ConnProtocol";
            this.netProtocolCB.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.netProtocolCB.FormattingEnabled = true;
            this.netProtocolCB.Items.AddRange(new object[] {
            "UDP",
            "TCP"});
            this.netProtocolCB.Location = new System.Drawing.Point(376, 14);
            this.netProtocolCB.Name = "netProtocolCB";
            this.netProtocolCB.Size = new System.Drawing.Size(50, 20);
            this.netProtocolCB.TabIndex = 85;
            this.netProtocolCB.SelectedIndexChanged += new System.EventHandler(this.netProtocolCB_SelectedIndexChanged);
            // 
            // channelNameL2
            // 
            this.channelNameL2.AutoSize = true;
            this.channelNameL2.Font = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.channelNameL2.Location = new System.Drawing.Point(47, 18);
            this.channelNameL2.Name = "channelNameL2";
            this.channelNameL2.Size = new System.Drawing.Size(0, 12);
            this.channelNameL2.TabIndex = 84;
            // 
            // panel_TCP
            // 
            this.panel_TCP.Controls.Add(this.numericUpDown1);
            this.panel_TCP.Controls.Add(this.label84);
            this.panel_TCP.Controls.Add(this.label83);
            this.panel_TCP.Controls.Add(this.label82);
            this.panel_TCP.Controls.Add(this.label81);
            this.panel_TCP.Controls.Add(this.label80);
            this.panel_TCP.Controls.Add(this.label79);
            this.panel_TCP.Controls.Add(this.label78);
            this.panel_TCP.Controls.Add(this.label77);
            this.panel_TCP.Controls.Add(this.label76);
            this.panel_TCP.Controls.Add(this.label75);
            this.panel_TCP.Controls.Add(this.label68);
            this.panel_TCP.Controls.Add(this.inactivityNUD);
            this.panel_TCP.Controls.Add(this.groupBox5);
            this.panel_TCP.Controls.Add(this.workasCB);
            this.panel_TCP.Controls.Add(this.groupBox4);
            this.panel_TCP.Controls.Add(this.dnsQueryPeriodNUD);
            this.panel_TCP.Controls.Add(this.hardDisconnectCB);
            this.panel_TCP.Controls.Add(this.checkEOTCB);
            this.panel_TCP.Controls.Add(this.onDSRDropCB);
            this.panel_TCP.Controls.Add(this.connectResponseCB);
            this.panel_TCP.Controls.Add(this.tcpRomteHostTB);
            this.panel_TCP.Controls.Add(this.useHostlistCB);
            this.panel_TCP.Controls.Add(this.tcpRemotePortNUD);
            this.panel_TCP.Controls.Add(this.tcpLocalPortNUD);
            this.panel_TCP.Controls.Add(this.startCharTB);
            this.panel_TCP.Controls.Add(this.tcpActiveCB);
            this.panel_TCP.Location = new System.Drawing.Point(25, 39);
            this.panel_TCP.Name = "panel_TCP";
            this.panel_TCP.Size = new System.Drawing.Size(402, 240);
            this.panel_TCP.TabIndex = 89;
            // 
            // numericUpDown1
            // 
            this.numericUpDown1.AccessibleName = "ConnTimeout_S";
            this.numericUpDown1.Location = new System.Drawing.Point(145, 217);
            this.numericUpDown1.Maximum = new decimal(new int[] {
            255,
            0,
            0,
            0});
            this.numericUpDown1.Name = "numericUpDown1";
            this.numericUpDown1.Size = new System.Drawing.Size(37, 21);
            this.numericUpDown1.TabIndex = 126;
            // 
            // label84
            // 
            this.label84.AutoSize = true;
            this.label84.Location = new System.Drawing.Point(3, 221);
            this.label84.Name = "label84";
            this.label84.Size = new System.Drawing.Size(113, 12);
            this.label84.TabIndex = 125;
            this.label84.Text = "Inactivity Timeout";
            // 
            // label83
            // 
            this.label83.AutoSize = true;
            this.label83.Location = new System.Drawing.Point(3, 200);
            this.label83.Name = "label83";
            this.label83.Size = new System.Drawing.Size(95, 12);
            this.label83.TabIndex = 124;
            this.label83.Text = "Hard Disconnect";
            // 
            // label82
            // 
            this.label82.AutoSize = true;
            this.label82.Location = new System.Drawing.Point(3, 180);
            this.label82.Name = "label82";
            this.label82.Size = new System.Drawing.Size(59, 12);
            this.label82.TabIndex = 123;
            this.label82.Text = "Check EOT";
            // 
            // label81
            // 
            this.label81.AutoSize = true;
            this.label81.Location = new System.Drawing.Point(3, 160);
            this.label81.Name = "label81";
            this.label81.Size = new System.Drawing.Size(71, 12);
            this.label81.TabIndex = 122;
            this.label81.Text = "On DSR Drop";
            // 
            // label80
            // 
            this.label80.AutoSize = true;
            this.label80.Location = new System.Drawing.Point(3, 139);
            this.label80.Name = "label80";
            this.label80.Size = new System.Drawing.Size(77, 12);
            this.label80.TabIndex = 121;
            this.label80.Text = "Use Hostlist";
            // 
            // label79
            // 
            this.label79.AutoSize = true;
            this.label79.Location = new System.Drawing.Point(3, 116);
            this.label79.Name = "label79";
            this.label79.Size = new System.Drawing.Size(101, 12);
            this.label79.TabIndex = 120;
            this.label79.Text = "Connect Response";
            // 
            // label78
            // 
            this.label78.AutoSize = true;
            this.label78.Location = new System.Drawing.Point(3, 93);
            this.label78.Name = "label78";
            this.label78.Size = new System.Drawing.Size(65, 12);
            this.label78.TabIndex = 119;
            this.label78.Text = "Local Port";
            // 
            // label77
            // 
            this.label77.AutoSize = true;
            this.label77.Location = new System.Drawing.Point(3, 65);
            this.label77.Name = "label77";
            this.label77.Size = new System.Drawing.Size(71, 12);
            this.label77.TabIndex = 118;
            this.label77.Text = "Remote Port";
            // 
            // label76
            // 
            this.label76.AutoSize = true;
            this.label76.Location = new System.Drawing.Point(3, 36);
            this.label76.Name = "label76";
            this.label76.Size = new System.Drawing.Size(71, 12);
            this.label76.TabIndex = 117;
            this.label76.Text = "Remote Host";
            // 
            // label75
            // 
            this.label75.AutoSize = true;
            this.label75.Location = new System.Drawing.Point(3, 12);
            this.label75.Name = "label75";
            this.label75.Size = new System.Drawing.Size(59, 12);
            this.label75.TabIndex = 116;
            this.label75.Text = "Worked As";
            // 
            // label68
            // 
            this.label68.AutoSize = true;
            this.label68.Location = new System.Drawing.Point(203, 61);
            this.label68.Name = "label68";
            this.label68.Size = new System.Drawing.Size(101, 12);
            this.label68.TabIndex = 109;
            this.label68.Text = "DNS Query Period";
            // 
            // inactivityNUD
            // 
            this.inactivityNUD.AccessibleName = "ConnTimeout_M";
            this.inactivityNUD.Location = new System.Drawing.Point(116, 217);
            this.inactivityNUD.Maximum = new decimal(new int[] {
            255,
            0,
            0,
            0});
            this.inactivityNUD.Name = "inactivityNUD";
            this.inactivityNUD.Size = new System.Drawing.Size(27, 21);
            this.inactivityNUD.TabIndex = 107;
            // 
            // groupBox5
            // 
            this.groupBox5.Controls.Add(this.label74);
            this.groupBox5.Controls.Add(this.label73);
            this.groupBox5.Controls.Add(this.label72);
            this.groupBox5.Controls.Add(this.oatdCB);
            this.groupBox5.Controls.Add(this.owacCB);
            this.groupBox5.Controls.Add(this.owpcCB);
            this.groupBox5.Location = new System.Drawing.Point(183, 165);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Size = new System.Drawing.Size(217, 70);
            this.groupBox5.TabIndex = 85;
            this.groupBox5.TabStop = false;
            this.groupBox5.Text = "Flush Output Buffer";
            // 
            // label74
            // 
            this.label74.AutoSize = true;
            this.label74.Location = new System.Drawing.Point(4, 53);
            this.label74.Name = "label74";
            this.label74.Size = new System.Drawing.Size(167, 12);
            this.label74.TabIndex = 115;
            this.label74.Text = "Output At Timeof Disconnect";
            // 
            // label73
            // 
            this.label73.AutoSize = true;
            this.label73.Location = new System.Drawing.Point(4, 32);
            this.label73.Name = "label73";
            this.label73.Size = new System.Drawing.Size(167, 12);
            this.label73.TabIndex = 114;
            this.label73.Text = "Output With Passive Connect";
            // 
            // label72
            // 
            this.label72.AutoSize = true;
            this.label72.Location = new System.Drawing.Point(4, 14);
            this.label72.Name = "label72";
            this.label72.Size = new System.Drawing.Size(161, 12);
            this.label72.TabIndex = 113;
            this.label72.Text = "Output With Active Connect";
            // 
            // oatdCB
            // 
            this.oatdCB.AccessibleName = "ConnFlushOutDis";
            this.oatdCB.AutoSize = true;
            this.oatdCB.Location = new System.Drawing.Point(174, 52);
            this.oatdCB.Name = "oatdCB";
            this.oatdCB.Size = new System.Drawing.Size(42, 16);
            this.oatdCB.TabIndex = 82;
            this.oatdCB.Text = "Yes";
            this.oatdCB.UseVisualStyleBackColor = true;
            // 
            // owacCB
            // 
            this.owacCB.AccessibleName = "ConnFlushOutActive";
            this.owacCB.AutoSize = true;
            this.owacCB.Location = new System.Drawing.Point(174, 10);
            this.owacCB.Name = "owacCB";
            this.owacCB.Size = new System.Drawing.Size(42, 16);
            this.owacCB.TabIndex = 80;
            this.owacCB.Text = "Yes";
            this.owacCB.UseVisualStyleBackColor = true;
            // 
            // owpcCB
            // 
            this.owpcCB.AccessibleName = "ConnFlushOutPassive";
            this.owpcCB.AutoSize = true;
            this.owpcCB.Location = new System.Drawing.Point(174, 31);
            this.owpcCB.Name = "owpcCB";
            this.owpcCB.Size = new System.Drawing.Size(42, 16);
            this.owpcCB.TabIndex = 81;
            this.owpcCB.Text = "Yes";
            this.owpcCB.UseVisualStyleBackColor = true;
            // 
            // workasCB
            // 
            this.workasCB.AccessibleName = "ConnWorkMode";
            this.workasCB.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.workasCB.FormattingEnabled = true;
            this.workasCB.Items.AddRange(new object[] {
            "Server",
            "Client",
            "Both"});
            this.workasCB.Location = new System.Drawing.Point(79, 9);
            this.workasCB.Name = "workasCB";
            this.workasCB.Size = new System.Drawing.Size(92, 20);
            this.workasCB.TabIndex = 106;
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.label71);
            this.groupBox4.Controls.Add(this.label70);
            this.groupBox4.Controls.Add(this.label69);
            this.groupBox4.Controls.Add(this.iwacCB);
            this.groupBox4.Controls.Add(this.iwpcCB);
            this.groupBox4.Controls.Add(this.iatdCB);
            this.groupBox4.Location = new System.Drawing.Point(181, 88);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(217, 70);
            this.groupBox4.TabIndex = 84;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "Flush Input Buffer";
            // 
            // label71
            // 
            this.label71.AutoSize = true;
            this.label71.Location = new System.Drawing.Point(6, 53);
            this.label71.Name = "label71";
            this.label71.Size = new System.Drawing.Size(161, 12);
            this.label71.TabIndex = 112;
            this.label71.Text = "Input At Timeof Disconnect";
            // 
            // label70
            // 
            this.label70.AutoSize = true;
            this.label70.Location = new System.Drawing.Point(6, 33);
            this.label70.Name = "label70";
            this.label70.Size = new System.Drawing.Size(161, 12);
            this.label70.TabIndex = 111;
            this.label70.Text = "Input With Passive Connect";
            // 
            // label69
            // 
            this.label69.AutoSize = true;
            this.label69.Location = new System.Drawing.Point(6, 14);
            this.label69.Name = "label69";
            this.label69.Size = new System.Drawing.Size(155, 12);
            this.label69.TabIndex = 110;
            this.label69.Text = "Input With Active Connect";
            // 
            // iwacCB
            // 
            this.iwacCB.AccessibleName = "ConnFlushInActive";
            this.iwacCB.AutoSize = true;
            this.iwacCB.Location = new System.Drawing.Point(174, 13);
            this.iwacCB.Name = "iwacCB";
            this.iwacCB.Size = new System.Drawing.Size(42, 16);
            this.iwacCB.TabIndex = 77;
            this.iwacCB.Text = "Yes";
            this.iwacCB.UseVisualStyleBackColor = true;
            // 
            // iwpcCB
            // 
            this.iwpcCB.AccessibleName = "ConnFlushInPassive";
            this.iwpcCB.AutoSize = true;
            this.iwpcCB.Location = new System.Drawing.Point(174, 32);
            this.iwpcCB.Name = "iwpcCB";
            this.iwpcCB.Size = new System.Drawing.Size(42, 16);
            this.iwpcCB.TabIndex = 78;
            this.iwpcCB.Text = "Yes";
            this.iwpcCB.UseVisualStyleBackColor = true;
            // 
            // iatdCB
            // 
            this.iatdCB.AccessibleName = "ConnFlushInDis";
            this.iatdCB.AutoSize = true;
            this.iatdCB.Location = new System.Drawing.Point(174, 52);
            this.iatdCB.Name = "iatdCB";
            this.iatdCB.Size = new System.Drawing.Size(42, 16);
            this.iatdCB.TabIndex = 79;
            this.iatdCB.Text = "Yes";
            this.iatdCB.UseVisualStyleBackColor = true;
            // 
            // dnsQueryPeriodNUD
            // 
            this.dnsQueryPeriodNUD.AccessibleName = "ConnDNS";
            this.dnsQueryPeriodNUD.Location = new System.Drawing.Point(319, 56);
            this.dnsQueryPeriodNUD.Maximum = new decimal(new int[] {
            65535,
            0,
            0,
            0});
            this.dnsQueryPeriodNUD.Name = "dnsQueryPeriodNUD";
            this.dnsQueryPeriodNUD.Size = new System.Drawing.Size(60, 21);
            this.dnsQueryPeriodNUD.TabIndex = 105;
            this.dnsQueryPeriodNUD.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            // 
            // hardDisconnectCB
            // 
            this.hardDisconnectCB.AccessibleName = "ConnHard";
            this.hardDisconnectCB.AutoSize = true;
            this.hardDisconnectCB.Location = new System.Drawing.Point(129, 199);
            this.hardDisconnectCB.Name = "hardDisconnectCB";
            this.hardDisconnectCB.Size = new System.Drawing.Size(42, 16);
            this.hardDisconnectCB.TabIndex = 102;
            this.hardDisconnectCB.Text = "Yes";
            this.hardDisconnectCB.UseVisualStyleBackColor = true;
            // 
            // checkEOTCB
            // 
            this.checkEOTCB.AccessibleName = "ConnEOT";
            this.checkEOTCB.AutoSize = true;
            this.checkEOTCB.Location = new System.Drawing.Point(129, 179);
            this.checkEOTCB.Name = "checkEOTCB";
            this.checkEOTCB.Size = new System.Drawing.Size(42, 16);
            this.checkEOTCB.TabIndex = 101;
            this.checkEOTCB.Text = "Yes";
            this.checkEOTCB.UseVisualStyleBackColor = true;
            // 
            // onDSRDropCB
            // 
            this.onDSRDropCB.AccessibleName = "ConnDSR";
            this.onDSRDropCB.AutoSize = true;
            this.onDSRDropCB.Location = new System.Drawing.Point(129, 159);
            this.onDSRDropCB.Name = "onDSRDropCB";
            this.onDSRDropCB.Size = new System.Drawing.Size(42, 16);
            this.onDSRDropCB.TabIndex = 100;
            this.onDSRDropCB.Text = "Yes";
            this.onDSRDropCB.UseVisualStyleBackColor = true;
            // 
            // connectResponseCB
            // 
            this.connectResponseCB.AccessibleName = "ConnResponse";
            this.connectResponseCB.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.connectResponseCB.FormattingEnabled = true;
            this.connectResponseCB.Items.AddRange(new object[] {
            "None",
            "ACT"});
            this.connectResponseCB.Location = new System.Drawing.Point(104, 113);
            this.connectResponseCB.Name = "connectResponseCB";
            this.connectResponseCB.Size = new System.Drawing.Size(67, 20);
            this.connectResponseCB.TabIndex = 99;
            // 
            // tcpRomteHostTB
            // 
            this.tcpRomteHostTB.AccessibleName = "ConnRemoteHost";
            this.tcpRomteHostTB.Location = new System.Drawing.Point(79, 32);
            this.tcpRomteHostTB.Name = "tcpRomteHostTB";
            this.tcpRomteHostTB.Size = new System.Drawing.Size(92, 21);
            this.tcpRomteHostTB.TabIndex = 98;
            // 
            // useHostlistCB
            // 
            this.useHostlistCB.AccessibleName = "ConnHostList";
            this.useHostlistCB.AutoSize = true;
            this.useHostlistCB.Location = new System.Drawing.Point(129, 139);
            this.useHostlistCB.Name = "useHostlistCB";
            this.useHostlistCB.Size = new System.Drawing.Size(42, 16);
            this.useHostlistCB.TabIndex = 97;
            this.useHostlistCB.Text = "Yes";
            this.useHostlistCB.UseVisualStyleBackColor = true;
            // 
            // tcpRemotePortNUD
            // 
            this.tcpRemotePortNUD.AccessibleName = "ConnRemotePort";
            this.tcpRemotePortNUD.Location = new System.Drawing.Point(111, 59);
            this.tcpRemotePortNUD.Maximum = new decimal(new int[] {
            65535,
            0,
            0,
            0});
            this.tcpRemotePortNUD.Name = "tcpRemotePortNUD";
            this.tcpRemotePortNUD.Size = new System.Drawing.Size(60, 21);
            this.tcpRemotePortNUD.TabIndex = 96;
            this.tcpRemotePortNUD.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            // 
            // tcpLocalPortNUD
            // 
            this.tcpLocalPortNUD.AccessibleName = "ConnLocalPort";
            this.tcpLocalPortNUD.Location = new System.Drawing.Point(111, 86);
            this.tcpLocalPortNUD.Maximum = new decimal(new int[] {
            65535,
            0,
            0,
            0});
            this.tcpLocalPortNUD.Name = "tcpLocalPortNUD";
            this.tcpLocalPortNUD.Size = new System.Drawing.Size(60, 21);
            this.tcpLocalPortNUD.TabIndex = 95;
            this.tcpLocalPortNUD.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            // 
            // startCharTB
            // 
            this.startCharTB.AccessibleName = "ConnStartChar";
            this.startCharTB.Location = new System.Drawing.Point(320, 29);
            this.startCharTB.Name = "startCharTB";
            this.startCharTB.Size = new System.Drawing.Size(37, 21);
            this.startCharTB.TabIndex = 79;
            // 
            // tcpActiveCB
            // 
            this.tcpActiveCB.AccessibleName = "ConnActive";
            this.tcpActiveCB.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.tcpActiveCB.FormattingEnabled = true;
            this.tcpActiveCB.Items.AddRange(new object[] {
            "None",
            "WithAnyCharacter",
            "WithStartCharacter",
            "AutoStart"});
            this.tcpActiveCB.Location = new System.Drawing.Point(292, 7);
            this.tcpActiveCB.Name = "tcpActiveCB";
            this.tcpActiveCB.Size = new System.Drawing.Size(107, 20);
            this.tcpActiveCB.TabIndex = 93;
            // 
            // panel_UDP
            // 
            this.panel_UDP.Controls.Add(this.label98);
            this.panel_UDP.Controls.Add(this.label94);
            this.panel_UDP.Controls.Add(this.label93);
            this.panel_UDP.Controls.Add(this.udpUCLPNUD);
            this.panel_UDP.Controls.Add(this.tableLayoutPanel2);
            this.panel_UDP.Controls.Add(this.panel7);
            this.panel_UDP.Controls.Add(this.datagramCB);
            this.panel_UDP.Location = new System.Drawing.Point(16, 40);
            this.panel_UDP.Name = "panel_UDP";
            this.panel_UDP.Size = new System.Drawing.Size(421, 241);
            this.panel_UDP.TabIndex = 107;
            // 
            // label98
            // 
            this.label98.AutoSize = true;
            this.label98.Location = new System.Drawing.Point(198, 98);
            this.label98.Name = "label98";
            this.label98.Size = new System.Drawing.Size(137, 12);
            this.label98.TabIndex = 139;
            this.label98.Text = "UDP UniCast Local Port";
            // 
            // label94
            // 
            this.label94.AutoSize = true;
            this.label94.Location = new System.Drawing.Point(19, 7);
            this.label94.Name = "label94";
            this.label94.Size = new System.Drawing.Size(83, 12);
            this.label94.TabIndex = 138;
            this.label94.Text = "Datagram Type";
            // 
            // label93
            // 
            this.label93.AutoSize = true;
            this.label93.Location = new System.Drawing.Point(241, 7);
            this.label93.Name = "label93";
            this.label93.Size = new System.Drawing.Size(95, 12);
            this.label93.TabIndex = 137;
            this.label93.Text = "Accept Incoming";
            // 
            // udpUCLPNUD
            // 
            this.udpUCLPNUD.AccessibleName = "UdpUniLocalPort";
            this.udpUCLPNUD.Location = new System.Drawing.Point(343, 96);
            this.udpUCLPNUD.Maximum = new decimal(new int[] {
            65535,
            0,
            0,
            0});
            this.udpUCLPNUD.Name = "udpUCLPNUD";
            this.udpUCLPNUD.Size = new System.Drawing.Size(60, 21);
            this.udpUCLPNUD.TabIndex = 136;
            this.udpUCLPNUD.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            // 
            // tableLayoutPanel2
            // 
            this.tableLayoutPanel2.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Single;
            this.tableLayoutPanel2.ColumnCount = 4;
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 8.02005F));
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 38.34586F));
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 36.34085F));
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 17.29323F));
            this.tableLayoutPanel2.Controls.Add(this.eAddr3TB, 2, 4);
            this.tableLayoutPanel2.Controls.Add(this.bAddr3TB, 1, 4);
            this.tableLayoutPanel2.Controls.Add(this.eAddr2TB, 2, 3);
            this.tableLayoutPanel2.Controls.Add(this.bAddr2TB, 1, 3);
            this.tableLayoutPanel2.Controls.Add(this.eAddr1TB, 2, 2);
            this.tableLayoutPanel2.Controls.Add(this.bAddr1TB, 1, 2);
            this.tableLayoutPanel2.Controls.Add(this.eAddr0TB, 2, 1);
            this.tableLayoutPanel2.Controls.Add(this.bAddr0TB, 1, 1);
            this.tableLayoutPanel2.Controls.Add(this.label85, 0, 1);
            this.tableLayoutPanel2.Controls.Add(this.label86, 3, 0);
            this.tableLayoutPanel2.Controls.Add(this.label87, 2, 0);
            this.tableLayoutPanel2.Controls.Add(this.label88, 1, 0);
            this.tableLayoutPanel2.Controls.Add(this.label89, 0, 0);
            this.tableLayoutPanel2.Controls.Add(this.label90, 0, 2);
            this.tableLayoutPanel2.Controls.Add(this.label91, 0, 3);
            this.tableLayoutPanel2.Controls.Add(this.label92, 0, 4);
            this.tableLayoutPanel2.Controls.Add(this.udpPort0TB, 3, 1);
            this.tableLayoutPanel2.Controls.Add(this.udpPort1TB, 3, 2);
            this.tableLayoutPanel2.Controls.Add(this.udpPort2TB, 3, 3);
            this.tableLayoutPanel2.Controls.Add(this.udpPort3TB, 3, 4);
            this.tableLayoutPanel2.Location = new System.Drawing.Point(9, 118);
            this.tableLayoutPanel2.Name = "tableLayoutPanel2";
            this.tableLayoutPanel2.RowCount = 5;
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 13.97849F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 21.50538F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 21.50538F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 21.50538F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 21.50538F));
            this.tableLayoutPanel2.Size = new System.Drawing.Size(402, 121);
            this.tableLayoutPanel2.TabIndex = 135;
            // 
            // eAddr3TB
            // 
            this.eAddr3TB.AccessibleName = "UdpRemoteIP8";
            this.eAddr3TB.Dock = System.Windows.Forms.DockStyle.Fill;
            this.eAddr3TB.Location = new System.Drawing.Point(189, 96);
            this.eAddr3TB.Name = "eAddr3TB";
            this.eAddr3TB.Size = new System.Drawing.Size(138, 21);
            this.eAddr3TB.TabIndex = 87;
            // 
            // bAddr3TB
            // 
            this.bAddr3TB.AccessibleName = "UdpRemoteIP7";
            this.bAddr3TB.Dock = System.Windows.Forms.DockStyle.Fill;
            this.bAddr3TB.Location = new System.Drawing.Point(36, 96);
            this.bAddr3TB.Name = "bAddr3TB";
            this.bAddr3TB.Size = new System.Drawing.Size(146, 21);
            this.bAddr3TB.TabIndex = 86;
            // 
            // eAddr2TB
            // 
            this.eAddr2TB.AccessibleName = "UdpRemoteIP6";
            this.eAddr2TB.Dock = System.Windows.Forms.DockStyle.Fill;
            this.eAddr2TB.Location = new System.Drawing.Point(189, 71);
            this.eAddr2TB.Name = "eAddr2TB";
            this.eAddr2TB.Size = new System.Drawing.Size(138, 21);
            this.eAddr2TB.TabIndex = 85;
            // 
            // bAddr2TB
            // 
            this.bAddr2TB.AccessibleName = "UdpRemoteIP5";
            this.bAddr2TB.Dock = System.Windows.Forms.DockStyle.Fill;
            this.bAddr2TB.Location = new System.Drawing.Point(36, 71);
            this.bAddr2TB.Name = "bAddr2TB";
            this.bAddr2TB.Size = new System.Drawing.Size(146, 21);
            this.bAddr2TB.TabIndex = 84;
            // 
            // eAddr1TB
            // 
            this.eAddr1TB.AccessibleName = "UdpRemoteIP4";
            this.eAddr1TB.Dock = System.Windows.Forms.DockStyle.Fill;
            this.eAddr1TB.Location = new System.Drawing.Point(189, 46);
            this.eAddr1TB.Name = "eAddr1TB";
            this.eAddr1TB.Size = new System.Drawing.Size(138, 21);
            this.eAddr1TB.TabIndex = 83;
            // 
            // bAddr1TB
            // 
            this.bAddr1TB.AccessibleName = "UdpRemoteIP3";
            this.bAddr1TB.Dock = System.Windows.Forms.DockStyle.Fill;
            this.bAddr1TB.Location = new System.Drawing.Point(36, 46);
            this.bAddr1TB.Name = "bAddr1TB";
            this.bAddr1TB.Size = new System.Drawing.Size(146, 21);
            this.bAddr1TB.TabIndex = 82;
            // 
            // eAddr0TB
            // 
            this.eAddr0TB.AccessibleName = "UdpRemoteIP2";
            this.eAddr0TB.Dock = System.Windows.Forms.DockStyle.Fill;
            this.eAddr0TB.Location = new System.Drawing.Point(189, 21);
            this.eAddr0TB.Name = "eAddr0TB";
            this.eAddr0TB.Size = new System.Drawing.Size(138, 21);
            this.eAddr0TB.TabIndex = 81;
            // 
            // bAddr0TB
            // 
            this.bAddr0TB.AccessibleName = "UdpRemoteIP1";
            this.bAddr0TB.Dock = System.Windows.Forms.DockStyle.Fill;
            this.bAddr0TB.Location = new System.Drawing.Point(36, 21);
            this.bAddr0TB.Name = "bAddr0TB";
            this.bAddr0TB.Size = new System.Drawing.Size(146, 21);
            this.bAddr0TB.TabIndex = 79;
            // 
            // label85
            // 
            this.label85.AutoSize = true;
            this.label85.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label85.Location = new System.Drawing.Point(4, 18);
            this.label85.Name = "label85";
            this.label85.Size = new System.Drawing.Size(25, 24);
            this.label85.TabIndex = 4;
            this.label85.Text = "0";
            this.label85.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label86
            // 
            this.label86.AutoSize = true;
            this.label86.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label86.Location = new System.Drawing.Point(334, 1);
            this.label86.Name = "label86";
            this.label86.Size = new System.Drawing.Size(64, 16);
            this.label86.TabIndex = 3;
            this.label86.Text = "Port";
            this.label86.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label87
            // 
            this.label87.AutoSize = true;
            this.label87.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label87.Location = new System.Drawing.Point(189, 1);
            this.label87.Name = "label87";
            this.label87.Size = new System.Drawing.Size(138, 16);
            this.label87.TabIndex = 2;
            this.label87.Text = "Host Address";
            this.label87.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label88
            // 
            this.label88.AutoSize = true;
            this.label88.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label88.Location = new System.Drawing.Point(36, 1);
            this.label88.Name = "label88";
            this.label88.Size = new System.Drawing.Size(146, 16);
            this.label88.TabIndex = 1;
            this.label88.Text = "Host Address";
            this.label88.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label89
            // 
            this.label89.AutoSize = true;
            this.label89.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label89.Location = new System.Drawing.Point(4, 1);
            this.label89.Name = "label89";
            this.label89.Size = new System.Drawing.Size(25, 16);
            this.label89.TabIndex = 0;
            this.label89.Text = "No.";
            this.label89.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label90
            // 
            this.label90.AutoSize = true;
            this.label90.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label90.Location = new System.Drawing.Point(4, 43);
            this.label90.Name = "label90";
            this.label90.Size = new System.Drawing.Size(25, 24);
            this.label90.TabIndex = 5;
            this.label90.Text = "1";
            this.label90.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label91
            // 
            this.label91.AutoSize = true;
            this.label91.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label91.Location = new System.Drawing.Point(4, 68);
            this.label91.Name = "label91";
            this.label91.Size = new System.Drawing.Size(25, 24);
            this.label91.TabIndex = 6;
            this.label91.Text = "2";
            this.label91.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label92
            // 
            this.label92.AutoSize = true;
            this.label92.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label92.Location = new System.Drawing.Point(4, 93);
            this.label92.Name = "label92";
            this.label92.Size = new System.Drawing.Size(25, 27);
            this.label92.TabIndex = 7;
            this.label92.Text = "3";
            this.label92.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // udpPort0TB
            // 
            this.udpPort0TB.AccessibleName = "UdpRemotePort1";
            this.udpPort0TB.Dock = System.Windows.Forms.DockStyle.Fill;
            this.udpPort0TB.Location = new System.Drawing.Point(334, 21);
            this.udpPort0TB.Maximum = new decimal(new int[] {
            65535,
            0,
            0,
            0});
            this.udpPort0TB.Name = "udpPort0TB";
            this.udpPort0TB.Size = new System.Drawing.Size(64, 21);
            this.udpPort0TB.TabIndex = 77;
            this.udpPort0TB.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            // 
            // udpPort1TB
            // 
            this.udpPort1TB.AccessibleName = "UdpRemotePort2";
            this.udpPort1TB.Dock = System.Windows.Forms.DockStyle.Fill;
            this.udpPort1TB.Location = new System.Drawing.Point(334, 46);
            this.udpPort1TB.Maximum = new decimal(new int[] {
            65535,
            0,
            0,
            0});
            this.udpPort1TB.Name = "udpPort1TB";
            this.udpPort1TB.Size = new System.Drawing.Size(64, 21);
            this.udpPort1TB.TabIndex = 78;
            this.udpPort1TB.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            // 
            // udpPort2TB
            // 
            this.udpPort2TB.AccessibleName = "UdpRemotePort3";
            this.udpPort2TB.Dock = System.Windows.Forms.DockStyle.Fill;
            this.udpPort2TB.Location = new System.Drawing.Point(334, 71);
            this.udpPort2TB.Maximum = new decimal(new int[] {
            65535,
            0,
            0,
            0});
            this.udpPort2TB.Name = "udpPort2TB";
            this.udpPort2TB.Size = new System.Drawing.Size(64, 21);
            this.udpPort2TB.TabIndex = 79;
            this.udpPort2TB.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            // 
            // udpPort3TB
            // 
            this.udpPort3TB.AccessibleName = "UdpRemotePort4";
            this.udpPort3TB.Dock = System.Windows.Forms.DockStyle.Fill;
            this.udpPort3TB.Location = new System.Drawing.Point(334, 96);
            this.udpPort3TB.Maximum = new decimal(new int[] {
            65535,
            0,
            0,
            0});
            this.udpPort3TB.Name = "udpPort3TB";
            this.udpPort3TB.Size = new System.Drawing.Size(64, 21);
            this.udpPort3TB.TabIndex = 80;
            this.udpPort3TB.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            // 
            // panel7
            // 
            this.panel7.Controls.Add(this.label97);
            this.panel7.Controls.Add(this.label96);
            this.panel7.Controls.Add(this.label95);
            this.panel7.Controls.Add(this.udpRemoteIpTB);
            this.panel7.Controls.Add(this.udpRemotePortNUD);
            this.panel7.Controls.Add(this.udpLocalPortNUD);
            this.panel7.Location = new System.Drawing.Point(9, 28);
            this.panel7.Name = "panel7";
            this.panel7.Size = new System.Drawing.Size(402, 62);
            this.panel7.TabIndex = 134;
            // 
            // label97
            // 
            this.label97.AutoSize = true;
            this.label97.Location = new System.Drawing.Point(10, 35);
            this.label97.Name = "label97";
            this.label97.Size = new System.Drawing.Size(95, 12);
            this.label97.TabIndex = 130;
            this.label97.Text = "UDP Net Segment";
            // 
            // label96
            // 
            this.label96.AutoSize = true;
            this.label96.Location = new System.Drawing.Point(238, 8);
            this.label96.Name = "label96";
            this.label96.Size = new System.Drawing.Size(95, 12);
            this.label96.TabIndex = 129;
            this.label96.Text = "UDP Remote Port";
            // 
            // label95
            // 
            this.label95.AutoSize = true;
            this.label95.Location = new System.Drawing.Point(10, 8);
            this.label95.Name = "label95";
            this.label95.Size = new System.Drawing.Size(89, 12);
            this.label95.TabIndex = 128;
            this.label95.Text = "UDP Local Port";
            // 
            // udpRemoteIpTB
            // 
            this.udpRemoteIpTB.AccessibleName = "UdpMulRemoteIP";
            this.udpRemoteIpTB.Location = new System.Drawing.Point(114, 32);
            this.udpRemoteIpTB.Name = "udpRemoteIpTB";
            this.udpRemoteIpTB.Size = new System.Drawing.Size(120, 21);
            this.udpRemoteIpTB.TabIndex = 78;
            // 
            // udpRemotePortNUD
            // 
            this.udpRemotePortNUD.AccessibleName = "UdpMulRemotePort";
            this.udpRemotePortNUD.Location = new System.Drawing.Point(339, 5);
            this.udpRemotePortNUD.Maximum = new decimal(new int[] {
            65535,
            0,
            0,
            0});
            this.udpRemotePortNUD.Name = "udpRemotePortNUD";
            this.udpRemotePortNUD.Size = new System.Drawing.Size(60, 21);
            this.udpRemotePortNUD.TabIndex = 77;
            this.udpRemotePortNUD.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            // 
            // udpLocalPortNUD
            // 
            this.udpLocalPortNUD.AccessibleName = "UdpMulLocalPort";
            this.udpLocalPortNUD.Location = new System.Drawing.Point(114, 6);
            this.udpLocalPortNUD.Maximum = new decimal(new int[] {
            65535,
            0,
            0,
            0});
            this.udpLocalPortNUD.Name = "udpLocalPortNUD";
            this.udpLocalPortNUD.Size = new System.Drawing.Size(60, 21);
            this.udpLocalPortNUD.TabIndex = 76;
            this.udpLocalPortNUD.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            // 
            // datagramCB
            // 
            this.datagramCB.AccessibleName = "UdpDataGram";
            this.datagramCB.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.datagramCB.FormattingEnabled = true;
            this.datagramCB.Items.AddRange(new object[] {
            "Uni_Cast",
            "Multi_Cast"});
            this.datagramCB.Location = new System.Drawing.Point(123, 2);
            this.datagramCB.Name = "datagramCB";
            this.datagramCB.Size = new System.Drawing.Size(88, 20);
            this.datagramCB.TabIndex = 132;
            // 
            // tabPage_Hostlist
            // 
            this.tabPage_Hostlist.Controls.Add(this.label43);
            this.tabPage_Hostlist.Controls.Add(this.comboBox_HostChannel);
            this.tabPage_Hostlist.Controls.Add(this.groupBox6);
            this.tabPage_Hostlist.Controls.Add(this.tableLayoutPanel1);
            this.tabPage_Hostlist.Controls.Add(this.channelNameL);
            this.tabPage_Hostlist.Location = new System.Drawing.Point(4, 38);
            this.tabPage_Hostlist.Name = "tabPage_Hostlist";
            this.tabPage_Hostlist.Size = new System.Drawing.Size(466, 291);
            this.tabPage_Hostlist.TabIndex = 7;
            this.tabPage_Hostlist.Text = "HostList Settings";
            this.tabPage_Hostlist.UseVisualStyleBackColor = true;
            // 
            // label43
            // 
            this.label43.AutoSize = true;
            this.label43.Location = new System.Drawing.Point(28, 12);
            this.label43.Name = "label43";
            this.label43.Size = new System.Drawing.Size(89, 12);
            this.label43.TabIndex = 109;
            this.label43.Text = "Channel Number";
            // 
            // comboBox_HostChannel
            // 
            this.comboBox_HostChannel.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox_HostChannel.FormattingEnabled = true;
            this.comboBox_HostChannel.Location = new System.Drawing.Point(123, 9);
            this.comboBox_HostChannel.Name = "comboBox_HostChannel";
            this.comboBox_HostChannel.Size = new System.Drawing.Size(50, 20);
            this.comboBox_HostChannel.TabIndex = 108;
            // 
            // groupBox6
            // 
            this.groupBox6.Controls.Add(this.label10);
            this.groupBox6.Controls.Add(this.checkBox1);
            this.groupBox6.Controls.Add(this.label9);
            this.groupBox6.Controls.Add(this.label8);
            this.groupBox6.Controls.Add(this.retryCNUD);
            this.groupBox6.Controls.Add(this.retryTNUD);
            this.groupBox6.Location = new System.Drawing.Point(30, 41);
            this.groupBox6.Name = "groupBox6";
            this.groupBox6.Size = new System.Drawing.Size(402, 60);
            this.groupBox6.TabIndex = 107;
            this.groupBox6.TabStop = false;
            this.groupBox6.Text = "TCP Hostlist Settings";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(20, 40);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(71, 12);
            this.label10.TabIndex = 107;
            this.label10.Text = "Backup Link";
            // 
            // checkBox1
            // 
            this.checkBox1.AccessibleName = "MaxTcp";
            this.checkBox1.AutoSize = true;
            this.checkBox1.Enabled = false;
            this.checkBox1.Location = new System.Drawing.Point(109, 39);
            this.checkBox1.Name = "checkBox1";
            this.checkBox1.Size = new System.Drawing.Size(60, 16);
            this.checkBox1.TabIndex = 106;
            this.checkBox1.Text = "Enable";
            this.checkBox1.UseVisualStyleBackColor = true;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(20, 17);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(83, 12);
            this.label9.TabIndex = 105;
            this.label9.Text = "Retry Counter";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(197, 17);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(83, 12);
            this.label8.TabIndex = 104;
            this.label8.Text = "Retry Timeout";
            // 
            // retryCNUD
            // 
            this.retryCNUD.AccessibleName = "RetryCounter";
            this.retryCNUD.Location = new System.Drawing.Point(109, 12);
            this.retryCNUD.Maximum = new decimal(new int[] {
            255,
            0,
            0,
            0});
            this.retryCNUD.Name = "retryCNUD";
            this.retryCNUD.Size = new System.Drawing.Size(60, 21);
            this.retryCNUD.TabIndex = 61;
            // 
            // retryTNUD
            // 
            this.retryTNUD.AccessibleName = "RetryTimeout";
            this.retryTNUD.Location = new System.Drawing.Point(286, 13);
            this.retryTNUD.Maximum = new decimal(new int[] {
            255,
            0,
            0,
            0});
            this.retryTNUD.Name = "retryTNUD";
            this.retryTNUD.Size = new System.Drawing.Size(60, 21);
            this.retryTNUD.TabIndex = 62;
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Single;
            this.tableLayoutPanel1.ColumnCount = 6;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 7.461742F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 30.34575F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 12.18962F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 7.463036F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 30.34968F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 12.19017F));
            this.tableLayoutPanel1.Controls.Add(this.hostPort12TB, 5, 6);
            this.tableLayoutPanel1.Controls.Add(this.hostIP12TB, 4, 6);
            this.tableLayoutPanel1.Controls.Add(this.hostPort11TB, 2, 6);
            this.tableLayoutPanel1.Controls.Add(this.hostIP11TB, 1, 6);
            this.tableLayoutPanel1.Controls.Add(this.hostPort10TB, 5, 5);
            this.tableLayoutPanel1.Controls.Add(this.hostIP10TB, 4, 5);
            this.tableLayoutPanel1.Controls.Add(this.hostPort9TB, 2, 5);
            this.tableLayoutPanel1.Controls.Add(this.hostIP9TB, 1, 5);
            this.tableLayoutPanel1.Controls.Add(this.hostPort8TB, 5, 4);
            this.tableLayoutPanel1.Controls.Add(this.hostIP8TB, 4, 4);
            this.tableLayoutPanel1.Controls.Add(this.hostPort7TB, 2, 4);
            this.tableLayoutPanel1.Controls.Add(this.hostIP7TB, 1, 4);
            this.tableLayoutPanel1.Controls.Add(this.hostPort6TB, 5, 3);
            this.tableLayoutPanel1.Controls.Add(this.hostIP6TB, 4, 3);
            this.tableLayoutPanel1.Controls.Add(this.hostPort5TB, 2, 3);
            this.tableLayoutPanel1.Controls.Add(this.hostIP5TB, 1, 3);
            this.tableLayoutPanel1.Controls.Add(this.hostPort4TB, 5, 2);
            this.tableLayoutPanel1.Controls.Add(this.hostIP4TB, 4, 2);
            this.tableLayoutPanel1.Controls.Add(this.hostPort3TB, 2, 2);
            this.tableLayoutPanel1.Controls.Add(this.hostIP3TB, 1, 2);
            this.tableLayoutPanel1.Controls.Add(this.hostPort2TB, 5, 1);
            this.tableLayoutPanel1.Controls.Add(this.hostIP2TB, 4, 1);
            this.tableLayoutPanel1.Controls.Add(this.hostPort1TB, 2, 1);
            this.tableLayoutPanel1.Controls.Add(this.label20, 0, 1);
            this.tableLayoutPanel1.Controls.Add(this.label19, 5, 0);
            this.tableLayoutPanel1.Controls.Add(this.label18, 4, 0);
            this.tableLayoutPanel1.Controls.Add(this.label17, 3, 0);
            this.tableLayoutPanel1.Controls.Add(this.label16, 2, 0);
            this.tableLayoutPanel1.Controls.Add(this.label15, 1, 0);
            this.tableLayoutPanel1.Controls.Add(this.label14, 0, 0);
            this.tableLayoutPanel1.Controls.Add(this.label21, 0, 2);
            this.tableLayoutPanel1.Controls.Add(this.label22, 0, 3);
            this.tableLayoutPanel1.Controls.Add(this.label23, 0, 4);
            this.tableLayoutPanel1.Controls.Add(this.label24, 0, 5);
            this.tableLayoutPanel1.Controls.Add(this.label25, 0, 6);
            this.tableLayoutPanel1.Controls.Add(this.label26, 3, 1);
            this.tableLayoutPanel1.Controls.Add(this.label27, 3, 2);
            this.tableLayoutPanel1.Controls.Add(this.label28, 3, 3);
            this.tableLayoutPanel1.Controls.Add(this.label29, 3, 4);
            this.tableLayoutPanel1.Controls.Add(this.label30, 3, 5);
            this.tableLayoutPanel1.Controls.Add(this.hostIP1TB, 1, 1);
            this.tableLayoutPanel1.Location = new System.Drawing.Point(30, 106);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 7;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 14.28571F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 14.28571F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 14.28571F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 14.28571F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 14.28571F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 14.28571F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 14.28571F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(402, 167);
            this.tableLayoutPanel1.TabIndex = 106;
            // 
            // hostPort12TB
            // 
            this.hostPort12TB.AccessibleName = "HostPort12";
            this.hostPort12TB.Dock = System.Windows.Forms.DockStyle.Fill;
            this.hostPort12TB.Location = new System.Drawing.Point(353, 142);
            this.hostPort12TB.Name = "hostPort12TB";
            this.hostPort12TB.Size = new System.Drawing.Size(45, 21);
            this.hostPort12TB.TabIndex = 41;
            // 
            // hostIP12TB
            // 
            this.hostIP12TB.AccessibleName = "HostIp12";
            this.hostIP12TB.Dock = System.Windows.Forms.DockStyle.Fill;
            this.hostIP12TB.Location = new System.Drawing.Point(233, 142);
            this.hostIP12TB.Name = "hostIP12TB";
            this.hostIP12TB.Size = new System.Drawing.Size(113, 21);
            this.hostIP12TB.TabIndex = 40;
            // 
            // hostPort11TB
            // 
            this.hostPort11TB.AccessibleName = "HostPort11";
            this.hostPort11TB.Dock = System.Windows.Forms.DockStyle.Fill;
            this.hostPort11TB.Location = new System.Drawing.Point(154, 142);
            this.hostPort11TB.Name = "hostPort11TB";
            this.hostPort11TB.Size = new System.Drawing.Size(42, 21);
            this.hostPort11TB.TabIndex = 39;
            // 
            // hostIP11TB
            // 
            this.hostIP11TB.AccessibleName = "HostIp11";
            this.hostIP11TB.Dock = System.Windows.Forms.DockStyle.Fill;
            this.hostIP11TB.Location = new System.Drawing.Point(34, 142);
            this.hostIP11TB.Name = "hostIP11TB";
            this.hostIP11TB.Size = new System.Drawing.Size(113, 21);
            this.hostIP11TB.TabIndex = 38;
            // 
            // hostPort10TB
            // 
            this.hostPort10TB.AccessibleName = "HostPort10";
            this.hostPort10TB.Dock = System.Windows.Forms.DockStyle.Fill;
            this.hostPort10TB.Location = new System.Drawing.Point(353, 119);
            this.hostPort10TB.Name = "hostPort10TB";
            this.hostPort10TB.Size = new System.Drawing.Size(45, 21);
            this.hostPort10TB.TabIndex = 37;
            // 
            // hostIP10TB
            // 
            this.hostIP10TB.AccessibleName = "HostIp10";
            this.hostIP10TB.Dock = System.Windows.Forms.DockStyle.Fill;
            this.hostIP10TB.Location = new System.Drawing.Point(233, 119);
            this.hostIP10TB.Name = "hostIP10TB";
            this.hostIP10TB.Size = new System.Drawing.Size(113, 21);
            this.hostIP10TB.TabIndex = 36;
            // 
            // hostPort9TB
            // 
            this.hostPort9TB.AccessibleName = "HostPort9";
            this.hostPort9TB.Dock = System.Windows.Forms.DockStyle.Fill;
            this.hostPort9TB.Location = new System.Drawing.Point(154, 119);
            this.hostPort9TB.Name = "hostPort9TB";
            this.hostPort9TB.Size = new System.Drawing.Size(42, 21);
            this.hostPort9TB.TabIndex = 35;
            // 
            // hostIP9TB
            // 
            this.hostIP9TB.AccessibleName = "HostIp9";
            this.hostIP9TB.Dock = System.Windows.Forms.DockStyle.Fill;
            this.hostIP9TB.Location = new System.Drawing.Point(34, 119);
            this.hostIP9TB.Name = "hostIP9TB";
            this.hostIP9TB.Size = new System.Drawing.Size(113, 21);
            this.hostIP9TB.TabIndex = 34;
            // 
            // hostPort8TB
            // 
            this.hostPort8TB.AccessibleName = "HostPort8";
            this.hostPort8TB.Dock = System.Windows.Forms.DockStyle.Fill;
            this.hostPort8TB.Location = new System.Drawing.Point(353, 96);
            this.hostPort8TB.Name = "hostPort8TB";
            this.hostPort8TB.Size = new System.Drawing.Size(45, 21);
            this.hostPort8TB.TabIndex = 33;
            // 
            // hostIP8TB
            // 
            this.hostIP8TB.AccessibleName = "HostIp8";
            this.hostIP8TB.Dock = System.Windows.Forms.DockStyle.Fill;
            this.hostIP8TB.Location = new System.Drawing.Point(233, 96);
            this.hostIP8TB.Name = "hostIP8TB";
            this.hostIP8TB.Size = new System.Drawing.Size(113, 21);
            this.hostIP8TB.TabIndex = 32;
            // 
            // hostPort7TB
            // 
            this.hostPort7TB.AccessibleName = "HostPort7";
            this.hostPort7TB.Dock = System.Windows.Forms.DockStyle.Fill;
            this.hostPort7TB.Location = new System.Drawing.Point(154, 96);
            this.hostPort7TB.Name = "hostPort7TB";
            this.hostPort7TB.Size = new System.Drawing.Size(42, 21);
            this.hostPort7TB.TabIndex = 31;
            // 
            // hostIP7TB
            // 
            this.hostIP7TB.AccessibleName = "HostIp7";
            this.hostIP7TB.Dock = System.Windows.Forms.DockStyle.Fill;
            this.hostIP7TB.Location = new System.Drawing.Point(34, 96);
            this.hostIP7TB.Name = "hostIP7TB";
            this.hostIP7TB.Size = new System.Drawing.Size(113, 21);
            this.hostIP7TB.TabIndex = 30;
            // 
            // hostPort6TB
            // 
            this.hostPort6TB.AccessibleName = "HostPort6";
            this.hostPort6TB.Dock = System.Windows.Forms.DockStyle.Fill;
            this.hostPort6TB.Location = new System.Drawing.Point(353, 73);
            this.hostPort6TB.Name = "hostPort6TB";
            this.hostPort6TB.Size = new System.Drawing.Size(45, 21);
            this.hostPort6TB.TabIndex = 29;
            // 
            // hostIP6TB
            // 
            this.hostIP6TB.AccessibleName = "HostIp6";
            this.hostIP6TB.Dock = System.Windows.Forms.DockStyle.Fill;
            this.hostIP6TB.Location = new System.Drawing.Point(233, 73);
            this.hostIP6TB.Name = "hostIP6TB";
            this.hostIP6TB.Size = new System.Drawing.Size(113, 21);
            this.hostIP6TB.TabIndex = 28;
            // 
            // hostPort5TB
            // 
            this.hostPort5TB.AccessibleName = "HostPort5";
            this.hostPort5TB.Dock = System.Windows.Forms.DockStyle.Fill;
            this.hostPort5TB.Location = new System.Drawing.Point(154, 73);
            this.hostPort5TB.Name = "hostPort5TB";
            this.hostPort5TB.Size = new System.Drawing.Size(42, 21);
            this.hostPort5TB.TabIndex = 27;
            // 
            // hostIP5TB
            // 
            this.hostIP5TB.AccessibleName = "HostIp5";
            this.hostIP5TB.Dock = System.Windows.Forms.DockStyle.Fill;
            this.hostIP5TB.Location = new System.Drawing.Point(34, 73);
            this.hostIP5TB.Name = "hostIP5TB";
            this.hostIP5TB.Size = new System.Drawing.Size(113, 21);
            this.hostIP5TB.TabIndex = 26;
            // 
            // hostPort4TB
            // 
            this.hostPort4TB.AccessibleName = "HostPort4";
            this.hostPort4TB.Dock = System.Windows.Forms.DockStyle.Fill;
            this.hostPort4TB.Location = new System.Drawing.Point(353, 50);
            this.hostPort4TB.Name = "hostPort4TB";
            this.hostPort4TB.Size = new System.Drawing.Size(45, 21);
            this.hostPort4TB.TabIndex = 25;
            // 
            // hostIP4TB
            // 
            this.hostIP4TB.AccessibleName = "HostIp4";
            this.hostIP4TB.Dock = System.Windows.Forms.DockStyle.Fill;
            this.hostIP4TB.Location = new System.Drawing.Point(233, 50);
            this.hostIP4TB.Name = "hostIP4TB";
            this.hostIP4TB.Size = new System.Drawing.Size(113, 21);
            this.hostIP4TB.TabIndex = 24;
            // 
            // hostPort3TB
            // 
            this.hostPort3TB.AccessibleName = "HostPort3";
            this.hostPort3TB.Dock = System.Windows.Forms.DockStyle.Fill;
            this.hostPort3TB.Location = new System.Drawing.Point(154, 50);
            this.hostPort3TB.Name = "hostPort3TB";
            this.hostPort3TB.Size = new System.Drawing.Size(42, 21);
            this.hostPort3TB.TabIndex = 23;
            // 
            // hostIP3TB
            // 
            this.hostIP3TB.AccessibleName = "HostIp3";
            this.hostIP3TB.Dock = System.Windows.Forms.DockStyle.Fill;
            this.hostIP3TB.Location = new System.Drawing.Point(34, 50);
            this.hostIP3TB.Name = "hostIP3TB";
            this.hostIP3TB.Size = new System.Drawing.Size(113, 21);
            this.hostIP3TB.TabIndex = 22;
            // 
            // hostPort2TB
            // 
            this.hostPort2TB.AccessibleName = "HostPort2";
            this.hostPort2TB.Dock = System.Windows.Forms.DockStyle.Fill;
            this.hostPort2TB.Location = new System.Drawing.Point(353, 27);
            this.hostPort2TB.Name = "hostPort2TB";
            this.hostPort2TB.Size = new System.Drawing.Size(45, 21);
            this.hostPort2TB.TabIndex = 21;
            // 
            // hostIP2TB
            // 
            this.hostIP2TB.AccessibleName = "HostIp2";
            this.hostIP2TB.Dock = System.Windows.Forms.DockStyle.Fill;
            this.hostIP2TB.Location = new System.Drawing.Point(233, 27);
            this.hostIP2TB.Name = "hostIP2TB";
            this.hostIP2TB.Size = new System.Drawing.Size(113, 21);
            this.hostIP2TB.TabIndex = 20;
            // 
            // hostPort1TB
            // 
            this.hostPort1TB.AccessibleName = "HostPort1";
            this.hostPort1TB.Dock = System.Windows.Forms.DockStyle.Fill;
            this.hostPort1TB.Location = new System.Drawing.Point(154, 27);
            this.hostPort1TB.Name = "hostPort1TB";
            this.hostPort1TB.Size = new System.Drawing.Size(42, 21);
            this.hostPort1TB.TabIndex = 19;
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label20.Location = new System.Drawing.Point(4, 24);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(23, 22);
            this.label20.TabIndex = 6;
            this.label20.Text = "1";
            this.label20.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label19.Location = new System.Drawing.Point(353, 1);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(45, 22);
            this.label19.TabIndex = 5;
            this.label19.Text = "Port";
            this.label19.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label18.Location = new System.Drawing.Point(233, 1);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(113, 22);
            this.label18.TabIndex = 4;
            this.label18.Text = "HOST Address";
            this.label18.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label17.Location = new System.Drawing.Point(203, 1);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(23, 22);
            this.label17.TabIndex = 3;
            this.label17.Text = "No";
            this.label17.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label16.Location = new System.Drawing.Point(154, 1);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(42, 22);
            this.label16.TabIndex = 2;
            this.label16.Text = "Port";
            this.label16.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label15.Location = new System.Drawing.Point(34, 1);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(113, 22);
            this.label15.TabIndex = 1;
            this.label15.Text = "HOST Address";
            this.label15.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label14.Location = new System.Drawing.Point(4, 1);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(23, 22);
            this.label14.TabIndex = 0;
            this.label14.Text = "No";
            this.label14.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label21.Location = new System.Drawing.Point(4, 47);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(23, 22);
            this.label21.TabIndex = 7;
            this.label21.Text = "3";
            this.label21.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label22.Location = new System.Drawing.Point(4, 70);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(23, 22);
            this.label22.TabIndex = 8;
            this.label22.Text = "5";
            this.label22.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label23.Location = new System.Drawing.Point(4, 93);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(23, 22);
            this.label23.TabIndex = 9;
            this.label23.Text = "7";
            this.label23.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label24.Location = new System.Drawing.Point(4, 116);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(23, 22);
            this.label24.TabIndex = 10;
            this.label24.Text = "9";
            this.label24.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label25.Location = new System.Drawing.Point(4, 139);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(23, 27);
            this.label25.TabIndex = 11;
            this.label25.Text = "11";
            this.label25.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label26.Location = new System.Drawing.Point(203, 24);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(23, 22);
            this.label26.TabIndex = 12;
            this.label26.Text = "2";
            this.label26.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label27.Location = new System.Drawing.Point(203, 47);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(23, 22);
            this.label27.TabIndex = 13;
            this.label27.Text = "4";
            this.label27.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label28.Location = new System.Drawing.Point(203, 70);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(23, 22);
            this.label28.TabIndex = 14;
            this.label28.Text = "6";
            this.label28.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label29.Location = new System.Drawing.Point(203, 93);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(23, 22);
            this.label29.TabIndex = 15;
            this.label29.Text = "8";
            this.label29.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label30.Location = new System.Drawing.Point(203, 116);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(23, 22);
            this.label30.TabIndex = 16;
            this.label30.Text = "10";
            this.label30.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // hostIP1TB
            // 
            this.hostIP1TB.AccessibleName = "HostIp1";
            this.hostIP1TB.Dock = System.Windows.Forms.DockStyle.Fill;
            this.hostIP1TB.Location = new System.Drawing.Point(34, 27);
            this.hostIP1TB.Name = "hostIP1TB";
            this.hostIP1TB.Size = new System.Drawing.Size(113, 21);
            this.hostIP1TB.TabIndex = 18;
            // 
            // channelNameL
            // 
            this.channelNameL.AutoSize = true;
            this.channelNameL.Font = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.channelNameL.Location = new System.Drawing.Point(50, 24);
            this.channelNameL.Name = "channelNameL";
            this.channelNameL.Size = new System.Drawing.Size(0, 12);
            this.channelNameL.TabIndex = 105;
            // 
            // tabPage_Password
            // 
            this.tabPage_Password.Controls.Add(this.groupBox1);
            this.tabPage_Password.Location = new System.Drawing.Point(4, 38);
            this.tabPage_Password.Name = "tabPage_Password";
            this.tabPage_Password.Size = new System.Drawing.Size(466, 291);
            this.tabPage_Password.TabIndex = 8;
            this.tabPage_Password.Text = "Password Settings";
            this.tabPage_Password.UseVisualStyleBackColor = true;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.oldPwdTB);
            this.groupBox1.Controls.Add(this.retypePwdTB);
            this.groupBox1.Controls.Add(this.newPwdTB);
            this.groupBox1.Controls.Add(this.label46);
            this.groupBox1.Controls.Add(this.label45);
            this.groupBox1.Controls.Add(this.label44);
            this.groupBox1.Location = new System.Drawing.Point(57, 41);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(315, 162);
            this.groupBox1.TabIndex = 1;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "ChangePassword";
            // 
            // oldPwdTB
            // 
            this.oldPwdTB.Location = new System.Drawing.Point(136, 32);
            this.oldPwdTB.Name = "oldPwdTB";
            this.oldPwdTB.PasswordChar = '*';
            this.oldPwdTB.Size = new System.Drawing.Size(137, 21);
            this.oldPwdTB.TabIndex = 100;
            // 
            // retypePwdTB
            // 
            this.retypePwdTB.Location = new System.Drawing.Point(136, 97);
            this.retypePwdTB.Name = "retypePwdTB";
            this.retypePwdTB.PasswordChar = '*';
            this.retypePwdTB.Size = new System.Drawing.Size(137, 21);
            this.retypePwdTB.TabIndex = 102;
            // 
            // newPwdTB
            // 
            this.newPwdTB.Location = new System.Drawing.Point(136, 65);
            this.newPwdTB.Name = "newPwdTB";
            this.newPwdTB.PasswordChar = '*';
            this.newPwdTB.Size = new System.Drawing.Size(137, 21);
            this.newPwdTB.TabIndex = 101;
            // 
            // label46
            // 
            this.label46.AutoSize = true;
            this.label46.Location = new System.Drawing.Point(35, 35);
            this.label46.Name = "label46";
            this.label46.Size = new System.Drawing.Size(77, 12);
            this.label46.TabIndex = 3;
            this.label46.Text = "Old Password";
            // 
            // label45
            // 
            this.label45.AutoSize = true;
            this.label45.Location = new System.Drawing.Point(34, 100);
            this.label45.Name = "label45";
            this.label45.Size = new System.Drawing.Size(95, 12);
            this.label45.TabIndex = 2;
            this.label45.Text = "Retype Password";
            // 
            // label44
            // 
            this.label44.AutoSize = true;
            this.label44.Location = new System.Drawing.Point(35, 71);
            this.label44.Name = "label44";
            this.label44.Size = new System.Drawing.Size(77, 12);
            this.label44.TabIndex = 1;
            this.label44.Text = "New Password";
            // 
            // tabPage_Power
            // 
            this.tabPage_Power.Controls.Add(this.groupBox7);
            this.tabPage_Power.Location = new System.Drawing.Point(4, 38);
            this.tabPage_Power.Name = "tabPage_Power";
            this.tabPage_Power.Size = new System.Drawing.Size(466, 291);
            this.tabPage_Power.TabIndex = 9;
            this.tabPage_Power.Text = "Power Manage";
            this.tabPage_Power.UseVisualStyleBackColor = true;
            // 
            // groupBox7
            // 
            this.groupBox7.Controls.Add(this.radioButton_Default);
            this.groupBox7.Controls.Add(this.radioButton_SaveReboot);
            this.groupBox7.Controls.Add(this.radioButton_DefaultReboot);
            this.groupBox7.Controls.Add(this.radioButton_Reboot);
            this.groupBox7.Location = new System.Drawing.Point(74, 63);
            this.groupBox7.Name = "groupBox7";
            this.groupBox7.Size = new System.Drawing.Size(308, 166);
            this.groupBox7.TabIndex = 9;
            this.groupBox7.TabStop = false;
            this.groupBox7.Text = "Power manage";
            // 
            // radioButton_Default
            // 
            this.radioButton_Default.AutoSize = true;
            this.radioButton_Default.Location = new System.Drawing.Point(32, 21);
            this.radioButton_Default.Name = "radioButton_Default";
            this.radioButton_Default.Size = new System.Drawing.Size(101, 16);
            this.radioButton_Default.TabIndex = 4;
            this.radioButton_Default.Text = "Load defaults";
            this.radioButton_Default.UseVisualStyleBackColor = true;
            // 
            // radioButton_SaveReboot
            // 
            this.radioButton_SaveReboot.AutoSize = true;
            this.radioButton_SaveReboot.Checked = true;
            this.radioButton_SaveReboot.Location = new System.Drawing.Point(32, 133);
            this.radioButton_SaveReboot.Name = "radioButton_SaveReboot";
            this.radioButton_SaveReboot.Size = new System.Drawing.Size(113, 16);
            this.radioButton_SaveReboot.TabIndex = 7;
            this.radioButton_SaveReboot.TabStop = true;
            this.radioButton_SaveReboot.Text = "Save and reboot";
            this.radioButton_SaveReboot.UseVisualStyleBackColor = true;
            // 
            // radioButton_DefaultReboot
            // 
            this.radioButton_DefaultReboot.AutoSize = true;
            this.radioButton_DefaultReboot.Location = new System.Drawing.Point(32, 59);
            this.radioButton_DefaultReboot.Name = "radioButton_DefaultReboot";
            this.radioButton_DefaultReboot.Size = new System.Drawing.Size(167, 16);
            this.radioButton_DefaultReboot.TabIndex = 5;
            this.radioButton_DefaultReboot.Text = "Load defaults and reboot";
            this.radioButton_DefaultReboot.UseVisualStyleBackColor = true;
            // 
            // radioButton_Reboot
            // 
            this.radioButton_Reboot.AutoSize = true;
            this.radioButton_Reboot.Location = new System.Drawing.Point(32, 97);
            this.radioButton_Reboot.Name = "radioButton_Reboot";
            this.radioButton_Reboot.Size = new System.Drawing.Size(59, 16);
            this.radioButton_Reboot.TabIndex = 6;
            this.radioButton_Reboot.Text = "Reboot";
            this.radioButton_Reboot.UseVisualStyleBackColor = true;
            // 
            // button_Refresh
            // 
            this.button_Refresh.Location = new System.Drawing.Point(12, 392);
            this.button_Refresh.Name = "button_Refresh";
            this.button_Refresh.Size = new System.Drawing.Size(75, 23);
            this.button_Refresh.TabIndex = 1;
            this.button_Refresh.Text = "Refresh";
            this.button_Refresh.UseVisualStyleBackColor = true;
            this.button_Refresh.Click += new System.EventHandler(this.button_Refresh_Click);
            // 
            // button_OK
            // 
            this.button_OK.Location = new System.Drawing.Point(313, 392);
            this.button_OK.Name = "button_OK";
            this.button_OK.Size = new System.Drawing.Size(75, 23);
            this.button_OK.TabIndex = 3;
            this.button_OK.Text = "OK";
            this.button_OK.UseVisualStyleBackColor = true;
            this.button_OK.Click += new System.EventHandler(this.button_OK_Click);
            // 
            // button_Close
            // 
            this.button_Close.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.button_Close.Location = new System.Drawing.Point(407, 392);
            this.button_Close.Name = "button_Close";
            this.button_Close.Size = new System.Drawing.Size(75, 23);
            this.button_Close.TabIndex = 4;
            this.button_Close.Text = "Close";
            this.button_Close.UseVisualStyleBackColor = true;
            // 
            // Lable_Message
            // 
            this.Lable_Message.BackColor = System.Drawing.Color.White;
            this.Lable_Message.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.Lable_Message.ForeColor = System.Drawing.Color.SteelBlue;
            this.Lable_Message.Location = new System.Drawing.Point(12, 345);
            this.Lable_Message.Margin = new System.Windows.Forms.Padding(3);
            this.Lable_Message.Name = "Lable_Message";
            this.Lable_Message.Padding = new System.Windows.Forms.Padding(3);
            this.Lable_Message.Size = new System.Drawing.Size(474, 39);
            this.Lable_Message.TabIndex = 29;
            // 
            // ConfigForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(495, 430);
            this.Controls.Add(this.Lable_Message);
            this.Controls.Add(this.button_Close);
            this.Controls.Add(this.button_OK);
            this.Controls.Add(this.button_Refresh);
            this.Controls.Add(this.tabControl);
            this.Name = "ConfigForm";
            this.Text = "ConfigForm";
            this.Load += new System.EventHandler(this.ConfigForm_Load);
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.ConfigForm_FormClosed);
            this.tabControl.ResumeLayout(false);
            this.tabPage_Basic.ResumeLayout(false);
            this.tabPage_Basic.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown2)).EndInit();
            this.tabPage_Network.ResumeLayout(false);
            this.tabPage_Network.PerformLayout();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.panel_StaticIp.ResumeLayout(false);
            this.panel_StaticIp.PerformLayout();
            this.panel_AutoIp.ResumeLayout(false);
            this.panel_AutoIp.PerformLayout();
            this.tabPage_PPP.ResumeLayout(false);
            this.tabPage_PPP.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pppIDLENUD)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pppRINUD)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pppMaxRTNUD)).EndInit();
            this.tabPage_Sever.ResumeLayout(false);
            this.tabPage_Sever.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.httpPortNUD)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.arpNUD)).EndInit();
            this.tabPage_Serial.ResumeLayout(false);
            this.tabPage_Serial.PerformLayout();
            this.panel9.ResumeLayout(false);
            this.panel9.PerformLayout();
            this.panel6.ResumeLayout(false);
            this.panel6.PerformLayout();
            this.panel4.ResumeLayout(false);
            this.panel4.PerformLayout();
            this.tabPage_Connection.ResumeLayout(false);
            this.tabPage_Connection.PerformLayout();
            this.panel_TCP.ResumeLayout(false);
            this.panel_TCP.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.inactivityNUD)).EndInit();
            this.groupBox5.ResumeLayout(false);
            this.groupBox5.PerformLayout();
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dnsQueryPeriodNUD)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tcpRemotePortNUD)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tcpLocalPortNUD)).EndInit();
            this.panel_UDP.ResumeLayout(false);
            this.panel_UDP.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.udpUCLPNUD)).EndInit();
            this.tableLayoutPanel2.ResumeLayout(false);
            this.tableLayoutPanel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.udpPort0TB)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.udpPort1TB)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.udpPort2TB)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.udpPort3TB)).EndInit();
            this.panel7.ResumeLayout(false);
            this.panel7.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.udpRemotePortNUD)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.udpLocalPortNUD)).EndInit();
            this.tabPage_Hostlist.ResumeLayout(false);
            this.tabPage_Hostlist.PerformLayout();
            this.groupBox6.ResumeLayout(false);
            this.groupBox6.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.retryCNUD)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.retryTNUD)).EndInit();
            this.tableLayoutPanel1.ResumeLayout(false);
            this.tableLayoutPanel1.PerformLayout();
            this.tabPage_Password.ResumeLayout(false);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.tabPage_Power.ResumeLayout(false);
            this.groupBox7.ResumeLayout(false);
            this.groupBox7.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabControl tabControl;
        private System.Windows.Forms.TabPage tabPage_Basic;
        private System.Windows.Forms.TabPage tabPage_Network;
        private System.Windows.Forms.TabPage tabPage_PPPoE;
        private System.Windows.Forms.TabPage tabPage_PPP;
        private System.Windows.Forms.TabPage tabPage_Sever;
        private System.Windows.Forms.TabPage tabPage_Serial;
        private System.Windows.Forms.TabPage tabPage_Connection;
        private System.Windows.Forms.TabPage tabPage_Hostlist;
        private System.Windows.Forms.TabPage tabPage_Password;
        private System.Windows.Forms.TabPage tabPage_Power;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.CheckBox telnetCB;
        private System.Windows.Forms.CheckBox webCB;
        private System.Windows.Forms.TextBox terminalTB;
        private System.Windows.Forms.TextBox timeServerTB;
        private System.Windows.Forms.ComboBox timeZoneCB;
        private System.Windows.Forms.TextBox nameTB;
        private System.Windows.Forms.Button button_Refresh;
        private System.Windows.Forms.Button button_OK;
        private System.Windows.Forms.Button button_Close;
        private System.Windows.Forms.GroupBox groupBox7;
        private System.Windows.Forms.RadioButton radioButton_Default;
        private System.Windows.Forms.RadioButton radioButton_SaveReboot;
        private System.Windows.Forms.RadioButton radioButton_DefaultReboot;
        private System.Windows.Forms.RadioButton radioButton_Reboot;
        private System.Windows.Forms.Label Lable_Message;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.TextBox oldPwdTB;
        private System.Windows.Forms.TextBox retypePwdTB;
        private System.Windows.Forms.TextBox newPwdTB;
        private System.Windows.Forms.Label label46;
        private System.Windows.Forms.Label label45;
        private System.Windows.Forms.Label label44;
        private System.Windows.Forms.GroupBox groupBox6;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.NumericUpDown retryCNUD;
        private System.Windows.Forms.NumericUpDown retryTNUD;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.TextBox hostPort12TB;
        private System.Windows.Forms.TextBox hostIP12TB;
        private System.Windows.Forms.TextBox hostPort11TB;
        private System.Windows.Forms.TextBox hostIP11TB;
        private System.Windows.Forms.TextBox hostPort10TB;
        private System.Windows.Forms.TextBox hostIP10TB;
        private System.Windows.Forms.TextBox hostPort9TB;
        private System.Windows.Forms.TextBox hostIP9TB;
        private System.Windows.Forms.TextBox hostPort8TB;
        private System.Windows.Forms.TextBox hostIP8TB;
        private System.Windows.Forms.TextBox hostPort7TB;
        private System.Windows.Forms.TextBox hostIP7TB;
        private System.Windows.Forms.TextBox hostPort6TB;
        private System.Windows.Forms.TextBox hostIP6TB;
        private System.Windows.Forms.TextBox hostPort5TB;
        private System.Windows.Forms.TextBox hostIP5TB;
        private System.Windows.Forms.TextBox hostPort4TB;
        private System.Windows.Forms.TextBox hostIP4TB;
        private System.Windows.Forms.TextBox hostPort3TB;
        private System.Windows.Forms.TextBox hostIP3TB;
        private System.Windows.Forms.TextBox hostPort2TB;
        private System.Windows.Forms.TextBox hostIP2TB;
        private System.Windows.Forms.TextBox hostPort1TB;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.TextBox hostIP1TB;
        private System.Windows.Forms.Label channelNameL;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.ComboBox cpuCB;
        private System.Windows.Forms.TextBox mtuTB;
        private System.Windows.Forms.NumericUpDown httpPortNUD;
        private System.Windows.Forms.NumericUpDown arpNUD;
        private System.Windows.Forms.ComboBox pppComCB;
        private System.Windows.Forms.TextBox pppDNS2TB;
        private System.Windows.Forms.TextBox pppDNS1TB;
        private System.Windows.Forms.TextBox pppGatewayTB;
        private System.Windows.Forms.TextBox pppIPTB;
        private System.Windows.Forms.TextBox pppStatusTB;
        private System.Windows.Forms.NumericUpDown pppIDLENUD;
        private System.Windows.Forms.NumericUpDown pppRINUD;
        private System.Windows.Forms.NumericUpDown pppMaxRTNUD;
        private System.Windows.Forms.ComboBox pppWorkModeCB;
        private System.Windows.Forms.TextBox pppPwdTB;
        private System.Windows.Forms.TextBox pppUserNameTB;
        private System.Windows.Forms.Label label47;
        private System.Windows.Forms.Label label42;
        private System.Windows.Forms.Label label41;
        private System.Windows.Forms.Label label40;
        private System.Windows.Forms.Label label39;
        private System.Windows.Forms.Label label38;
        private System.Windows.Forms.Label label37;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.CheckBox checkBox1;
        private System.Windows.Forms.Panel panel9;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.Label label61;
        private System.Windows.Forms.Label label60;
        private System.Windows.Forms.TextBox lastTB;
        private System.Windows.Forms.TextBox firstCharTB;
        private System.Windows.Forms.ComboBox sendBytesCB;
        private System.Windows.Forms.CheckBox match2CB;
        private System.Windows.Forms.CheckBox sendFrameCB;
        private System.Windows.Forms.ComboBox idleCB;
        private System.Windows.Forms.CheckBox enablePackCB;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.ComboBox protocolCB;
        private System.Windows.Forms.ComboBox stopbitCB;
        private System.Windows.Forms.ComboBox parityCB;
        private System.Windows.Forms.ComboBox databitCB;
        private System.Windows.Forms.ComboBox baudrateCB;
        private System.Windows.Forms.ComboBox flowCB;
        private System.Windows.Forms.ComboBox fifoCB;
        private System.Windows.Forms.CheckBox serialOptionCB;
        private System.Windows.Forms.Label channelNameL1;
        private System.Windows.Forms.Label label62;
        private System.Windows.Forms.Label label63;
        private System.Windows.Forms.Panel panel_TCP;
        private System.Windows.Forms.Label label84;
        private System.Windows.Forms.Label label83;
        private System.Windows.Forms.Label label82;
        private System.Windows.Forms.Label label81;
        private System.Windows.Forms.Label label80;
        private System.Windows.Forms.Label label79;
        private System.Windows.Forms.Label label78;
        private System.Windows.Forms.Label label77;
        private System.Windows.Forms.Label label76;
        private System.Windows.Forms.Label label75;
        private System.Windows.Forms.Label label68;
        private System.Windows.Forms.NumericUpDown inactivityNUD;
        private System.Windows.Forms.GroupBox groupBox5;
        private System.Windows.Forms.Label label74;
        private System.Windows.Forms.Label label73;
        private System.Windows.Forms.Label label72;
        private System.Windows.Forms.CheckBox oatdCB;
        private System.Windows.Forms.CheckBox owacCB;
        private System.Windows.Forms.CheckBox owpcCB;
        private System.Windows.Forms.ComboBox workasCB;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.Label label71;
        private System.Windows.Forms.Label label70;
        private System.Windows.Forms.Label label69;
        private System.Windows.Forms.CheckBox iwacCB;
        private System.Windows.Forms.CheckBox iwpcCB;
        private System.Windows.Forms.CheckBox iatdCB;
        private System.Windows.Forms.NumericUpDown dnsQueryPeriodNUD;
        private System.Windows.Forms.CheckBox hardDisconnectCB;
        private System.Windows.Forms.CheckBox checkEOTCB;
        private System.Windows.Forms.CheckBox onDSRDropCB;
        private System.Windows.Forms.ComboBox connectResponseCB;
        private System.Windows.Forms.TextBox tcpRomteHostTB;
        private System.Windows.Forms.CheckBox useHostlistCB;
        private System.Windows.Forms.NumericUpDown tcpRemotePortNUD;
        private System.Windows.Forms.NumericUpDown tcpLocalPortNUD;
        private System.Windows.Forms.TextBox startCharTB;
        private System.Windows.Forms.ComboBox tcpActiveCB;
        private System.Windows.Forms.ComboBox netProtocolCB;
        private System.Windows.Forms.Label channelNameL2;
        private System.Windows.Forms.Panel panel_UDP;
        private System.Windows.Forms.Label label98;
        private System.Windows.Forms.Label label94;
        private System.Windows.Forms.Label label93;
        private System.Windows.Forms.NumericUpDown udpUCLPNUD;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel2;
        private System.Windows.Forms.TextBox eAddr3TB;
        private System.Windows.Forms.TextBox bAddr3TB;
        private System.Windows.Forms.TextBox eAddr2TB;
        private System.Windows.Forms.TextBox bAddr2TB;
        private System.Windows.Forms.TextBox eAddr1TB;
        private System.Windows.Forms.TextBox bAddr1TB;
        private System.Windows.Forms.TextBox eAddr0TB;
        private System.Windows.Forms.TextBox bAddr0TB;
        private System.Windows.Forms.Label label85;
        private System.Windows.Forms.Label label86;
        private System.Windows.Forms.Label label87;
        private System.Windows.Forms.Label label88;
        private System.Windows.Forms.Label label89;
        private System.Windows.Forms.Label label90;
        private System.Windows.Forms.Label label91;
        private System.Windows.Forms.Label label92;
        private System.Windows.Forms.NumericUpDown udpPort0TB;
        private System.Windows.Forms.NumericUpDown udpPort1TB;
        private System.Windows.Forms.NumericUpDown udpPort2TB;
        private System.Windows.Forms.NumericUpDown udpPort3TB;
        private System.Windows.Forms.Panel panel7;
        private System.Windows.Forms.Label label97;
        private System.Windows.Forms.Label label96;
        private System.Windows.Forms.Label label95;
        private System.Windows.Forms.TextBox udpRemoteIpTB;
        private System.Windows.Forms.NumericUpDown udpRemotePortNUD;
        private System.Windows.Forms.NumericUpDown udpLocalPortNUD;
        private System.Windows.Forms.ComboBox datagramCB;
        private System.Windows.Forms.Label label43;
        private System.Windows.Forms.ComboBox comboBox_HostChannel;
        private System.Windows.Forms.Label label99;
        private System.Windows.Forms.ComboBox comboBox_SerialChannel;
        private System.Windows.Forms.Label label100;
        private System.Windows.Forms.ComboBox comboBox_ConnChannel;
        private System.Windows.Forms.NumericUpDown numericUpDown1;
        private System.Windows.Forms.NumericUpDown numericUpDown6;
        private System.Windows.Forms.NumericUpDown numericUpDown5;
        private System.Windows.Forms.NumericUpDown numericUpDown4;
        private System.Windows.Forms.NumericUpDown numericUpDown3;
        private System.Windows.Forms.NumericUpDown numericUpDown2;
        private System.Windows.Forms.NumericUpDown numericUpDown7;
        private System.Windows.Forms.TextBox macTB;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.ComboBox duplexCB;
        private System.Windows.Forms.ComboBox speedCB;
        private System.Windows.Forms.Panel panel_StaticIp;
        private System.Windows.Forms.TextBox altDNSTB;
        private System.Windows.Forms.TextBox pDNSTB;
        private System.Windows.Forms.TextBox gatewayTB;
        private System.Windows.Forms.TextBox subnetTB;
        private System.Windows.Forms.TextBox ipTB;
        private System.Windows.Forms.Panel panel_AutoIp;
        private System.Windows.Forms.TextBox dhcpNameTB;
        private System.Windows.Forms.CheckBox autoIPCB;
        private System.Windows.Forms.CheckBox dhcpCB;
        private System.Windows.Forms.CheckBox bootpCB;
        private System.Windows.Forms.Label label104;
        private System.Windows.Forms.Label label103;
        private System.Windows.Forms.Label label102;
        private System.Windows.Forms.Label label101;
        private System.Windows.Forms.Label label107;
        private System.Windows.Forms.Label label106;
        private System.Windows.Forms.Label label105;
        private System.Windows.Forms.Label label109;
        private System.Windows.Forms.Label label108;
        private System.Windows.Forms.Label label110;
        private System.Windows.Forms.Label label112;
        private System.Windows.Forms.Label label111;
        private System.Windows.Forms.CheckBox checkBox2;
        private System.Windows.Forms.ComboBox comboBox_IpConfig;
        private System.Windows.Forms.Label label113;

    }
}